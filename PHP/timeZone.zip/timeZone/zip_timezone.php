<?php
//~ https://api.worldweatheronline.com/premium/v1/tz.ashx?key=xxxxxxxxxxxxxxxxx&q=99660&format=xml
$zipcode = $_GET["zipcode"];
$selDate = $_GET["selDate"];


$loc_array= Array($zipcode);			//data validated in foreach. 
$api_key="5e96f934d9824b1eae953803162406";		//should be embedded in your code, so no data validation necessary, otherwise if(strlen($api_key)!=24)

$loc_safe=Array();
foreach($loc_array as $loc){
	$loc_safe[]= urlencode($loc);
}
$loc_string=implode(",", $loc_safe);
// print $loc_string . "<br />";

//To add more conditions to the query, just lengthen the url string
$basicurl=sprintf('https://api.worldweatheronline.com/premium/v1/tz.ashx?key=%s&q=%s&format=xml', $api_key, $loc_string);
// print $basicurl . "<br />";

$xml_response = file_get_contents($basicurl);
$xml = simplexml_load_string($xml_response);

$ziplocaltime  = $xml->time_zone->localtime;
$ziptimezone   = $xml->time_zone->utcOffset;

//zip date
$zip_response_date = date('Y-m-d', strtotime($ziplocaltime));
$zip_response_time = date('g:i A', strtotime($ziplocaltime));
$cttime = strtotime($zip_response_date.' '.$zip_response_time);
$ctdate = strtotime($zip_response_date);
echo $zip_hours = date("H", $cttime);

$zip_dayname = date("l", $cttime);
switch ($zip_dayname) {
	case 'Monday':
		$maxTime = strtotime($selDate." 12:00:00");
		$time_limit = 12;
		break;
	case 'Tuesday':
		$maxTime = strtotime($selDate);
		$time_limit = 12;
		break;
	case 'Wednesday':
		$maxTime = strtotime($selDate);
		$time_limit = 12;
		break;
	case 'Thursday':
		$maxTime = strtotime($selDate);
		$time_limit = 12;
		break;
	case 'Friday':
		$maxTime = strtotime($selDate);
		$time_limit = 12;
		break;
	case 'Saturday':
		$maxTime = strtotime($selDate);
		$time_limit = 10;
		break;
	case 'Sunday':
		// $maxTime = closed;
		break;
}

//cc 06-24-2016 12:00:00 ==== max 06-25-2016 12:00:00 

$tomorrow = date('m-d-Y', strtotime($zip_response_date . "+1 days"));
//echo '<br>maxtime '.$max_tim.'<br>'.$maxTime;
if( $zip_dayname == "Sunday" ){
		$array_data['status']  = 'closed';
		$array_data['nextday'] = $tomorrow;
}
else{

	if( $ctdate == $maxTime  && $zip_hours < $time_limit ){// check if it is today and less then given time
		$array_data['status']  = 'active';
		$array_data['nextday'] = 0;
	}
	elseif($ctdate == $maxTime  && $zip_hours >= $time_limit){ //if zip code date is greate then condition time
		$array_data['status']  = 'fail';
		$array_data['nextday'] = $tomorrow;
	}
	elseif($ctdate < $maxTime){
		$array_data['status']  =  'active';
		$array_data['nextday'] = 0;
	}else{
		$array_data['status']  =  'fail';
		$array_data['nextday'] = $tomorrow;
	}

}


print_r(json_encode($array_data));


?>
