<?php
//~ https://api.worldweatheronline.com/premium/v1/tz.ashx?key=xxxxxxxxxxxxxxxxx&q=99660&format=xml
$zipcode = $_POST["zipcode"];
// $zipcode = "99660";

$loc_array= Array($zipcode);			//data validated in foreach. 
$api_key="5e96f934d9824b1eae953803162406";		//should be embedded in your code, so no data validation necessary, otherwise if(strlen($api_key)!=24)

$loc_safe=Array();
foreach($loc_array as $loc){
	$loc_safe[]= urlencode($loc);
}
$loc_string=implode(",", $loc_safe);
// print $loc_string . "<br />";

//To add more conditions to the query, just lengthen the url string
$basicurl=sprintf('https://api.worldweatheronline.com/premium/v1/tz.ashx?key=%s&q=%s&format=xml', $api_key, $loc_string);
// print $basicurl . "<br />";

$xml_response = file_get_contents($basicurl);
$xml = simplexml_load_string($xml_response);

echo $srvlocaltime  = date("Y-m-d h:i") . ";";
echo $srvlocalhours = date("h") . ";";

echo $ziplocaltime  = $xml->time_zone->localtime . ";";
echo $ziptimezone   = $xml->time_zone->utcOffset;

// printf("<p>The time zone at %s is %s and the local time is %s</p>", $xml->request->query, $xml->time_zone->utcOffset, $xml->time_zone->localtime );

// print "<pre>";
// print_r($xml);
// print "</pre>";
?>
