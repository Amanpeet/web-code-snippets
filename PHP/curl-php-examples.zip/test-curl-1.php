<?php
var_dump(function_exists('curl_version'));