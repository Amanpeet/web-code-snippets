<?php
  // set seo
  $title = "Pharmaceutical, Chemical & Biological Testing & Analysis Services| SRD Pharma";
  $description = "One stop shop for all your research needs, trusted manufacturer and supplier of fine chemicals, ELISA kits, pharmaceutical testing, microbiological, water, testing, cosmetic, chemical & biological testing.";
  $keywords = "Water testing laboratory, Food testing lab, Analytical lab, Consumer product testing, Pharmaceutical testing, chemical testing laboratory, microbiological analysis, Chemical water analysis";

  // header
  include('include/header.php');
?>

<div class="titlemon pt-4 pb-2">
  <div class="container text-center pt-4">
    <h1 class="text-dark"><strong> Services </strong></h1>
    <div><a href="index.php"> <small> <i class="fa fa-arrow-left"></i> BACK TO HOME</small></a> </div>
    <span class="line"></span>
  </div>
</div>

<section class="page-section py-5">
  <div class="container">
    <div class="card card-body text-center py-4">

      <h2> Services We Provide </h2>
      <div class="text-center">
        <p>We are an accredited independent analytical laboratory with operations in North America, Canada, India, Middle East and Africa. We are serving best in the business of pharmaceuticals, food testing, neutraceuticals, water and industrial chemical analysis. Our expertise includes analysis of drugs, food products, organic materials, inorganic materials, water, oil, analytical method validation and process validation using advanced techniques of HPLC (with RI Detector UV detector, Fluorescence detector, Diode Array Detector, quaternary system with chiller) etc.</p>
      </div>

    </div>
  </div>
</section>

<section class="page-section bg-light mb-5">
  <div class="container">
    <div class="py-2">

      <div class="card mb-4">
        <div class="row no-gutters">
          <div class="col-md-2 bg-light2 text-left text-lg-center p-4">
            <span class="icon"><i class="fa fa-vials fa-3x"></i></span>
          </div>
          <div class="col-md-10">
            <div class="card-body">
              <h3 class="card-title"> Pharmaceutical Testing </h3>
              <div class="card-text">
                <p class="text-dark">At SRD Pharma we perform a variety of pharmaceutical testing to support quality processes. Quality is of great importance in the pharmaceutical industry as people’s lives directly depend on the quality of medicines given to them. This highlights how important it is to have a reliable partner for testing and certification of pharmaceutical products and their ingredients. </p>

                <h5>Raw Materials</h5>
                <ul class="triple-list text-muted">
                  <li> Appearance </li>
                  <li> Clarity & Colour of solution </li>
                  <li> LOD </li>
                  <li> Water by KF </li>
                  <li> pH/ acidity/ alkalinity </li>
                  <li> Congealing range </li>
                  <li> Melting point/ Boiling point </li>
                  <li> Boiling range </li>
                  <li> Optical rotation </li>
                  <li> Solubility </li>
                  <li> Density/ specific gravity at 25C </li>
                  <li> Freezing point </li>
                  <li> Peroxide value </li>
                  <li> Refractive index </li>
                  <li> Gravimetric assay </li>
                  <li> Acid value </li>
                  <li> Iodine value </li>
                  <li> Hydroxyl value </li>
                  <li> Jelly strength </li>
                  <li> Saponification value </li>
                  <li> Pepsin </li>
                  <li> Fungal diastase </li>
                  <li> K value </li>
                  <li> Crystallinity </li>
                  <li> Flame photometer </li>
                  <li> Papain </li>
                  <li> Ether soluble substances </li>
                  <li> Total dye content </li>
                  <li> Degree of substitution </li>
                  <li> Degree of polymerization </li>
                  <li> Fat content </li>
                  <li> Protein content </li>
                  <li> Total residue </li>
                  <li> Carbohydrate content </li>
                  <li> Related substances </li>
                  <li> Energy value </li>
                  <li> Assay (Titration, HPLC, GC, AAS, etc.) </li>
                  <li> Identification (by IR, HPLC, UV, GC, TLC, Chemically) </li>
                  <li> Limit test (Arsenic, Chloride, heavy metals, iron, lead, sulphate) </li>
                  <li> Sulphated ash/ residue on ignition/ loss on ignition </li>
                  <li> Viscosity </li>
                </ul>

                <h5>Finished Products</h5>
                <ul class="triple-list text-muted">
                  <li> Disintegration test </li>
                  <li> Density </li>
                  <li> Uniformity of content </li>
                  <li> Fungal diabase </li>
                  <li> Hardness test </li>
                  <li> Friability test </li>
                  <li> Pepsin </li>
                  <li> Papain </li>
                  <li> pH/ acidity/ alkalinity </li>
                  <li> Residual solvents (by GC) </li>
                  <li> Related substances (HPLC, GC) </li>
                  <li> Dissolution rate test <!--(HPLC, AAS, GC)--> </li>
                  <li> Uniformity of weight/ mass/ volume/ fill </li>
                  <li> Assay as per IP/ BP/ USP (HPLC, GC, UV, FTIR) </li>
                </ul>

              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="card mb-4">
        <div class="row no-gutters">
          <div class="col-md-2 bg-light2 text-left text-lg-center p-4">
            <span class="icon"><i class="fa fa-flask fa-3x"></i></span>
          </div>
          <div class="col-md-10">
            <div class="card-body">
              <h3 class="card-title"> Cosmetic Testing </h3>
              <div class="card-text">
                <p>Cosmetics are required to be safe for the consumers to be used. We test various skincare and hair products for them to be safe to use by humans. </p>
                <h5>Chemical & Biological testing of</h5>
                <ul class="triple-list text-muted">
                  <li> Hair Oils </li>
                  <li> Hair colors </li>
                  <li> Shampoo </li>
                  <li> Skin creams </li>
                  <li> Lotions </li>
                  <li> Perfume Concentrates </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="card mb-4">
        <div class="row no-gutters">
          <div class="col-md-2 bg-light2 text-left text-lg-center p-4">
            <span class="icon"><i class="fa fa-utensils fa-3x"></i></span>
          </div>
          <div class="col-md-10">
            <div class="card-body">
              <h3 class="card-title"> Food Testing </h3>
              <div class="card-text">
                <p>Food testing is of utmost importance to the efficient production of safe and quality products. In today’s world, food hygiene is a must. Food hygiene also refers to making sure that food is hygienically prepared and the quality is maintained. Food testing process is usually done at the end of the food manufacturing process. Food testing is a crucial process that determines whether the food is safe for consumption. </p>
                <h5>Chemical & Biological testing of</h5>
                <ul class="triple-list text-muted">
                  <li> Salt </li>
                  <li> Infant Food </li>
                  <li> Herbs, Spices & Condiments </li>
                  <li> Oils, Fats & Fat emulsions </li>
                  <li> Alcoholic Beverages </li>
                  <li> Tea & Tea Products </li>
                  <li> Milk & Milk products (As per BIS & FSSAI) </li>
                  <li> Cereal & Cereal Products – Maida, Wheat </li>
                  <li> Fruits & Vegetable products – Jam, Crushes, Syrups, Pickles, Murabbas, Tomato Ketchup etc. </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="card mb-4">
        <div class="row no-gutters">
          <div class="col-md-2 bg-light2 text-left text-lg-center p-4">
            <span class="icon"><i class="fa fa-tint fa-3x"></i></span>
          </div>
          <div class="col-md-10">
            <div class="card-body">
              <h3 class="card-title"> Water Testing </h3>
              <div class="card-text">
                <p>There are different types of tests that are done on water such as bacteria tests, pH tests, mineral tests, etc. Testing water quality on a regularly is a major part of maintaining a safe and reliable water source. Water testing results allow you to properly address the distinct problems of a water supply. </p>
                <h5>Chemical & Biological testing of</h5>
                <ul class="triple-list text-muted">
                  <li> Water for injection </li>
                  <li> Raw Water </li>
                  <li> Purified Water </li>
                  <li> Waste Water </li>
                  <li> Drinking water as per IS 10500:2012 </li>
                  <li> Water for food processing industries as per IS 4251 </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="card mb-4">
        <div class="row no-gutters">
          <div class="col-md-2 bg-light2 text-left text-lg-center p-4">
            <span class="icon"><i class="fa fa-microscope fa-3x"></i></span>
          </div>
          <div class="col-md-10">
            <div class="card-body">
              <h3 class="card-title"> Microbiological Testing </h3>
              <div class="card-text">
                <p>Microbiology testing process is a paramount to minimize the risk of potential damage by microbes" to "Microbiology testing process is paramount to minimize the risk of potential damage by microbes. </p>
                <h5>Chemical & Biological testing of</h5>
                <ul class="triple-list text-muted">
                  <li> Total Bacterial Count (TBC) </li>
                  <li> P.aeruginosa </li>
                  <li> Salmonella </li>
                  <li> Total Fungal Count (TFC) </li>
                  <li> E.coli </li>
                  <li> Sterility </li>
                  <li> BET </li>
                  <li> Pathogens </li>
                  <li> S. aureus </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="card mb-4">
        <div class="row no-gutters">
          <div class="col-md-2 bg-light2 text-left text-lg-center p-4">
            <span class="icon"><i class="fa fa-book-reader fa-3x"></i></span>
          </div>
          <div class="col-md-10">
            <div class="card-body">
              <h3 class="card-title"> Training </h3>
              <div class="card-text">
                <p>We provide 1 - 12 months chargeable trainings to students with a graduation or post-graduation degree.</p>
                <p> We give training in Instrumentation/ Chemical/ Microbiology and also in Q.A. (Regulatory). Candidates will be trained in both individual sections and combined sections. The needs of the industry are always kept in mind while providing training. For this we have regular interaction with the Q.C/ Q/A/ department of industry. We help students find jobs in various pharmaceutical companies.  </p>
                <p> We also provide practical trainings to students in the field of Quality Control (QC) and quality Assurance (QA). We offer short duration courses in the above mentioned fields focusing on their placement in the Drug & Pharma, Chemical, Food industry, etc. </p>
                <p> We provide training as per international guideline IS/ISO/IEC 17 0?.5: </p>

                <h5>Management Requirements</h5>
                <ul class="triple-list text-muted">
                  <li> Management System </li>
                  <li> Control of non-conformance work </li>
                  <li> Management Review </li>
                  <li> Document Control </li>
                  <li> Preventive action </li>
                  <li> Organization </li>
                  <li> Control of records </li>
                  <li> Corrective action </li>
                  <li> Internal Audits </li>
                </ul>

                <h5>Technical requirements</h5>
                <ul class="triple-list text-muted">
                  <li> Test and calibration methods and method validation </li>
                  <li> Accommodation and environmental conditions </li>
                  <li> Handling of test items </li>
                  <li> Reporting of Results </li>
                  <li> Preventive action </li>
                  <li> Personnel requirements </li>
                  <li> Internal Audits </li>
                  <li> Control of records </li>
                  <li> Management Review </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>


    </div>
  </div>
</section>

<section class="page-section bg-light py-4 mb-5 d-none">
  <div class="container">
    <div class="row">

      <div class="col-md-4">
        <img src="img/about_2.jpg" class="img-thumbnail" alt="">
      </div>

      <div class="col-md-8">
        <div class="cardxx card-bodyxx py-4">
          <h2> Why choose SRD Pharma? </h2>
          <ul class="pl-4">
            <li> We at SRD Pharma believe in becoming the most <strong>cost-effective, efficient, and dependable</strong> testing facility for drugs, water & food. </li>
            <li> The quality of our products is ensured by <strong>state-of-the-art analytical facilities</strong>. Our experienced chemists hard to provide excellent quality products. </li>
            <li> We make sure that our team performs without any kind of fear, pressure or prejudice. </li>
            <li> <strong>Customer satisfaction</strong> is of the highest priority at our company. That is why we have a dedicated team of professionals for customer service positioned to ensure customer satisfaction and technical support. </li>
          </ul>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- footer -->
<?php include('include/footer.php'); ?>