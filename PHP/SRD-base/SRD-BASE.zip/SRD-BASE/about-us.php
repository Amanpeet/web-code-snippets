<?php
  // set seo
  $title = "Chemical Manufacturer Supplier & Products Innovative Research | SRD Pharma";
  $description = "SRD Pharma is a global leader in Industrial chemical analysis, pharmacology, cannabis testing, synthesis and radiolabeling custom chemical services.";
  $keywords = "Chemical Testing, Pharmaceutical Testing, Microbiological Testing, Water Testing, Food Testing Labs near me, Drinking water testing lab near me, Chemical analysis lab";

  // header
  include('include/header.php');
?>

<div class="titlemon pt-4 pb-2">
  <div class="container text-center pt-4">
    <h1 class="text-dark"><strong> About us </strong></h1>
    <div><a href="index.php"> <small> <i class="fa fa-arrow-left"></i> BACK TO HOME</small></a> </div>
    <span class="line"></span>
  </div>
</div>

<section class="page-section py-5">
  <div class="container">
    <div class="card card-body text-center py-4">

      <h2> Know about SRD Pharma</h2>
      <img src="img/logo2.png" width="300" alt="" class="mx-auto my-3">
      <div class="text-center">
        <p>We are a accredited independent analytical laboratory with operations in North America, Canada, India, Middle East and Africa. Serving the best in the business among pharmaceuticals, food testing, neutralceuticals, water and industrial chemical analysis. Our expertise includes analysis of drugs, food products, organic materials, inorganic materials, water, oil, analytical method validation and process validation using advanced techniques of HPLC (with RI Detector UV detector, Fluorescence detector, Diode Array Detector, quaternary system with chiller) etc.</p>
      </div>
      <div class="text-center border-top mt-4 pt-4">
        <h4>Our Mission</h4>
        <p>To become market leaders in the pharmaceutical industry by always putting our customers first. </p>
        <h4>Our Values</h4>
        <p>Customer centricity, Quality, Innovation and Honesty. </p>
      </div>
    </div>
  </div>
</section>

<section class="page-section bg-light py-4 mb-5">
  <div class="container">
    <div class="row">

      <div class="col-md-4 pr-md-5">
        <img src="img/about_1.jpg" class="img-thumbnail" alt="">
      </div>

      <div class="col-md-8">
        <div class="cardxx card-bodyxx py-4">
          <h2> Certified Independent Analytical Laboratory </h2>
          <div class="text-left">
            <p>SRD Pharma is a certified independent analytical laboratory, serving the best in the business of pharmaceuticals. We also provide services in food testing, nutraceuticals, water and industrial chemical analysis. Our laboratory is equipped with superior quality modern scientific equipment for guaranteed precise results with four independent sections of Instruments, Chemicals, Microbiology and Food.</p>
            <p> Our highly trained team of analysts with years of experience across various technical fields ensure accurate results as fast as possible. The areas of our expertise include analysis of drugs, organic materials, food products, water, oil, inorganic materials, analytical method validation and process validationusing advanced techniques of HPLC (with RI Detector, UV detector, Diode Array Detector, Fluorescence detector, quaternary system with chiller), UV spectrophotometer, Atomic Absorption, GC (with Auto sampler & Head Space), FTIR, Spectrophotometer with Hydride generator, Dissolution, Liquid particle counter, Potentiometer, etc. </p>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>

<section class="page-section bg-light py-4 mb-5">
  <div class="container">
    <div class="row">

      <div class="col-md-8">
        <div class="cardxx card-bodyxx py-4">
          <h2> Why choose SRD Pharma? </h2>
          <ul class="pl-4">
            <li> We at SRD Pharma believe in becoming the most cost-effective, efficient, and dependable testing facility for drugs, water & food. </li>
            <li> The quality of our products is ensured by state-of-the-art analytical facilities. Our experienced chemists work hard to provide excellent quality products. </li>
            <li> We make sure that our team performs without any kind of fear, pressure or prejudice. </li>
            <li> Customer satisfaction is of the highest priority at our company. That is why we have a dedicated team of professionals for customer service positioned to ensure customer satisfaction and technical support. </li>
          </ul>
        </div>
      </div>

      <div class="col-md-4">
        <img src="img/about_2.jpg" class="img-thumbnail" alt="">
      </div>

    </div>
  </div>
</section>

<!-- footer -->
<?php include('include/footer.php'); ?>