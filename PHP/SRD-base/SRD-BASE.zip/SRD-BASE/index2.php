<?php
  // set seo
  $title = "Independent Analytical Laboratory & Chemicals Analysis & Testing Lab | SRD Pharma";
  $description = "SRD Pharma is analytical lab, we are manufacturers and distributors of pharma raw material - Impurities, Reference Standards, Working Standards and API.";
  $keywords = "food testing, water testing lab, microbiological testing, chemical testing laboratory, analytical lab, cosmetic testing, chemical analysis lab, food testing labs near me";
  // header
  include('include/header.php');
?>

<!-- popup -->
<div class="modal fade" id="popup" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Query Form</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

        <?php
        if (isset($_REQUEST['query_submit'])) {
          $captcha = $_REQUEST['g-recaptcha-response'];
          $handle = curl_init('https://www.google.com/recaptcha/api/siteverify');
          curl_setopt($handle, CURLOPT_POST, true);
          curl_setopt($handle, CURLOPT_POSTFIELDS, "secret=6LdlKaMUAAAAANhhKIJ6RumZ3qRFRGCFACjYFgOx&response=$captcha");
          curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
          $response = curl_exec($handle);
          $explodedArr = explode(",", $response);
          $doubleExplodedArr = explode(":", $explodedArr[0]);
          $captchaConfirmation = end($doubleExplodedArr);
          if (trim($captchaConfirmation) == "true") {
            $cleanedFrom = $_POST['email'];
            $to = 'sales@srdpharma.com, aspnetusername@gmail.com';
            $subject = 'Homepage New Query';
            $headers = "From: " . $cleanedFrom . "\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
            $message = '<html><body>';
            $message .= '<table rules="all" style="border-color: #035DAA;" cellpadding="10" width="450">';
            $message .= "<tr style='background: #17375e; color: #fff;'><td colspan='2'><strong>Homepage Query Form</strong></td></tr>";
            $message .= "<tr><td><strong>First Name:</strong> </td><td>" . $_POST['name'] . "</td></tr>";
            $message .= "<tr><td><strong>Phone:</strong> </td><td>" . $_POST['phone'] . "</td></tr>";
            $message .= "<tr><td><strong>Email:</strong> </td><td>" . $_POST['email'] . "</td></tr>";
            $message .= "<tr><td><strong>Message:</strong> </td><td>" . $_POST['message'] . "</td></tr>";
            $message .= "<tr style='background: #17375e;'><td colspan='2'>&nbsp;</td></tr>";
            $message .= "</table>";
            $message .= "</body></html>";
            $send = mail($to, $subject, $message, $headers);
            if ($send) {
              echo "<script> alert('Message Sent. Thank You!!!') </script>";
              echo "<script> window.location = 'index.php' </script>";
            } else {
              echo "<script> alert('Message Not Sent. Please try again') </script>";
              echo "<script> window.location = 'index.php' </script>";
            }
          } else {
            echo "<script> alert('Captcha entry was wrong. Please try again') </script>";
          }
        }
        ?>

        <form method="post" action="" name="query_form">
          <input name="request_type" id="l_request_type" value="" type="hidden">
          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="">Full Name</label>
              <input class="form-control" type="text" name="name" placeholder="john test" required>
            </div>
            <div class="form-group col-md-6">
              <label for="">Phone</label>
              <input class="form-control" type="text" name="phone" placeholder="00 0000 0000">
            </div>
          </div>
          <div class="form-group">
            <label for="">Email</label>
            <input class="form-control" type="email" name="email"  placeholder="example@mail.com" required>
          </div>
          <div class="form-group">
            <label for="">Message</label>
            <textarea class="form-control" name="message" placeholder="write to us"></textarea>
          </div>
          <!-- <div class="form-group">
            <div class="g-recaptcha" data-sitekey="6LdlKaMUAAAAAPdAsG-DB2cHibIvYS27lgXs-0S6"></div>
          </div> -->
          <div class="form-group">
            <input type="submit" name="query_submit" class="btn btn-primary" value="Submit" />
          </div>
        </form>

      </div>
    </div>
  </div>
</div>

<div class="hero-slide owl-carousel site-blocks-cover">
  <div class="intro-section" style="background-image: url('img/hero_1.jpg');">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-lg-12 mx-auto text-center" data-aos="fade-up">
          <h2>We are market leaders in the industry of pharmaceuticals</h2>
        </div>
      </div>
    </div>
  </div>
  <div class="intro-section" style="background-image: url('img/hero_2.jpg');">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-lg-12 mx-auto text-center" data-aos="fade-up">
          <span class="d-block"></span>
          <h2>Best High Quality <strong>Products</strong> in Class</h2>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="site-section services-1-wrap">
  <div class="container">
    <div class="row mb-5 justify-content-center text-center">
      <div class="col-lg-5">
        <h1 class="d-none">SRD Pharma</h1>
        <h3 class="section-subtitle">Services</h3>
        <h2 class="section-title mb-4 text-black">We are market leaders in the industry of pharmaceuticals</h2>
      </div>
    </div>
    <div class="row no-gutters">

      <div class="col-lg-4 col-md-6">
        <div class="service-1">
          <span class="number">01</span>
          <div class="service-1-icon">
            <span> <i class="fa fa-vials"></i> </span>
          </div>
          <div class="service-1-content">
            <h3 class="service-heading">Pharmaceutical Testing</h3>
            <p>We perform a variety of pharmaceutical testing to support quality processes in the pharmaceutical industry. </p>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-md-6">
        <div class="service-1">
          <span class="number">02</span>
          <div class="service-1-icon">
            <span> <i class="fa fa-flask"></i> </span>
          </div>
          <div class="service-1-content">
            <h3 class="service-heading">Cosmetic Testing</h3>
            <p>Cosmetics are required to be safe for the consumers to be used. We test various skincare and hair products. </p>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-md-6">
        <div class="service-1">
          <span class="number">03</span>
          <div class="service-1-icon">
            <span> <i class="fa fa-utensils"></i> </span>
          </div>
          <div class="service-1-content">
            <h3 class="service-heading">Food Testing</h3>
            <p>Food testing is of utmost importance to the efficient production of safe and quality products. </p>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-md-6">
        <div class="service-1">
          <span class="number">04</span>
          <div class="service-1-icon">
            <span> <i class="fa fa-tint"></i> </span>
          </div>
          <div class="service-1-content">
            <h3 class="service-heading">Water Testing</h3>
            <p>There are different types of tests that are done on water such as bacteria tests, pH tests, mineral tests, etc. </p>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-md-6">
        <div class="service-1">
          <span class="number">05</span>
          <div class="service-1-icon">
            <span> <i class="fa fa-microscope"></i> </span>
          </div>
          <div class="service-1-content">
            <h3 class="service-heading">Microbiological Testing</h3>
            <p>This testing process is paramount to minimize risk of potential damage by microbes to Microbiology testing process. </p>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-md-6">
        <div class="service-1">
          <span class="number">06</span>
          <div class="service-1-icon">
            <span> <i class="fa fa-book-reader"></i> </span>
          </div>
          <div class="service-1-content">
            <h3 class="service-heading">Education & Training</h3>
            <p>We provide 1 - 12 months chargeable trainings to students with a graduation or post-graduation degree. </p>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>

<div class="site-section bg-white">
  <div class="block-2">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 mb-4 mb-lg-0">
          <img src="img/about_1.jpg" alt="About SRD Pharma" class="img-fluid img-overlap" loading="lazy">
        </div>
        <div class="col-lg-5 ml-auto">
          <h3 class="section-subtitle">Why Choose Us</h3>
          <h2 class="section-title mb-4">More than 20 years of experience in the industry</h2>
          <p class="text-muted">We are an accredited independent analytical laboratory with operations in North America, Canada, India, Middle East and Africa. We are serving best in the business of pharmaceuticals, food testing, neutraceuticals, water and industrial chemical analysis.</p>
          <p class="text-muted">Our expertise includes analysis of drugs, food products, organic materials, inorganic materials, water, oil, analytical method validation and process validation using advanced techniques of HPLC (with RI Detector UV detector, Fluoroscence detector, Diode Array Detector, quaternary system with chiller) etc.</p>
          <a href="about-us.php" class="btn btn-primary mt-3">Know More</a>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="site-section bg-white pt-0">
  <div class="container">
    <div class="row">
      <div class="col-lg-4 align-self-end">
        <div class="card mb-4">
          <a href="refer-earn.php">
            <img src="img/refer.jpg" alt="Refer and Earn on SRD Pharma" class="w-100 d-nonexx d-lg-block" loading="lazy">
          </a>
        </div>
        <div class="card mb-4">
          <a href="become-reseller.php">
            <img src="img/seller.jpg" alt="Become a Seller on SRD Pharma" class="w-100 d-nonexx d-lg-block" loading="lazy">
          </a>
        </div>
      </div>
      <div class="col-lg-8 align-self-center">

        <div class="bg-black quote-form-wrap wrap text-white">
          <div class="mb-5">
            <h3 class="section-subtitle">Get A Quote</h3>
            <h2 class="section-title mb-4">Write to us</h2>
          </div>
          <form action="contact-us.php" method="POST" class="quote-form">
            <div class="row">
              <div class="col-md-6 form-group">
                <input type="text" class="form-control" name="name" placeholder="Name *" required>
              </div>
              <div class="col-md-6 form-group">
                <input type="text" class="form-control" name="phone" placeholder="Phone *" required>
              </div>
            </div>

            <div class="row">
              <div class="col-md-6 form-group">
                <input type="text" class="form-control" name="email" placeholder="Email *" required>
              </div>
              <div class="col-md-6 form-group">
                <input type="text" class="form-control" name="subject" placeholder="Subject *" required>
              </div>
            </div>

            <div class="row">
              <div class="col-md-6">
                <textarea name="" class="form-control" name="message" placeholder="Message *" rows="4"></textarea>
              </div>
              <div class="col-md-6 align-self-end">
                <input type="submit" name="mail_submit" class="btn btn-primary btn-block btn-lg" value="Send Message">
              </div>
            </div>

          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="site-section block-3">
  <div class="container">

    <div class="mb-5">
      <h3 class="section-subtitle">Our Products</h3>
      <h2 class="section-title mb-4">Explore Our <strong>Latest Products</strong></h2>
    </div>

    <div class="projects-carousel-wrap">
      <div class="owl-carousel owl-slide-3">

        <?php
          $items_per_page = 6;
          $select ="SELECT * FROM products ORDER BY pid DESC LIMIT $items_per_page ";
          $quer = mysqli_query($conn, $select);
          while($fetch = mysqli_fetch_array($quer)) {
            ?>
            <div class="project-item">
              <div class="project-item-contents">
                <a href="products-each.php?view=<?php echo $fetch['pid']; ?>">
                  <span class="project-item-category"> <?php echo $fetch['proMolecular']; ?> </span>
                  <h2 class="project-item-title"> <?php echo $fetch['proName']; ?> </h2>
                </a>
              </div>
              <img class="w-100" src="<?php echo 'adminize/uploads/'.$fetch['proImage']; ?>" alt="<?php echo $fetch['pid']; ?>" loading="lazy">
            </div>
            <?php
          }
        ?>
        <!-- <div class="project-item">
          <div class="project-item-contents">
            <a href="#">
              <span class="project-item-category">Category</span>
              <h2 class="project-item-title"> Product Name </h2>
            </a>
          </div>
          <img src="img/products/product1.png" alt="" class="img-fluid">
        </div> -->

      </div>
    </div>

  </div>
</div>

<div class="site-section bg-light pt-0">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-12 mb-5 text-left">
        <h3 class="section-subtitle">News</h3>
        <h2 class="section-title text-black mb-4">News &amp; <strong>Events</strong> </h2>
      </div>
    </div>
    <div class="row">

      <?php
        //Get latest blogs
        $items_per_page = 3;
        $blog_sql = "SELECT * FROM blog ORDER BY bid DESC LIMIT $items_per_page";
        $blog_query = mysqli_query($conn, $blog_sql);
        while($blog_row = mysqli_fetch_array($blog_query)) {
          $post_img = (!empty($blog_row['blog_image'])) ? $blog_row['blog_image'] : 'default.jpg';
          ?>
          <div class="col-md-6 mb-4 mb-lg-0 col-lg-4">
            <div class="blog-entry">
              <a href="blog-single.php?post=<?php echo $blog_row['bid']; ?>" class="img-link">
                <img class="homeblog-img" src="adminize/uploads/<?php echo $post_img; ?>" alt="<?php echo $blog_row['blog_title']; ?>" loading="lazy">
              </a>
              <div class="blog-entry-contents">
                <h3><a href="blog-single.php?post=<?php echo $blog_row['bid']; ?>"><?php echo $blog_row['blog_title']; ?></a></h3>
                <div class="meta"> <?php echo strip_tags( substr( $blog_row['blog_content'], 0, 60 ) ) . '...'; ?> </div>
              </div>
            </div>
          </div>
          <?php
        }
      ?>
      <!-- <div class="col-md-6 mb-4 mb-lg-0 col-lg-4">
        <div class="blog-entry">
          <a href="#" class="img-link">
            <img src="img/img4.jpg" alt="" class="img-fluid">
          </a>
          <div class="blog-entry-contents">
            <h3><a href="#">Top Companies That Are Best In Pharmaceutical Business</a></h3>
            <div class="meta"> Lorem, ipsum dolor sit amet consectetur adipisicing elit. </div>
          </div>
        </div>
      </div> -->

    </div>
  </div>
</div>

<div class="py-5 bg-primary block-4">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-lg-6">
        <h3 class="text-white"><strong>Get Reply</strong></h3>
        <p>Just leave us your email here & we will get back to you shortly. </p>
      </div>
      <div class="col-lg-6">
        <form action="response.php" method="post" class="form-subscribe d-flex">
          <input type="email" class="form-control form-control" name="sub_email" required>
          <input type="submit" class="btn btn-secondary px-4" name="sub_submit" value="SUBMIT">
        </form>
      </div>
    </div>
  </div>
</div>


<!-- footer -->
<?php include('include/footer.php'); ?>