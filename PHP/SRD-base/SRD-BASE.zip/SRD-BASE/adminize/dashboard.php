<?php include('inc/header.php'); ?>

<!-- page title -->
<div class="p-2 border-bottomxx">
  <h1> <strong>Welcome</strong> </h1>
  <p>Click on left sidebar links to get started.</p>
</div>

<!-- content & forms -->
<div class="p-2">
  <a class="btn btn-dark" href="https://www.srdpharma.com/products-all.php" target="_blank">View Products on Frontend</a>
</div>

<!-- include header -->
<?php include('inc/footer.php'); ?>