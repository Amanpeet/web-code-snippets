<div class="search-mod">
  <p>Enter Product #, CAS #, Chemical Name or Mol Formula:</p>
  <div class="search pt-0">
    <form action="/products-search.php" method="get">
      <div class="input-group mb-3">
        <input type="text" class="form-control" placeholder="advanced search" name="advanced">
        <div class="input-group-append">
          <button type="submit" class="btn btn-outline-secondary"><i class="fa fa-search"></i></button>
        </div>
      </div>
    </form>
  </div>
  <a class="btn btn-dark btn-sm" href="/products-search-category.php" title="">Search by Category <i class="fa fa-table"></i></a>
  <!-- <a class="btn" href="/products-search-parent.php" title="">Search by Parent Drug <i class="fa fa-box"></i></a> -->
</div>
