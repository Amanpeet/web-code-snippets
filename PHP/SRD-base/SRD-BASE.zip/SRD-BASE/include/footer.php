
    </div><!-- ./page-actual -->

    <!-- footer -->
    <div class="footer site-footer">
      <div class="container">
        <div class="row">
          <div class="col-lg-4">
            <p class="mb-4"><img src="<?php echo $siteurl; ?>/img/logo-wht.png" alt="Fundermax" width="250"></p>
            <p>Fundermax is certified independent analytical laboratory, serving the best in the business among pharmaceuticals, food testing, neutraceuticals, water and industrial chemical analysis.</p>
          </div>
          <div class="col-lg pl-lg-5">
            <h3 class="footer-heading"><span>Company</span></h3>
            <ul class="list-unstyled">
              <li><a href="<?php echo $siteurl; ?>/index.php">Home</a></li>
              <li><a href="<?php echo $siteurl; ?>/about-us.php">About us</a></li>
              <li><a href="<?php echo $siteurl; ?>/services.php">Services</a></li>
              <li><a href="<?php echo $siteurl; ?>/blog.php">News & Events</a></li>
            </ul>
          </div>
          <div class="col-lg">
            <h3 class="footer-heading"><span>Services</span></h3>
            <ul class="list-unstyled">
              <li><a href="<?php echo $siteurl; ?>/products-all.php">Products</a></li>
              <li><a href="<?php echo $siteurl; ?>/careers.php">Careers</a></li>
              <li><a href="<?php echo $siteurl; ?>/refer-earn.php">Refer & Earn</a></li>
              <li><a href="<?php echo $siteurl; ?>/become-reseller.php">Become Reseller</a></li>
            </ul>
          </div>
          <div class="col-lg">
            <h3 class="footer-heading"><span>Contact</span></h3>
            <ul class="list-unstyled">
              <li><a href="<?php echo $siteurl; ?>/contact-us.php">Contact us</a></li>
              <li><a href="<?php echo $siteurl; ?>/terms-conditions.php">Terms & Conditions</a></li>
              <li><a href="<?php echo $siteurl; ?>/privacy-policy.php">Privacy Policy</a></li>
            </ul>
          </div>
        </div>

        <div class="row">
          <div class="col-12">
            <div class="copyright">
              <p>
                Copyright &copy; 2021 All rights reserved. Powered by <a href="http://intiger.com/" target="_blank">Intiger Web</a>.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>
  <!-- .site-wrap -->

  <div class="fixed-note">
    <div class="note-item">
      <a href="#" title="Email" target="_blank"> <i class="fa fa-envelope"></i> </a>
    </div>
    <div class="note-item">
      <a href="#" title="Call" target="_blank"> <i class="fa fa-phone"></i> </a>
    </div>
    <div class="note-item">
      <a href="#" title="WhatsApp" target="_blank"> <i class="fab fa-whatsapp"></i> </a>
    </div>
    <div class="note-item">
      <a href="#" title="Facebook" target="_blank"> <i class="fab fa-facebook"></i> </a>
    </div>
    <div class="note-item">
      <a href="#" title="Linkedin" target="_blank"> <i class="fab fa-linkedin"></i> </a>
    </div>
    <div class="note-item">
      <a href="#" title="Twitter" target="_blank"> <i class="fab fa-twitter"></i> </a>
    </div>
    <div class="note-item">
      <a href="#" title="Instagram" target="_blank"> <i class="fab fa-instagram"></i> </a>
    </div>
  </div>

  <script src="<?php echo $siteurl; ?>/js/jquery.min.js"></script>
  <script src="<?php echo $siteurl; ?>/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo $siteurl; ?>/js/aos.js"></script>
  <script src="<?php echo $siteurl; ?>/js/owl.carousel.min.js"></script>
  <script src="<?php echo $siteurl; ?>/js/jquery.fancybox.min.js"></script>
  <script src="<?php echo $siteurl; ?>/js/select2.min.js"></script>
  <script src="<?php echo $siteurl; ?>/js/main.js"></script>

  <script src="<?php echo $siteurl; ?>/js/fontawesome.all.min.js" async></script>
  <script src="https://www.google.com/recaptcha/api.js" async></script>


  <script>
    $(document).ready(function() {
      console.log("footer jquery initilized.");

      // $('#popup').modal('show');

      // output msg
      var out = getParameterByName('var');
      if( out == 'success'){
        alert('Thanks for contacting us. We ll get back to you soon.');
        window.location.href = window.location.href.split('?')[0];
      } else if( out == 'error'){
        alert('There is an error in sending. Please check inputs.');
        window.location.href = window.location.href.split('?')[0];
      } if( out == 'invalid'){
        alert('Please fill all inputs with valid information.');
        window.location.href = window.location.href.split('?')[0];
      } else{
        console.log('query strings empty');
      }

      // select2
      $('.js-example-basic-multiple').select2();


    });//.document

    // function
    function getParameterByName(name, url) {
      if (!url) url = window.location.href;
      name = name.replace(/[\[\]]/g, "\\$&");
      var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
          results = regex.exec(url);
      if (!results) return null;
      if (!results[2]) return '';
      return decodeURIComponent(results[2].replace(/\+/g, " "));
    }
  </script>

</body>
</html>
