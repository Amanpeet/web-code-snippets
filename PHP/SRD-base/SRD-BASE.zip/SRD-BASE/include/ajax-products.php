<?php
// header
// include('include/header.php');
require('../adminize/inc/connection.php');

$prodArray = array();
if( isset($_REQUEST["search"]) || isset($_REQUEST["advanced"]) ) {

  // get vars
  $sname = trim( $_REQUEST["search"] );
  $sadvanced = trim( $_REQUEST["advanced"] );
  // $sname = $_REQUEST["search"];

  // the search cases
  $select = "";
  if( !empty($sname) ){
    $select ="SELECT * FROM products WHERE proName LIKE '%$sname%' ORDER BY proCode ASC  LIMIT 100";
  } else if( !empty($sadvanced) ) {
    $select ="SELECT * FROM products WHERE proCode LIKE '%$sadvanced%' OR proCasnum LIKE '%$sadvanced%' OR proChemical LIKE '%$sadvanced%' OR proMolecular LIKE '%$sadvanced%' ORDER BY proCode ASC LIMIT 100";
  } else {
    $select = "SELECT * FROM products ORDER BY proCode ASC LIMIT 100";
  }

  // echo 'Showing results for' . $_REQUEST['search'] . $_REQUEST['advanced'] ."<br>";

  // get resultset from query
  $quer = mysqli_query($conn, $select);
  if($result = mysqli_query($conn,$select)){
    if( mysqli_num_rows($result) > 0 ){

      $rowcount = mysqli_num_rows($result);
      // echo("Number of Rows found: ".$rowcount."<br><br>");

      while($fetch = mysqli_fetch_array($quer)){

        // $data = array();
        // $data['id'] = $fetch['pid'];
        // $data['text'] = $fetch['proName'];
        // $prodArray[] = $data;

        $prodArray[] = array(
          "id" => $fetch['pid'],
          "text" => $fetch['proName']
        );

        // echo $fetch['proName'];
        // echo $fetch['pid'];
        // echo $fetch['proCode'];
        // echo $fetch['proChemical'];
        // echo '<br>';
      }

    } else {
      // echo "No Products found!";
      $data1 = array();
      $data1['id'] = '0';
      $data1['text'] = 'No Products found';
      $prodArray[] = $data1;
    }
  }

} else {
  // echo "No Search criteria found!";
  // echo "No Products found!";
  $data2 = array();
  $data2['id'] = '0';
  $data2['text'] = 'No Search criteria found';
  $prodArray[] = $data2;
}

// final output
echo json_encode($prodArray);
exit();
