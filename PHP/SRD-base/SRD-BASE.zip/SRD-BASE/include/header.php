<?php include("adminize/inc/softcheck.php"); ?>
<?php
  $siteurl = "https://betweenfriends.in";
  $fileurl = ($_SERVER['REQUEST_URI']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title><?php echo empty($title) ? "Fundermax" : $title; ?></title>
  <link rel="icon" type="image/png" href="img/favicon.png">

  <meta name="author" content="Fundermax">
  <meta name="language" content="en-gb">
  <meta name="distribution" content="Global">
  <meta name="rating" content="General">
  <meta name="doc-type" content="Web Page">

  <meta name="keywords" content="<?php echo $keywords; ?>">
  <meta name="description" content="<?php echo $description; ?>">

  <!-- other meta tags -->
  <meta name="URL" content="<?php echo $siteurl . $fileurl; ?>">
  <link rel="canonical" href="<?php echo $siteurl . $fileurl; ?>">

  <!-- style sheets -->
  <link rel="stylesheet" href="<?php echo $siteurl; ?>/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo $siteurl; ?>/css/aos.css">
  <link rel="stylesheet" href="<?php echo $siteurl; ?>/css/owl.carousel.min.css">
  <link rel="stylesheet" href="<?php echo $siteurl; ?>/css/owl.theme.default.min.css">
  <link rel="stylesheet" href="<?php echo $siteurl; ?>/css/select2.min.css">
  <link rel="stylesheet" href="<?php echo $siteurl; ?>/css/style.css">

  <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@400;700&family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">

</head>
<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>

    <div class="header-top bg-white">
      <div class="container">
        <div class="row align-items-center no-gutters">

          <div class="col-6 col-lg-4">
            <a href="<?php echo $siteurl; ?>/index.php">
              <img src="<?php echo $siteurl; ?>/img/logo.png" alt="Fundermax" width="250">
            </a>
          </div>

          <div class="col-6 col-lg px-lg-5">
            <div class="quick-contact-icons d-flex">
              <div class="icon align-self-start ml-auto">
                <span class="text-primary"> <img src="<?php echo $siteurl; ?>/img/icons/quote.png" alt="Get Quote"> </span>
              </div>
              <div class="text">
                <span class="caption-text">Get Quote</span>
                <span class="h4 d-block"> <a href="<?php echo $siteurl; ?>/products-quote.php">Products Inquiry</a> </span>
              </div>
            </div>
          </div>

          <div class="col-lg mt-4 mt-lg-0 px-3 px-lg-0">
            <form class="mt-1" action="/products-search.php" method="get">
              <div class="input-group">
                <input type="text" class="form-control" placeholder="Find Products" name="search">
                <div class="input-group-append">
                  <button type="submit" class="btn btn-outline-secondary"><img src="<?php echo $siteurl; ?>/img/icons/search.png" alt="Search" width="19"></button>
                </div>
              </div>
            </form>
          </div>

          <!-- <div class="col-lg d-none d-lg-block pl-lg-5">
            <div class="quick-contact-icons d-flex">
              <div class="icon align-self-start">
                <span class="text-primary"> <img src="img/icons/phone.png" alt=""> </span>
              </div>
              <div class="text">
                <span class="caption-text">Call us</span>
                <span class="h4 d-block">+1 437-833-5485</span>
              </div>
            </div>
          </div> -->

          <!-- <div class="col-lg d-none d-lg-block">
            <div class="quick-contact-icons d-flex">
              <div class="icon align-self-start">
                <span class="text-primary"> <img src="img/icons/email.png" alt=""> </span>
              </div>
              <div class="text">
                <span class="caption-text">Email us</span>
                <span class="h4 d-block"> <a href="mailto:sales@srdpharma.com">sales@srdpharma.com</a> </span>
              </div>
            </div>
          </div> -->

        </div>
      </div>

      <div class="site-navbar">
        <div class="container">
          <div class="text-right navbar-dark d-block d-lg-none py-2 mr-4">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
          </div>
          <nav class="navbar navbar-expand-lg navbar-dark bg-darkxxx">
            <!-- <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button> -->
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                  <a class="nav-link" href="<?php echo $siteurl; ?>/index.php">Home </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="<?php echo $siteurl; ?>/about-us.php">About</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="<?php echo $siteurl; ?>/services.php">Services</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="<?php echo $siteurl; ?>/products-all.php">Products</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="<?php echo $siteurl; ?>/blog.php">News & Events</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="<?php echo $siteurl; ?>/careers.php">Careers</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="<?php echo $siteurl; ?>/contact-us.php">Contact</a>
                </li>
                <!-- <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Dropdown </a>
                  <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="#">Action</a>
                    <a class="dropdown-item" href="#">Another action</a>
                    <a class="dropdown-item" href="#">Something else</a>
                  </div>
                </li> -->
              </ul>
              <span class="navbar-text">
                <a class="nav-link" href="<?php echo $siteurl; ?>/track-your-shipment.php">Track Your Shipment</a>
              </span>
            </div>
          </nav>
        </div>
      </div>

    </div>

    <!-- page-actual -->
    <div class="page-actual bg-light">
