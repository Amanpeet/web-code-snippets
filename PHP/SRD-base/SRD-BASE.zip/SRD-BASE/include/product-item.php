<?php
//works only in while loop
$pic = $fetch['proImage'];
$datef = date('d M, Y', strtotime($fetch['pdate']));

//permalink
//https://www.srdpharma.com//products-each.php?view=10220
$plink = (!empty($fetch['plink'])) ? $fetch['plink'] : '';
$final_link = "";
if( !empty($plink) ){
  $final_link = "/products/".$plink;
} else {
  $final_link = "/products-each.php?view=".$fetch['bid'];
}
?>

<div class="card products-item mb-4">
  <div class="row no-gutters">
    <div class="col-md-4 p-4">
      <a href="products-each.php?view=<?php echo $fetch['pid']; ?>">
        <img class="card-img product-img" src="<?php echo 'adminize/uploads/'.$pic; ?>" alt="<?php echo $fetch['pid']; ?>">
      </a>
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h5 class="card-title"> <?php echo $fetch['proName']; ?> </h5>
        <div class="card-text">
          <p>
            <!-- Catalogue No: <span> <a class="btn btn-primary micro" href="products-each.php?view=<?php //echo $fetch['pid']; ?>"><?php //echo $fetch['proCatalogue']; ?> <i class="fa fa-search"></i> </a> </span><br> -->
            Product Code: <span> <strong><?php echo $fetch['proCode']; ?> </strong></span><br>
            Chemical Name: <span><strong> <?php echo $fetch['proChemical']; ?> </strong></span><br>
            CAS number: <span> <?php echo $fetch['proCasnum']; ?> </span><br>
            <!-- Alternate CAS: <span> <?php echo $fetch['proCasnumAlt']; ?> </span><br> -->
            Mol. Formula: <span> <?php echo $fetch['proMolecular']; ?> </span><br>
            <!-- Synonyms: <span> <?php echo $fetch['proSynonyms']; ?> </span><br> -->
          </p>
        </div>
        <!-- <a class="btn btn-primary btn-sm" href="products-each.php?view=<?php echo $fetch['pid']; ?>">View Details</a> -->
        <a class="btn btn-primary btn-sm" href="<?php echo $final_link; ?>">View Details</a>
      </div>
    </div>
  </div>
</div>
