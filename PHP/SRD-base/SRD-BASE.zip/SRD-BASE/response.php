<?php
  // set seo
  $title = "SRD Pharma";
  $keywords = "SRD Pharma";
  $description = "SRD Pharma";

  // header
  include('include/header.php');
?>

<div class="titlemon pt-4 pb-2">
  <div class="container text-center pt-4">
    <h1 class="text-dark"><strong> RESPONSE </strong></h1>
    <div><a href="index.php"> <small> <i class="fa fa-arrow-left"></i> BACK TO HOME</small></a> </div>
    <span class="line"></span>
  </div>
</div>

<div class="response-secion p-0">
  <div class="container text-center">
    <?php
      if (isset($_REQUEST['mail_submit'])) {

        $name  = strip_tags( $_POST['name'] );
        $email = strip_tags( $_POST['email'] );
        $phone = strip_tags( $_POST['phone'] );
        $msg   = strip_tags( $_POST['message'] );

        $to = "sales@srdpharma.com, ankush.mehra@srdpharma.com, amanpreet@intiger.in";
        $from = "mail@srdpharma.com";
        $subject = "Contact Form Query on Website";

        $message = "<html><head><title>Contact Form Query</title></head><body>";
        $message .= '<table rules="all" style="border:1px solid #ccc;" cellpadding="10">';
        $message .= "<tr> <td>Name</td> <td>".$name."</td> </tr>";
        $message .= "<tr> <td>Email</td> <td>".$email."</td> </tr>";
        $message .= "<tr> <td>Phone</td> <td>".$phone."</td> </tr>";
        $message .= "<tr> <td>Message</td> <td>".$msg."</td> </tr>";
        $message .= "</table>";
        $message .= "</body></html>";

        // Always set content-type when sending HTML email
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= 'From: <'.$from.'>' . "\r\n";
        $headers .= 'Reply-To: <'.$from.'>' . "\r\n";
        // $headers .= "CC: susan@example.com\r\n";

        $mail_check = mail($to, $subject, $message, $headers);
        if( $mail_check ){
          // echo "Mail Sent";
          ?>
            <div class="alert alert-success mt-4" role="alert">
              <h3> Thank you for contacting us.</h3>
              <h5> We will get back to you shortly.</h5>
            </div>
          <?php
        } else {
          // echo "Mail Failed";
          ?>
            <div class="alert alert-danger mt-4" role="alert">
              <h3> Error in sending message.</h3>
              <h5> Please try again later or Contact us manually.</h5>
            </div>
          <?php
        }
      }
    ?>
  </div>
</div>

<div class="response-secion p-0">
  <div class="container text-center">
    <?php
      if (isset($_REQUEST['sub_submit'])) {

        $email = strip_tags( $_POST['sub_email'] );

        $to = "sales@srdpharma.com, ankush.mehra@srdpharma.com, amanpreet@intiger.in";
        $from = "mail@srdpharma.com";
        $subject = "Email Inquiry Request on Website";

        $message = "<html><head><title>Instant Reply Query</title></head><body>";
        $message .= '<table rules="all" style="border:1px solid #ccc;" cellpadding="10">';
        $message .= "<tr> <td>Email</td> <td>".$email."</td> </tr>";
        $message .= "</table>";
        $message .= "</body></html>";

        // Always set content-type when sending HTML email
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= 'From: <'.$from.'>' . "\r\n";
        $headers .= 'Reply-To: <'.$from.'>' . "\r\n";
        // $headers .= "CC: susan@example.com\r\n";

        $mail_check = mail($to, $subject, $message, $headers);
        if( $mail_check ){
          // echo "Mail Sent";
          ?>
            <div class="alert alert-success mt-4" role="alert">
              <h3> Thank you for contacting us.</h3>
              <h5> We will get back to you shortly.</h5>
            </div>
          <?php
        } else {
          // echo "Mail Failed";
          ?>
            <div class="alert alert-danger mt-4" role="alert">
              <h3> Error in sending message.</h3>
              <h5> Please try again later or Contact us manually.</h5>
            </div>
          <?php
        }
      }
    ?>
  </div>
</div>

<section class="page-section py-5">
  <div class="container">
    <div class="card card-body text-center py-4">
      <!-- <h2> Check back later! </h2> -->
      <div class="text-center">
        <!-- <p> This website is currently under construction and content is being created. Please check back later. </p> -->
        <a class="btn btn-dark d-inline-block" href="index.php">Back to Home</a>
      </div>
    </div>
  </div>
</section>

<!-- footer -->
<?php include('include/footer.php'); ?>