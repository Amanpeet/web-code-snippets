<?php
  // set seo
  $title = "Global Market Leader in Pharmaceuticals | SRD Pharma";
  $description = "We at SRD Pharma believe that our biggest asset is our people. We offer an exciting and comfortable work environment to work and grow. Apply Now";
  $keywords = "Pharmaceutical Careers, Careers in pharma, Careers in pharmaceutical industry, Career in SRD Pharma, Chemical Analyst, Jobs for M.Pharma, Jobs in Pharma Industry";

  // header
  include('include/header.php');
?>

<div class="titlemon pt-4 pb-3">
  <div class="container text-center pt-4">
    <h1 class="text-dark"><strong> Careers </strong></h1>
    <div><a href="index.php"> <small> <i class="fa fa-arrow-left"></i> BACK TO HOME</small></a> </div>
    <span class="line"></span>
  </div>
</div>

<div class="response-secion p-0">
  <div class="container text-center">
    <?php
      if (isset($_POST['refer_submit'])) {

        $name    = strip_tags( $_POST['name'] );
        $experience = strip_tags( $_POST['experience'] );
        $country = strip_tags( $_POST['country'] );
        $email   = strip_tags( $_POST['email'] );
        $phone   = strip_tags( $_POST['phone'] );
        $msg     = strip_tags( $_POST['message'] );

        $to = "sales@srdpharma.com, ankush.mehra@srdpharma.com, amanpreet@intiger.in";
        // $to = "aspnetusername@gmail.com";
        $from = "mail@srdpharma.com";
        $subject = "Careers Form Registration on Website";

        $htmlMessage = "<html><head><title>Careers Form Registration</title></head><body>";
        $htmlMessage .= '<table rules="all" style="border:1px solid #ccc;" cellpadding="10">';
        $htmlMessage .= "<tr> <td>Name</td> <td>".$name."</td> </tr>";
        $htmlMessage .= "<tr> <td>Email</td> <td>".$email."</td> </tr>";
        $htmlMessage .= "<tr> <td>Phone</td> <td>".$phone."</td> </tr>";
        $htmlMessage .= "<tr> <td>Country</td> <td>".$country."</td> </tr>";
        $htmlMessage .= "<tr> <td>Experience</td> <td>".$experience."</td> </tr>";
        $htmlMessage .= "<tr> <td>Additional Details</td> <td>".$msg."</td> </tr>";
        $htmlMessage .= "</table>";
        $htmlMessage .= "</body></html>";

        // Always set content-type when sending HTML email
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= 'From: <'.$from.'>' . "\r\n";
        $headers .= 'Reply-To: <'.$from.'>' . "\r\n";
        // $headers .= "CC: susan@example.com\r\n";


        // send email with attachments if found
        $path = $_FILES['attachment']['tmp_name'];
        if (file($path)) { //path of file after moving

          $maxTotalAttachments = 2097152; //Maximum of 2 MB total attachments, in bytes
          $boundary_text = "anyRandomStringOfCharactersThatIsUnlikelyToAppearInEmail";
          $boundary = "--".$boundary_text."\r\n";
          $boundary_last = "--".$boundary_text."--\r\n";
          $emailAttachments = "";
          $totalAttachmentSize = 0;

          foreach ($_FILES as $file) {
            //In case some file inputs are left blank - ignore them
            if ($file['error'] == 0 && $file['size'] > 0) {
              $fileContents = file_get_contents($file['tmp_name']);
              $totalAttachmentSize += $file['size']; //size in bytes
              $emailAttachments .= "Content-Type: "
                . $file['type'] . "; name=\"" . basename($file['name']) . "\"\r\n"
                . "Content-Transfer-Encoding: base64\r\n"
                . "Content-disposition: attachment; filename=\""
                . basename($file['name']) . "\"\r\n"
                . "\r\n"
                . chunk_split(base64_encode($fileContents))
                . $boundary;
            }
          }

          if ($totalAttachmentSize == 0) {
            // echo "<strong> Mail Attachment Failed. </strong> ";
          } else {
            // Always set content-type when sending HTML email
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= 'From: <'.$from.'>' . "\r\n";
            $headers .= 'Reply-To: <'.$from.'>' . "\r\n";
            $headers .= "Content-Type: multipart/mixed; boundary=\"$boundary_text\"" . "\r\n";
            $final_message .= "If you can see this, your email client " ."doesn't accept MIME types!\r\n" .$boundary;
            $final_message .= $emailAttachments;
            $final_message .= "Content-Type: text/html; charset=\"iso-8859-1\"\r\n" ."Content-Transfer-Encoding: 7bit\r\n\r\n" .$htmlMessage . "\r\n" .$boundary_last;
            // echo "<strong> Mail Attachment Attached. </strong> ";
          }

        } else {
          echo "<strong> Mail Simply. </strong> ";
          // Always set content-type when sending HTML email
          $headers = "MIME-Version: 1.0" . "\r\n";
          $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
          $headers .= 'From: <'.$from.'>' . "\r\n";
          $headers .= 'Reply-To: <'.$from.'>' . "\r\n";
          // $headers .= "CC: susan@example.com\r\n";
          $final_message = $htmlMessage;
        }

        // send email
        if (mail($to, $subject, $final_message, $headers)) {
          // echo "Mail Sent";
          ?>
            <div class="alert alert-success mt-4" role="alert">
              <h3> Thank you for registering. </h3>
              <h5> We will get in touch with you soon.</h5>
            </div>
          <?php
        } else {
          // echo "Mail Failed";
          ?>
            <div class="alert alert-danger mt-4" role="alert">
              <h3> Error in sending message.</h3>
              <h5> Please try again later or Contact us manually.</h5>
            </div>
          <?php
        }

      }
    ?>
  </div>
</div>

<section class="page-section py-5">
  <div class="container">
    <div class="card card-body text-center py-4">

      <h2> Why choose SRD Pharma? </h2>
      <div class="text-center">
        <p> We at SRD Pharma believe that our biggest asset behind our growth is our people. We have a team of trained and experienced professionals working with us and we are proud of their passion and commitment towards their work and our company. We want our team members to share the same vision as us and help us provide superior quality products at affordable prices. </p>
        <p> It doesn’t matter if you join as an intern or an apprentice, if it’s you’re a fresher or an experienced professional we will try our best to help you develop and grow. It will be our aim to help you reach your maximum potential and utilize your skills. We will provide you opportunities to enrich your current skillset whilst improving your grasp of the business. </p>
        <p> As a team member of SRD Pharma, you will work with an inspiring and visionary leadership. We hope our company offers you an exciting and comfortable workplace environment to work and grow. </p>
      </div>

    </div>
  </div>
</section>

<section class="page-section pb-5">
  <div class="container">

    <div class="card card-body h-100">
      <div class="row">
        <div class="col-md-10 mx-auto mb-4">

          <h4 class="text-center">Fill up the form below & Get Enrolled with us!</h4>
          <p class="text-center">We are constantly on the look out for fresh B.Sc, M.Sc, B.Pharma &amp; M.Pharma candidates to work. <br> We also require experienced analysts for our ever expanding needs.</p>

          <form action="" method="POST" enctype="multipart/form-data">
            <div class="row form-group">
              <div class="col-md-12">
                <label class="text-black">Name</label>
                <input type="text" name="name" class="form-control" placeholder="your full name" required>
              </div>
            </div>
            <div class="row form-group">
              <div class="col-md-6">
                <label class="text-black">Email</label>
                <input type="email" name="email" class="form-control" placeholder="example@mail.com" required>
              </div>
              <div class="col-md-6">
                <label class="text-black">Phone</label>
                <input type="subject" name="phone" class="form-control" placeholder="phone number" required>
              </div>
            </div>
            <div class="row form-group">
              <div class="col-md-6">
                <label class="text-black">Experience</label>
                <input type="text" name="experience" class="form-control" placeholder="fresher or experienced">
              </div>
              <div class="col-md-6">
                <label class="text-black">Country</label>
                <input type="subject" name="country" class="form-control" placeholder="your country" required>
              </div>
            </div>
            <div class="row form-group">
              <div class="col-md-12">
                <label class="text-black">Additional Information</label>
                <textarea name="message" name="message" rows="2" class="form-control" placeholder="Why should we hire you?"></textarea>
              </div>
            </div>
            <div class="row form-group">
              <div class="col-md-12">
                <label class="text-black">Upload Resume/CV</label>
                <div class="custom-file">
                  <input type="file" class="custom-file-input" id="attachment" name="attachment">
                  <label class="custom-file-label" for="attachment">Choose file</label>
                </div>
                <small class="text-muted">* Max size allowed: 2MB, Format: pdf, docx</small>
              </div>
            </div>
            <div class="row form-group">
              <div class="col-md-12 text-center">
                <input type="submit" name="refer_submit" value="Submit" class="btn btn-primary py-2 px-4 text-white">
              </div>
            </div>
          </form>

        </div>
      </div>

    </div>


  </div>
</section>

<!-- footer -->
<?php include('include/footer.php'); ?>



