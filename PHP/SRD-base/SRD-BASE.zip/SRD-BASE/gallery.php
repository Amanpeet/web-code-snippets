<?php
// set seo
$title = "SRD Pharma";
$keywords = "SRD Pharma";
$description = "SRD Pharma";

// header
include('include/header.php');
?>

<div class="titlemon pt-4 pb-3">
  <div class="container text-center pt-4">
    <h1 class="text-dark"><strong> Gallery </strong></h1>
    <div><a href="index.php"> <small> <i class="fa fa-arrow-left"></i> BACK TO HOME</small></a> </div>
    <span class="line"></span>
  </div>
</div>

<section class="page-section py-5">
  <div class="container">
    <div class="card card-body text-center py-4">

      <div class="row">

        <?php
          /* DISPLAY ALL IMAGES FROM A FOLDER */

          //get site url
          $site_url = "http://" . $_SERVER['SERVER_NAME'] . dirname($_SERVER['PHP_SELF']);

          //gallery folder
          $dir = $_SERVER['DOCUMENT_ROOT'] . '/images/gallery/';

          $ImagesArray = [];
          $file_display = ['jpg', 'jpeg', 'png', 'JPG', 'JPEG', 'PNG'];

          if (file_exists($dir) == false) {
            echo  "Directory $dir not found!";
          } else {

            $dir_contents = scandir($dir);
            foreach ($dir_contents as $file) {
              $file_type = pathinfo($file, PATHINFO_EXTENSION);
              if (in_array($file_type, $file_display) == true) {
                $ImagesArray[] = $file;
              }
            }

            // DISPLAY ALL IMAGES
            foreach ($ImagesArray as $image) {
          ?>
              <div class="col-sm-4">
                <div class="in2">
                  <a href="<?php echo $site_url . 'images/gallery/' . $image; ?>" data-fancybox="gallery">
                    <img class="card-img-top" src="<?php echo $site_url . 'images/gallery/' . $image; ?>" alt="">
                  </a>
                </div>
              </div>
          <?php
            }
          }

        ?>
      </div>

    </div>
  </div>
</section>

<!-- footer -->
<?php include('include/footer.php'); ?>