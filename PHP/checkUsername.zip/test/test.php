<!-- little html to input name -->
<div>
	<input type="text" id="name_input" placeholder="input name here"><br>
	<button id="checkBtn" type="button">Press to Check</button><br>
	<pre id="response"></pre><br>
</div>


<!-- jquery scripts: this stays in your main file -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script>
$(document).ready(function(){

	//call checkUser on click
	$("#checkBtn").click(function(){
		var name = $("#name_input").val();
		//callling function
		checkUser(name);
	});

});

//ajax function to get user
function checkUser(name) {

	//here the path is needed, input path to your php file.
  var checkUserPath = "checkUser.php";

  //ajax call to php file
  $.ajax({
    url: checkUserPath,
    type: 'post',
    data: {
      "user_to_check": name
    },
    success: function(data, status) {
      /* Text to input in modal */
      console.log("Response from php file as json: " + data);
      //$("#response").html(data);
      var jdata = jQuery.parseJSON(data);
      status  = $.trim( jdata.status );
      console.log("Status: " + status);

      if(status == "exists"){
      	$("#response").html("Username Exists.");
      	//return true;
      } else if(status == "failed") {
      	$("#response").html("Username not found!");
      	//return false;
      }
    },
    error: function(xhr, desc, err) {
    	//in case of errors
      console.log(xhr);
      console.log("Details: " + desc + "\nError:" + err);
    },
    complete: function (data) {
      // if any function to run after completion
      console.log("Completed operation");
    }
  });
  // end ajax call

}

</script>