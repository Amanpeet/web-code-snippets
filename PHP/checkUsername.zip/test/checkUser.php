<?php

	if(isset($_POST['user_to_check'])) {

	  $user_to_check = $_POST['user_to_check'];

		$link = mysqli_connect("localhost", "root", "", "test");
		if (!$link) {
			die("Error when connecting to database");
		}

		//modified query to fetch username
		$query = "SELECT * FROM user WHERE name = '$user_to_check' ";

		//$table_globalSettings = mysqli_query($link, "SELECT * FROM global_settings");
		$result = mysqli_query($link, $query);

		if (!$result) {
			die("Error accessing database table");
		}
		else{
			if( mysqli_num_rows($result) > 0){
				//echo "results found";
				$array_data['status'] = 'exists';

				//if you want to display rows
				// while($row = mysqli_fetch_assoc($result)) {
				// 	echo "Found Name: ".$row['name'];
				// }

			}			
			else{
				//echo "Username doesnt exitst!";
				$array_data['status'] = 'failed';
			}
			
		}

		print_r(json_encode($array_data));

		mysqli_close($link);
		//No new line at end of file

	}

?>
