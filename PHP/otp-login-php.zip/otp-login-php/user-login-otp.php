<?php include("header.php");?>
<!-- check if user is already logged in -->
<?php
// session_start(); //already in header
if( isset($_SESSION['user_email']) ) {
  header("location: user-dashboard.php"); // Redirect
  echo '<script>window.location="user-dashboard.php";</script>';
}
?>

<!-- page-title -->
<section class="titlemon">
  <div class="container text-center pb-5">
    <h1>Login</h1>
    <div class="response text-success">
      <?php
      if(isset($_GET['response']) && !empty($_GET['response']) ){
        if( $_GET['response'] == '100' ){
          echo "<h4 class='text-danger'>Please Login / Register First to complete the action. You can do the payment before or after filling the required application forms.</h4>";
        } else {
          echo "<h4><strong>".$_GET['response']."</strong></h4>";
        }
      }
      ?>
    </div>
  </div>
</section>

<!-- page-content -->
<section class="page-section p-0">
  <div class="container">
    <div class="row">

      <div class="col-sm-6 mx-auto">
        <div class="card card-body">
          <form class="login p-4" method="post" action="include/login-usergetin-otp.php">
            <?php
              //retrieve error
              if(isset($_GET['error'])){
                echo '<h5 class="text-danger text-center">'.$_GET['error'].'</h5>';
              }
              //create new otp
              $new_otp = rand(1000,9999);
              $show_otp = rand(1000,9999).$new_otp.rand(10,99);
            ?>
            <input type="hidden" id="main_otp" name="main_otp" value="<?php echo $show_otp; ?>">
            <div class="mb-3">
              <label for="user_phone">Registered Phone</label>
              <div class="input-group">
                <input class="form-control" name="user_phone" id="user_phone" type="text" placeholder="phone" maxlength="12" required>
                <button type="button" id="send_otp_btn" class="btn btn-primary btn-outline-secondaryxx">Send OTP</button>
              </div>
              <div id="resend_otp_area" class="text-end text-muted" style="display:none;">
                <small>You can Resend OTP after <strong id="timer">30</strong> seconds.</small>
              </div>
            </div>
            <div class="mb-3">
              <label for="user_otp">Received OTP</label>
              <input class="form-control" name="user_otp" id="user_otp" type="text" placeholder="received OTP" maxlength="6" required>
            </div>
            <div class="mb-3 text-center">
              <p id="response_para" class="text-center text-danger font-strong mb-0"></p>
              <input class="btn btn-dark btn-lg px-5" type='submit' id='login_btn' name='loginhit' value='Login'>
            </div>
            <div class="pt-4 border-top border-dark">
              <!-- <a class="d-block mb-3" href="forgot-password.php">Forgot Password?</a></span> -->
              <p class="mb-0">If you are not registered, you can <a href="user-register.php"><strong>Register here</strong></a>.<br> Alternatively, you can use Email & Password to <a href="user-login.php"><strong>Login here</strong></a>. </p>
            </div>
          </form>
        </div>
      </div>

    </div>
  </div>
</section>

<script>
$(document).ready(function() {

  // disable buttons
  $('#login_btn').prop('disabled', true);
  // $('#send_otp_btn').prop('disabled', true);

  // otp click
  $('#send_otp_btn').click(function(e){
    e.preventDefault();
    $('#send_otp_btn').prop('disabled', true);
    $('#response_para').slideUp();
    $("#response_para").html("");

    var user_phone = $("#user_phone").val();
    var main_otp = $("#main_otp").val();

    $.ajax({
      type: "POST",
      url: "include/send-otp.php",
      dataType: "json",
      // data: $(this).serialize(),
      data: {user_phone:user_phone, main_otp:main_otp },
      success : function(response){
        console.log(response);
        $('#response_para').slideDown();
        $("#response_para").html(response.msg);
        // if code sent
        if (response.code == "200"){
          $('#resend_otp_area').slideDown();
          startTimer();
        } else {
          //enable send otp again
          $('#send_otp_btn').prop('disabled', false);
        }
      }
    });
    //enable btn
    $('#login_btn').prop('disabled', false);
  });

  // enable login
  $('#user_otp').keyup(function() {
    var dInput = this.value;
    // console.log(dInput);
    $('#login_btn').prop('disabled', false);
  });


});

// timer
function startTimer(){
  var secs = 30;
  var newsecs = secs;
  $('#timer').html(secs);
  var theTimer = setInterval(function(){
    newsecs = newsecs - 1;
    console.log(newsecs);
    if( newsecs >= 0 ){
      $('#timer').html(newsecs);
    } else {
      $('#send_otp_btn').prop('disabled', false);
      clearInterval(theTimer);
    }
  }, 1000);
}
</script>


<!-- footer -->
<?php include("footer.php"); ?>