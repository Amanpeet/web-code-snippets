<?php
/*
USER = httaxi
SENDERID = HTTAXI
DLT = 1201159488828138180

Template IDs:
SALESINVOICE = 1207165691144801852
OTPPREPAID = 1207165717915128480
OTPFORLOGIN = 1207165691136070000

SMS Type (accusage):
TRANSACTIONAL = 1
PROMOTINAL = 2
INVOICE = 5

OTPFORLOGIN
Your login OTP for Prepaid-Taxi is {#var#}. Do not share it with anyone. Visit prepaid.taxi for more info! PREPAID TAXI

OTPPREPAID
{#var#} is OTP to access your account. OTP is valid for {#var#} min. Do not share your OTP with anyone. PREPAID TAXI

SALESINVOICE:
Sales Invoice{#var#} of Rs.{#var#} has been recorded for you on {#var#}.
View Sales Invoice voucher: {#var#}{#var#}

Thank you,
PRE-PAID TAXI"
*/

// error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// msg
$phn = "918054269940";
$otp = rand ( 1000 , 9999 );
$msg = "Your login OTP for Prepaid-Taxi is ".$otp.". Do not share it with anyone. Visit prepaid.taxi for more info! PREPAID TAXI";

// set xml
$xml_data = '<?xml version="1.0"?>
<parent>
<child>
<user>httaxi</user>
<key>577d3f9a8eXX</key>
<mobile>'.$phn.'</mobile>
<message>'.$msg.'</message>
<accusage>1</accusage>
<senderid>HTTAXI</senderid>
<entityid>1201159488828138180</entityid>
<tempid>1207165691136071822</tempid>
</child>
</parent>';

//url
$URL = "msg.vadvertiseweb.com/submitsms.jsp?";

// curl
$ch = curl_init($URL);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_POST, TRUE);
curl_setopt($ch, CURLOPT_ENCODING, 'UTF-8');
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/xml'));
curl_setopt($ch, CURLOPT_POSTFIELDS, "$xml_data");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
$result = curl_exec($ch);

// check
if (curl_errno($ch)) {
  die('Couldn\'t send request: ' . curl_error($ch));
} else {
  $resultStatus = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  print_r( $resultStatus);

  if ($resultStatus != 200) {
    die('Request failed: HTTP status code: ' . $resultStatus);
  }
}

// close & print
curl_close($ch);
print_r($result);

print_r($xml_data);