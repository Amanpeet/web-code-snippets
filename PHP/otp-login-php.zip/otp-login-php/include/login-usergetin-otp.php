<?php
// error reporting
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

session_start();
// include_once('../backend/inc/connection.php');
include_once($_SERVER['DOCUMENT_ROOT']."/backend/inc/connection.php");

$error = "";
if(isset($_POST["loginhit"])) {

  if( empty($_POST["user_phone"]) || empty($_POST["main_otp"]) || empty($_POST["user_otp"]) ) {
    $error = "Some fields are missing.";
  } else  {
    $user_phone = $_POST['user_phone'];
    $main_otp = $_POST['main_otp'];
    $user_otp = $_POST['user_otp'];

    // To protect from MySQL injection
    $user_phone = stripslashes($user_phone);
    $main_otp = stripslashes($main_otp);
    $user_otp = stripslashes($user_otp);

    //filter phone
    $filtered_phone = filter_var($user_phone, FILTER_SANITIZE_NUMBER_INT);

    // verify data
    $phn = "";
    if( strlen($filtered_phone) == 10 ){
      $phn = "91".$filtered_phone;
    } elseif ( strlen($filtered_phone) == 12 ){
      $phn = $filtered_phone;
    } else {
      $error = "Phone number does not seem valid.";
    }
    // echo $phn;

    // verify otp
    $sent_otp = substr($main_otp,3,4);
    $received_otp = $user_otp;

    //min phone
    $sub_phn = substr($phn,2,11);

    //check otp
    if ( $sent_otp == $received_otp ){

      //Check username and password from database
      $sql = "SELECT * FROM `users` WHERE `user_phone`='$phn' OR `user_phone`='$sub_phn' ";
      $result = mysqli_query($conn,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      // echo $row['username'];
      //If exist in our database then create session else echo error.
      if( mysqli_num_rows($result) > 0 ) {
        // Initializing Session
        $_SESSION['user_id'] = $row['uid'];
        $_SESSION['user_email'] = $row['user_email'];
        $_SESSION['user_phone'] = $row['user_phone'];
        $_SESSION['user_fullname'] = $row['user_fullname'];
        header("location: ../user-dashboard.php");
        // echo '<script>window.location="../index.php";</script>';
      } else {
        $error = "This Phone Number is not Registered.";
        header("location: ../user-login-otp.php?error=".$error);
        // echo '<script>window.location="../user-login-otp.php";</script>';
      }

    } else {

      $error = "OTP is not correct. Please Try Again.";
      header("location: ../user-login-otp.php?error=".$error);
      // echo '<script>window.location="../user-login-otp.php";</script>';

    }


  }
}

print_r($error);
