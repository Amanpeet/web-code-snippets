<?php
// error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
// include_once('../backend/inc/connection.php');
include_once($_SERVER['DOCUMENT_ROOT']."/backend/inc/connection.php");

$output = "";
$code = "";
$error = "";

if( empty($_POST["user_phone"]) || empty($_POST["main_otp"]) ) {
  $code = 404;
  $output = "Some fields are missing.";
  $error = "user_phone or main_otp is missing";
} else  {

  //get inputs
  $user_phone = $_POST['user_phone'];
  $main_otp = $_POST['main_otp'];

  //filter phone
  $filtered_phone = filter_var($user_phone, FILTER_SANITIZE_NUMBER_INT);

  // verify data
  $phn = "";
  if( strlen($filtered_phone) == 10 ){
    $phn = "91".$filtered_phone;
  } elseif ( strlen($filtered_phone) == 12 ){
    $phn = $filtered_phone;
  } else {
    $code = 420;
    $output = "Phone number does not seem valid.";
    $error = "phone number is not valid";
  }

  // verify otp
  $otp = substr($main_otp,3,4);

  //proceed
  if( !empty($phn) && !empty($otp) ) {
    // msg
    $msg = "Your login OTP for Prepaid-Taxi is ".$otp.". Do not share it with anyone. Visit prepaid.taxi for more info! PREPAID TAXI";

    // set xml
    $xml_data = '<?xml version="1.0"?>
    <parent>
    <child>
    <user>httaxi</user>
    <key>577d3f9a8eXX</key>
    <mobile>'.$phn.'</mobile>
    <message>'.$msg.'</message>
    <accusage>1</accusage>
    <senderid>HTTAXI</senderid>
    <entityid>1201159488828138180</entityid>
    <tempid>1207165691136071822</tempid>
    </child>
    </parent>';

    //url
    $URL = "msg.vadvertiseweb.com/submitsms.jsp?";

    // curl
    $ch = curl_init($URL);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_POST, TRUE);
    curl_setopt($ch, CURLOPT_ENCODING, 'UTF-8');
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/xml'));
    curl_setopt($ch, CURLOPT_POSTFIELDS, "$xml_data");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    $result = curl_exec($ch);

    // check
    if (curl_errno($ch)) {
      die('Couldn\'t send request: ' . curl_error($ch));
      $error = 'Couldn\'t send request: ' . curl_error($ch);
    } else {
      $resultStatus = curl_getinfo($ch, CURLINFO_HTTP_CODE);
      // print_r( $resultStatus);
      if ($resultStatus != 200) {
        die('Request failed: HTTP status code: ' . $resultStatus);
        $error = 'Request failed: HTTP status code: ' . $resultStatus;
      }
    }

    // close & print
    curl_close($ch);
    // print_r($result);

    $code = 200;
    $output = "OTP Sent Successfully. Please check your phone.";

  }


}

echo json_encode([ 'code'=>$code, 'msg'=>$output, 'err'=>$error ]);
// echo json_encode($response);
