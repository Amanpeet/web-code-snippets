<?php
  // set seo
  $title = "Shimla Camping | Adventure Camping | Eco Certified Camps & Resorts";
  $keywords = "Shimla Camping, Adventure Camping in Shimla, Camping in Shimla, Forest Camping in Shimla , Shimla Hotels, Hotels of Shimla, Honeymoon in Shimla, Camp Mashobra Greens, Shimla Camp Sites, Adventure in Shimla, Adventure Camps Near Shimla, Shimla Camps, Camping Near Shimla, Camping Around Shimla, Camping in Shimla Shimla India Hotels, Shimla India,  Camp Mashobra Greens, Camp Green Mashobra";
  $description = "Welcome to avalanche adventures & eco certified camps & resorts in Shimla. Mashobra Greens provides programs like camping, trekking, rafting & summer camps.";

  // header //
  include 'include/header.php';
?>

<section class="slider">
  <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="4"></li>
    </ol>
    <div class="carousel-inner" role="listbox">
      
      <div class="carousel-item active">
        <img src="images/banner-2.jpg" alt="banner-1.png">
    
      </div>
      <div class="carousel-item">
        <img src="images/banner-3.jpg" alt="banner-1.png">
        <!--<div class="carousel-caption d-none d-md-block">
          <h1>Welcome to  Avalanche Adventures</h1>
          <h2>Eco Certified Camps & Resorts</h2>
          <p>Mashobra Greens rated "excellent" by 38 travellers</p>
          <a class="btn btn-lg btn-primary" href="aboutus.php" role="button">Learn more</a>
        </div>-->
      </div>
      <div class="carousel-item">
        <img src="images/banner-4.jpg" alt="banner-1.png">
   
      </div>
      <div class="carousel-item">
        <img src="images/banner-5.jpg" alt="banner-1.png">  
 
      </div>

      <div class="carousel-item ">
        <img src="images/banner-1.jpg" alt="banner-1.png">
     
      </div>
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>

</section>
<!-- about-us -->
<section class="in-div about-us">
  <h1>About Us</h1>
  <div class="container">
    <div class="row">
      <div class="col-sm-6">
        <h2>Mashobra Greens</h2>
        <p>A perfect place to unravel. Away from the crowded city you would find solitude in the cedar forest surrounded by the enchanting fragrance of the wilderness and the weather is just right (between 10 to 20 degree Celsius)to rejuvenate your mind body and soul where you will find the much needed peace and quiet away from the everyday hustle and rush of the city. Just cool breezes, lovely sunsets and quiet mountains.</p>
        <h2>Our Mission</h2>
        <p>We at Camp Mashobra Greens are committed to an organization of trust, providing staunch and quality services to meet all the desired needs of the customers. We aim at achieving optimum customer's satisfaction through highly motivated employees' involvement and well established continual quality management systems. </p>
        <a href="aboutus.php">Read More</a>
      </div>
      <div class="col-sm-6">
        <img src="images/about-img.jpg" alt="about-img">
      </div>
    </div>
  </div>
</section>
<!-- gallery -->
<section class="in-div gallery">
  <h1>Our Gallery</h1>
  <div class="gallery-in">
    <div class="container">
      <div class="row">
        <div class="col-sm-3">
          <img src="images/gallery/gallery-1.jpg" alt="gallery">
        </div>
        <div class="col-sm-3">
          <img src="images/gallery/gallery-2.jpg" alt="gallery">
        </div>
        <div class="col-sm-3">
          <img src="images/gallery/gallery-3.jpg" alt="gallery">
        </div>
        <div class="col-sm-3">
          <img src="images/gallery/gallery-4.jpg" alt="gallery">
        </div>
        <div class="col-sm-3">
          <img src="images/gallery/gallery-5.jpg" alt="gallery">
        </div>
        <div class="col-sm-3">
          <img src="images/gallery/gallery-6.jpg" alt="gallery">
        </div>
        <div class="col-sm-3">
          <img src="images/gallery/gallery-7.jpg" alt="gallery">
        </div>
        <div class="col-sm-3">
          <img src="images/gallery/gallery-8.jpg" alt="gallery">
        </div>
        <p> <a href="gallery.php">View All <i class="fas fa-arrow-right"></i></a> </p>
      </div>
    </div>
  </div>
</section>
<!-- special-packages -->
<section class="in-div special-packages">
  <h1>Special Packages</h1>
  <div class="container">
    <div class="row">
      <div class="col-sm-6 col-md-4">
        <div class="test">
          <img src="images/special-packages-1.jpg" alt="special-packages">
          <h3>Bamboo Cottage <br> <b> 1 Night/ 2 Days</b></h3>
          <p><b>4000-7500 INR</b> </p>
          <span><i class="fas fa-shopping-cart"></i> <a href="our-packages.php">See Package</a></span>
        </div>
      </div>
      <div class="col-sm-6 col-md-4">
        <div class="test">
          <img src="images/special-packages-2.jpg" alt="special-packages">
          <h3>Swiss Tent <br> <b> 1 Night/ 2 Days</b></h3>
          <p><b>4000-4500 INR</b> </p>
          <span><i class="fas fa-shopping-cart"></i> <a href="our-packages.php">See Package</a></span>
        </div>
      </div>
      <div class="col-sm-6 col-md-4">
        <div class="test">
          <img src="images/special-packages-3.jpg" alt="special-packages">
          <h3>Mud Cottage <br><b>1 Night/ 2 Days</b></h3>
          <p><b> 6500-7500 INR</b></p>
          <span><i class="fas fa-shopping-cart"></i> <a href="our-packages.php">See Package</a></span>
        </div>
      </div>
    </div>
  </div>
</section>
<!--book-now"-->
<div class="container">
  <div class="book-now">
    <div class="row">
      <div class="col-sm-7">
        <h4>Book your special package today!</h4>
      </div>
      <div class="col-sm-5">
        <a id="myBtn" href="#">Book Now</a>
      </div>
    </div>
  </div>
</div>
<!--  testimonials -->
<section id="demos" class="in-div main-testimonials">
  <h1>Testimonials</h1>
  <div class="testimonials">
    <div class="container">
      <div class="row">
        <div class="large-12 columns">
          <div class="owl-carousel owl-theme">
            <div class="item">
              <span><img src="images/client-1.jpg" alt="client"></span>
              <p>The Mashobra Greens provide a choice to challenge your limits with Varity of mountaineering adventure activities run by experts and certified professionals for every one .</p>
              <h4>Don MacDomaid</h4>
            </div>
            <div class="item">
              <span><img src="images/client-2.jpg" alt="client"></span>
              <p>The Mashobra Greens provide a choice to challenge your limits with Varity of mountaineering adventure activities run by experts and certified professionals for every one .</p>
              <h4>Julia Day</h4>
            </div>
            <div class="item">
              <span><img src="images/client-3.jpg" alt="client"></span>
              <p>The Mashobra Greens provide a choice to challenge your limits with Varity of mountaineering adventure activities run by experts and certified professionals for every one .</p>
              <h4>Nate Polla</h4>
            </div>
            <div class="item">
              <span><img src="images/client-1.jpg" alt="client"></span>
              <p>The Mashobra Greens provide a choice to challenge your limits with Varity of mountaineering adventure activities run by experts and certified professionals for every one .</p>
              <h4>Don MacDomaid</h4>
            </div>
            <div class="item">
              <span><img src="images/client-2.jpg" alt="client"></span>
              <p>The Mashobra Greens provide a choice to challenge your limits with Varity of mountaineering adventure activities run by experts and certified professionals for every one .</p>
              <h4>Julia Day</h4>
            </div>
            <div class="item">
              <span><img src="images/client-3.jpg" alt="client"></span>
              <p>The Mashobra Greens provide a choice to challenge your limits with Varity of mountaineering adventure activities run by experts and certified professionals for every one .</p>
              <h4>Nate Polla</h4>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- contacts-us-->
<section class="in-div contacts-us">
  <div class="container">
    <div class="row">
      <div class="col-sm-7">
        <h1>Contact Us</h1>
        <form enctype="multipart/form-data" method="post" action="">
          <div class="row">
            <div class="form-group col-sm-6">
              <label for="text">First Name:</label>
              <input class="input" required placeholder="" name="cname" type="text">
            </div>
            <div class="form-group col-sm-6">
              <label for="text">Last Name:</label>
              <input class="input" required placeholder="" name="cname" type="text">
            </div>
            <div class="form-group col-sm-6">
              <label for="text">Email Address:</label>
              <input class="input" required placeholder="" name="cemail" type="email">
            </div>
            <div class="form-group col-sm-6">
              <label for="text">Phone:</label>
              <input class="input" required placeholder="" name="cphone" type="text">
            </div>
            <div class="form-group col-sm-12">
              <label for="text">Message:</label>
              <textarea rows="4" class="input1" placeholder="" rows="" cols="" name="cmessage" type="text"></textarea>
            </div>
            <div class="form-group col-sm-12">
              <input value="Submit" name="submit" class="m-bt pull-right" type="submit">
            </div>
          </div>
        </form>
        <h5>
            <?php
            if(isset($_POST["submit"])){
              // Checking For Blank Fields
              if($_POST["cname"]==""||$_POST["cemail"]==""||$_POST["cphone"]==""||$_POST["cmessage"]==""){
                echo "Fill all fields. Please try again with valid info.";
              } else {
                // Check if the "Sender's Email" input field is filled out
                $email=$_POST['cemail'];
                $email =filter_var($email, FILTER_SANITIZE_EMAIL);
                $email= filter_var($email, FILTER_VALIDATE_EMAIL);
                if (!$email){
                  echo "Invalid Email detected. Please try again with valid info.";
                }
                else{
                  // Compose the email message to send
                  $to = "globusinteriorschd@gmail.com";
                  $from = $_POST['cemail'];
                  $subject = "New Enquiry Form";
                  $headers = 'From:'. $from . "\r\n";
                  $message = "Name: " . $_POST['cname'] . "\r\n";
                  $message .= "Email: " . $_POST['cemail'] . "\r\n";
                  $message .= "Phone: " . $_POST['cphone'] . "\r\n\r\n";
                  $message .= "Query: " .$_POST['cmessage'];
                  // Send Mail By PHP Mail Function
                  if(mail($to, $subject, $message, $headers) ){
                    echo "Message sent successfully!<br> We will contact to you soon.";
                  } else {
                    echo "Message sending failed!<br> Please try again later.";
                  }
                }
              }
            }
            ?>
            </h5>
      </div>
      <div class="col-sm-5 details">
        <h1>Details</h1>
        <div class="in">
          <h3><i class="fas fa-map-marker"></i> Mashobra Greens</h3>
          <p>A unit of Avalanche adventures Village Shipur Mashobra Shimla 171007</p>
          <p><i class="fas fa-phone"></i> <a href="tel:09418265001"> 09418265001</a>, <a href="tel:09418015636">09418015636</a>, <a href="tel:09216123999">09216123999</a></p>
          <h3><i class="fas fa-map-marker"></i> Chandigarh</h3>
          <p>Mashobra Greens
            <br> S.C.O 56-57 First Floor Sector 9 -D Madhya Marg</p>
          <p><i class="fas fa-phone"></i> <a href="tel:01725075664">0172- 5075664</a>, <a href="tel:01725075665">5075665</a>, <a href="tel:9216111791">9216111791</a></p><a href="tel:9216111791"></a><i class="fas fa-envelope"></i>
          <p><a href="tel:9216111791"></a><a href="mailto:info@shimlacamping.com">info@shimlacamping.com</a>
            <br>
            </p>  
          <p> <i class="fas fa-link"></i>   
<a href="http://www.shimlacamping.com/">www.shimlacamping.com</a>
          </p>
        </div>
      </div>
    </div>  

    <!-- The Modal -->
    <div id="myModal" class="modal">
      <!-- Modal content -->
      <div class="modal-content contacts-us ">
        <div class="modal-header">
          <h2>Book Now</h2>
          <span class="close">×</span>
        </div>
        <div class="row">
          <div class="form-group col-sm-12">
            <label for="text">Name</label>
            <input class="form-control" id="email" type="text">
          </div>
          <div class="form-group col-sm-12">
            <label for="text">Address:</label>
            <input class="form-control" id="pwd" type="rext">
          </div>
          <div class="form-group col-sm-12">
            <label for="text">Phone:</label>
            <input class="form-control" id="pwd" type="text">
          </div>
          <div class="form-group col-sm-12">
            <label for="text">Email Address:</label>
            <input class="form-control" id="pwd" type="text">
          </div>
          <div class="form-group col-sm-12">
            <label for="texr">Message:</label>
            <textarea rows="4" cols="50"></textarea>
          </div>
          <div class="col-sm-12">
            <button type="submit" class="btn btn-default">Submit</button>
          </div>
        </div>   
      </div> 
    </div>
  </div>
</section>

<?php include 'include/footer.php';?>