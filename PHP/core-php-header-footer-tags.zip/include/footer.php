<!-- footer -->
<footer class="main-footer">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-4 footer-logo">
                <a href="index.php"><img src="images/logo-f.png" alt="logo"></a>
                <p>Discover thrilling experience in the midst of mountains in the profound wilderness of mountains that provides acclaimed programs like camping, Discover thrilling experience in the midst provides acclaimed programs like camping,</p>
            </div>
            <div class="col-sm-12 col-md-4  fot-nav">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="index.php">Home </a></li>
                    <li><a href="gallery.php">GALLERY </a></li>
                    <li><a href="aboutus.php">About Us</a></li>
                    <li><a href="features.php">Features </a></li>
                    <li><a href="accommodation.php">Accommodation</a></li>
                    <li><a href="about-himachal.php">About Himachal</a></li>
                    <li><a href="our-packages.php">OUR PACKAGES</a></li>
                    <li><a href="route-distance.php">Route Distance </a></li>
                    <li><a href="activities.php">ACTIVITIES</a></li>
                    <li><a href="contact-us.php">Contact us</a></li>
                </ul>
            </div>
            <div class="col-sm-12 col-md-4 fot-right">
                <h3>Follow Us</h3>
                <ul class="fot-socal-icon">
                    <li><a target="_blank" href="https://www.facebook.com/MashobraGreens"><img src="images/fb.png" alt="fb"></a></li>
                    <li><a target="_blank" href="http://mashobragreens.blogspot.in/"><img src="images/blogspot.png" alt="in"></a></li>
                </ul>
                <form method="post">
                    <input name="newsemail" placeholder="info@shimlacamping.com" required="" type="email">
                    <input name="newssubmit" value="Subscribe" type="submit">
                </form>
            </div>
        </div>
    </div>
</footer>
<div class="last-fot">
    <div class="container">
        <p>All rights reserved. Copyright © 2018. Website designed by <a target="block" href="http://www.intiger.com/">intiger.com</a></p>
    </div>
</div>
<!-- script -->
<script src="net/jquery.min.js"></script>
<script src="net/owl.carousel.js"></script>
<script src="js/jquery.fancybox.min.js"></script>
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>

</body>
</html>