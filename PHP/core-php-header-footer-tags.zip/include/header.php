<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <!-- essentials -->
    <title>
        <?php echo empty($title) ? "Shimla Camping" : $title; ?>
    </title>
    <link rel="icon" type="image/png" href="images/favicon.png" />
    
    <!-- from the pages -->
    <meta name="keywords" content="<?php echo $keywords; ?>" />
    <meta name="description" content="<?php echo $description; ?>" />

    <!-- Bootstrap -->
    <link rel="stylesheet" href="css/carousel.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/fontawesome-all.min.css">
    <link rel="stylesheet" href="net/owl.carousel.min.css">
    <link rel="stylesheet" href="css/animate.css.css">
    <link rel="stylesheet" href="css/jquery.fancybox.min.css ">
</head>

<body>
    <header class="main-header">
        <div class="top-header">
            <div class="container">
                <div class="row">
                    <div class="col-sm-4">
                        <a href="index.php"><img src="images/logo.png" alt="logo"></a>
                    </div>
                    <div class="col-sm-4">
                        <div class="center">
                            <h3>Bravo! </h3>
                            <p> <a target="_blank" href="https://www.tripadvisor.in/Hotel_Review-g1156032-d1952674-Reviews-Mashobra_Greens-Mashobra_Shimla_District_Himachal_Pradesh.html">Mashobra Greens rated "excellent" by 38 travellers TripAdvisor</a></p>
                            <a target="_blank" href="https://www.tripadvisor.in/"><img src="images/tripadvisor_logo_115x18.png" alt="tripadvisor_logo_115x18"></a>
                        </div>
                    </div>
                    <div class="col-sm-4 header-right">
                        <p><a href="mailto:info@shimlacamping.com"><span><img src="images/mailto.png" alt="mailto"></span>info@shimlacamping.com</a></p>
                        <p><a href="tel:9418265001"><span><img src="images/call.png" alt="call"></span> +91 9418265001</a>
                            <br>
                            <a class="none" href="tel:09418015636">+91 9418015636</a>
                            <br>
                            <a class="none" href="tel:09216123999">+91 9216123999 </a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <nav class="navbar navbar-expand-md navbar-dark bg-dark">
            <div class="container">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item active"><a href="index.php">Home </a></li>
                        <li class="nav-item"><a class="nav-link disabled" href="aboutus.php">About Us</a></li>
                        <li class="nav-item"><a class="nav-link disabled" href=" accommodation.php">Accommodation</a></li>
                        <li class="nav-item"><a class="nav-link disabled" href="our-packages.php">OUR PACKAGES</a></li>
                        <li class="nav-item"><a class="nav-link disabled" href="activities.php">ACTIVITIES</a></li>
                        <!--<li class="nav-item"><a class="nav-link disabled" href="testimonials.php">TESTIMONIALS </a></li>-->
                        <li class="nav-item"><a class="nav-link disabled" href="gallery.php">GALLERY </a></li>
                        <li class="nav-item"><a class="nav-link disabled" href="contact-us.php">Contact us</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>