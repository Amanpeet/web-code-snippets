<?php
if (!defined('FTP_CLIENT_TEST_VENDOR')) {
    define('FTP_CLIENT_TEST_VENDOR', __DIR__ . '/../../../');
}

$loader = require_once FTP_CLIENT_TEST_VENDOR . '/autoload.php';
