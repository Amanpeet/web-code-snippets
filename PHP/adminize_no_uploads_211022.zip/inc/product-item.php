<?php
//works only in while loop
$pic = $fetch['proImage'];
$datef = date('d M, Y', strtotime($fetch['pdate']));
?>
<div class="products-item">
  <div class="row">
    <div class="col-4">
      <a href="products-each.php?view=<?php echo $fetch['pid']; ?>">
        <img class="product-img" src="<?php echo 'adminize/uploads/'.$pic; ?>" />
      </a>
    </div>
    <div class="col-8">
      <!-- Catalogue No: <span> <a class="btn btn-primary micro" href="products-each.php?view=<?php //echo $fetch['pid']; ?>"><?php //echo $fetch['proCatalogue']; ?> <i class="fa fa-search"></i> </a> </span><br> -->
      Product Code: <span> <a class="btn btn-primary micro" href="products-each.php?view=<?php echo $fetch['pid']; ?>"><?php echo $fetch['proCode']; ?> <i class="fa fa-search"></i> </a> </span><br>
      Chemical Name: <span><strong> <?php echo $fetch['proChemical']; ?> </strong></span><br>
      CAS number: <span> <?php echo $fetch['proCasnum']; ?> </span><br>
      Alternate CAS: <span> <?php echo $fetch['proCasnumAlt']; ?> </span><br>
      Mol. Formula: <span> <?php echo $fetch['proMolecular']; ?> </span><br>
      Synonyms: <span> <?php echo $fetch['proSynonyms']; ?> </span><br>
      <a class="link" href="products-each.php?view=<?php echo $fetch['pid']; ?>"><strong>View Details</strong> </a>
    </div>
  </div>
</div>