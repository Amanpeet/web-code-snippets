
          <!-- content goes here -->
        </div>
      </div>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <footer class="sticky-footer">
      <div class="container">
        <div class="text-center">
          <small>&copy; Copyrights 2018. Handcrafted by Intiger Web</small>
        </div>
      </div>
    </footer>
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
    </a>
    <!-- Logout Modal-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Click "Logout" below if you want to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="inc/logout.php">Logout</a>
          </div>
        </div>
      </div>
    </div>

  <!-- others JavaScript-->
  <script src="js/bootstrap.bundle.min.js"></script>
  <script src="js/jquery.easing.min.js"></script>
  <script src="js/custom-admin.js"></script>

  <!-- datepicker -->
  <!-- <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css"> -->
  <!-- <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script> -->
  <script>
    $(document).ready(function() {
      console.log("footer jquery initilized.");

      //datepicker
      // $(".datepickery").datepicker({
      //   changeMonth: true,
      //   changeYear: true,
      // });

      //max file size
      $('form.file-form').submit(function(){
        var isOk = true;
        $('input[type=file]').each(function(){
          if(typeof this.files[0] !== 'undefined'){
            // var maxSize = parseInt($(this).attr('max-size'), 10);
            var maxSize = 2*1024*1024; //2MB
            var size = this.files[0].size;            
            if( size > maxSize ) {
              alert('Files Size Limit Exceeded. Max File Size Allowed: 2 MB for each file.');
              isOk = false;
              return isOk; 
            }
          }
        });
        return isOk;
      });

      //add input
      $('#addpack').click(function(e){
        e.preventDefault();
        var getdata = parseInt( $('#packbox').find('input:last-child').attr('data-pack') );
        var newdata = getdata + 1;
        if( newdata < 11 ){
          var newinput = '<input type="text" class="form-control mt-1" name="proPack'+newdata+'" placeholder="00mg ('+newdata+')" data-pack="'+newdata+'">';
          $('#packbox').append(newinput);
        } else {
          alert('Packs limit exceeded. Max Allowed is 10.');
        }
      });

      //generate code
      $('#productname').keyup(function(e){
        gencode();
      });
      $('#productname').change(function(e){
        gencode();
      });
      $('#gencode').click(function(e){
        $('#productcode').attr('readonly', false);
        // gencode();
      });
      function gencode(){
        var getname = $('#productname').val();
        getname = getname.replace(/[^a-z]/gi, '');
        getname = getname.charAt(0).toUpperCase();
        var getlast = $('#productcode').attr('data-last');
        var finalcode = getname + getlast;
        $('#productcode').val(finalcode);
        console.log('Code Generated');
      }


    });
  </script>
</body>
</html>
