<?php
// Include the Composer autoload file
// require __DIR__ . '/vendor/autoload.php';

/*
imap.gmail.com:993 and the POP server at pop.gmail.com:995
smtp.gmail.com
supports TLS
STARTTLS command, use port 465 (for SSL), or port 587
*/


//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require 'vendor/autoload.php';

//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);

try {
  //Server settings

  $mail->SMTPDebug = SMTP::DEBUG_SERVER;
  $mail->isSMTP();
  $mail->Host       = 'mail.smtp2go.com';
  $mail->SMTPAuth   = true;
  $mail->Username   = 'coachrakeshverma.com';
  $mail->Password   = '3UQm4cjFgbrNr5Um';
  // $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
  $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
  $mail->Port       = 587;

  // Set mailer to use SMTP
  /* $mail->isSMTP();
  $mail->Host       = 'smtp.gmail.com';
  $mail->SMTPAuth   = true;
  $mail->Username   = 'rv@coachrakeshverma.com';
  $mail->Password   = 'richa1998#';
  $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
  $mail->Port       = 587; */

  //Recipients
  $mail->setFrom('rv@coachrakeshverma.com', 'Website Contact Form');
  $mail->addAddress('amanpreet@intiger.in');
  $mail->addAddress('aspnetusername@gmail.com');
  $mail->addAddress('rv@coachrakeshverma.com', 'Coach Rakesh Verma');
  $mail->addReplyTo('rv@coachrakeshverma.com', 'Coach Rakesh Verma');

  // $mail->addCC('cc@example.com');
  // $mail->addBCC('bcc@example.com');

  //Attachments
  // $mail->addAttachment('/var/tmp/file.tar.gz');
  // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');

  //Content
  $mail->isHTML(true); //Set email format to HTML
  $mail->Subject = 'Website Contact Form Query';
  $mail->Body = 'This is the HTML message body <b>in bold!</b>';
  $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

  $mail->send();
  echo 'Message has been sent';

} catch (Exception $e) {

  echo "Message could not be senty. Mailer Error: {$mail->ErrorInfo}";

}
