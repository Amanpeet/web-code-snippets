<?php
/*
Template Name: Register-page-Template
*/
?>
<!-- the header -->
<?php get_header(); ?>


<!-- Custom wordpress registeration form -->
<?php

  $reg_action_url = $_SERVER['REQUEST_URI'];

  if (isset($_POST['reg_values'])) {

    registration_validation(
      $_POST['username'],
      $_POST['password'],
      $_POST['confirm_password'],
      $_POST['email_id'],
      $_POST['first_name'],
      $_POST['last_name']
    );
  
    // sanitize user form input
    global $username, $password, $email, $website, $first_name, $last_name, $reg_output;
    $username   =   sanitize_user($_POST['username']);
    $password   =   esc_attr($_POST['password']);
    $email      =   sanitize_email($_POST['email_id']);
    $first_name =   sanitize_text_field($_POST['first_name']);
    $last_name  =   sanitize_text_field($_POST['last_name']);

    // call @function complete_registration to create the user only when no WP_error is found
    complete_registration(
      $username,
      $password,
      $email,
      $first_name,
      $last_name
    );

    echo $reg_output;
  }


  function registration_validation( $username, $password, $confirm_password, $email, $first_name, $last_name )  {
      global $reg_errors;
      $reg_errors = new WP_Error;

      if ( empty( $username ) || empty( $password ) || empty( $email ) ) {
        $reg_errors->add('field', 'Required form field is missing');
      }

      if ( strlen( $username ) < 4 ) {
        $reg_errors->add('username_length', 'Username too short. At least 4 characters is required');
      }

      if ( username_exists( $username ) )
        $reg_errors->add('user_name', 'Sorry, that username already exists!');

      if ( !validate_username( $username ) ) {
        $reg_errors->add('username_invalid', 'Sorry, the username you entered is not valid');
      }

      if ( strlen( $password ) < 5 ) {
        $reg_errors->add('password', 'Password length must be greater than 5');
      }

      if ( !is_email( $email ) ) {
        $reg_errors->add('email_invalid', 'Email is not valid');
      }

      if ( email_exists( $email ) ) {
        $reg_errors->add('email', 'Email Already in use');
      }

      if ( is_wp_error( $reg_errors ) ) {
          foreach ( $reg_errors->get_error_messages() as $error ) {
            $reg_output .= '<strong>ERROR</strong>:'. $error . '<br/>';
          }
      }
  }

  function complete_registration() {
      global $reg_errors, $username, $password, $email, $first_name, $last_name;
      if ( count($reg_errors->get_error_messages()) < 1 ) {
          $userdata = array(
          'user_login'  =>  $username,
          'user_email'  =>  $email,
          'user_pass'   =>  $password,
          'first_name'  =>  $first_name,
          'last_name'   =>  $last_name
      );

      $user = wp_insert_user( $userdata );
      $reg_output = 'Registration complete. Goto <a href="' . get_site_url() . '/wp-login.php">login page</a>.';   
    }

    	if(isset($_FILES["pic_input"]["error"])){
    		upload_profile_pic();
    	}
  }

?>
	
	<section class="output_bar">
	  <div class="row">
	    <div class="container">
	      <p class="error-msg">
	      	<?php echo (!empty($reg_output)) ? $reg_output : ''; ?>
	      </p>
	    </div>
	  </div>
	</section>


  <section class="page-banner">
    <div class="row">
      <div class="container">
        <div class="breadcrumb">
          <p>
              <?php
                if($location = substr(dirname($_SERVER['PHP_SELF']), 1)){
                  $dirlist = explode('/', $location);
                } else{
                  //$dirlist = array();
                }
                $count = array_push($dirlist, basename($_SERVER['PHP_SELF']));
                $address = 'http://'.$_SERVER['HTTP_HOST'];
                echo '<a href="'.$address.'">Home</a>';
                for($i = 0; $i < $count; $i++) {
                  echo '&nbsp;&raquo;&nbsp;<a href="'.($address .= '/'.$dirlist[$i]).'">'.$dirlist[$i].'</a>';
                }
              ?>
          </p>
        </div>
        <?php the_title( '<h2 class="page-title center entry-title">', '</h2>' ); ?>
        <p class="page-descrip center">Upload your content to you us for discussions.</p>
      </div>
    </div>
  </section>


  <section class="submit-content">
    <div class="row">
      <div class="container">

      	<!-- <form class="reg_form" name="reg_form" action="<?php echo $reg_action_url; ?>" method="POST"> -->
        
        <div class="mega left">
          <div class="whitey no-gap full">
        
            <div class="cicles-titles ghosty">
              <h3 class="titler">Tell us about yourself</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
            </div>
        
            <div class="blank">

              <form class="reg_form" name="reg_form" action="<?php echo $reg_action_url; ?>" method="POST">
              	<input type="hidden" name="reg_values" value="1">
        
                <div class="txts full">
                  <div class="half left">
                    <h3 class="titler"> Gender</h3>
                    <label> <input class="chkbox" type="radio" name="gender"> Male </label>
                    <label> <input class="chkbox" type="radio" name="gender"> Female </label>
                  </div>
                </div>
          
                <div class="txts full">
                  <div class="half left">
                    <h3 class="titler"> First Name</h3>
                    <input class="txtbox" type="text" name="first_name" placeholder="Jack">
                  </div>
                  <div class="half left">
                    <h3 class="titler"> Last Name</h3>
                    <input class="txtbox" type="text" name="last_name" placeholder="Sparrow">
                  </div>
                </div>

                <div class="txts full">
                  <div class="half left">
                    <h3 class="titler"> Username</h3>
                    <input class="txtbox" type="text" name="username" placeholder="Unique Username">
                  </div>
                  <div class="half left">
                    <h3 class="titler"> Email</h3>
                    <input class="txtbox" type="text" name="email_id" placeholder="example@mail.com">
                  </div>
                </div>
          
                <div class="txts full">
                  <div class="half left">
                    <h3 class="titler"> Password</h3>
                    <input class="txtbox" type="password" name="password" placeholder="Min 6 Chars">
                  </div>
                  <div class="half left">
                    <h3 class="titler"> Confirm Password</h3>
                    <input class="txtbox" type="password" name="confirm_password" placeholder="Min 6 Chars">
                  </div>
                </div>
                
                <div class="txts full">
                  <div class="half left">
                    <h3 class="titler"> Date of Birth </h3>
                    <select class="sltbox third left" name="dob_day">
                      <option>Day</option>
                      <option>5</option>
                      <option>6</option>
                    </select>
                    <select class="sltbox third left" name="dob_month">
                      <option>Month</option>
                      <option>June</option>
                      <option>November</option>
                    </select>
                    <select class="sltbox third left" name="dob_year">
                      <option>Year</option>
                      <option>2000</option>
                      <option>2016</option>
                    </select>
                  </div>
                </div>
								
								<input type="hidden" id="pic_input_uid" name="pic_input_uid" value="dummy">
              </form>

            </div>
          </div>
          
        </div>

        <div class="mini left">
          <div class="whitey full reg-bg">          
            <div class="pic-upload center">

            	<form id="pic_form" action="" method="post" enctype="multipart/form-data">
            		<div class="profile-pic-box">
	            		<img id="previewing" src="<?php echo get_template_directory_uri(); ?>/img/profile_pic_1.jpg" alt="">
            		</div>
	              <h3 class="titler ">Upload your picture </h3>
	              <p>Give a face to your profile, or maybe later.</p><br>
	              <input class="txtbox" type="file" name="pic_input" id="pic_input">
	              <!-- <br><br> <input class="btn-mini" type="submit" id="upload_pic_btn" name="upload_pic_btn" value="Upload"> -->
	              <h4 id='loading' style="display:none;">loading..</h4>
	              <button type="submit" id="upload_pic_btn" class="btn-mini">UPLOAD</button>
            	</form>

            </div>
          </div>          
        </div>

        <!-- </form> -->


      </div>
    </div>

    <div class="row">
      <div class="container">

        <div class="whitey no-gap full">
          <div class="ghosty">
            <h2 class="center">Choose your interests</h2><br>
            <p class="center">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt.</p>
          </div>
          <div class="category-pics">
            <ul class="center">
              <li>
                <a href="#">
                  <img src="http://placehold.it/150x150" alt="">
                  <span class="category-name"> Category </span>
                  <span class="tick"><i class="fa fa-check"></i></span>
                </a>
              </li>
              <li>
                <a href="#">
                  <img src="http://placehold.it/150x150" alt="">
                  <span class="category-name"> Category </span>
                  <span class="tick"><i class="fa fa-check"></i></span>
                </a>
              </li>
              <li>
                <a href="#">
                  <img src="http://placehold.it/150x150" alt="">
                  <span class="category-name"> Category </span>
                  <span class="tick"><i class="fa fa-check"></i></span>
                </a>
              </li>
              <li>
                <a href="#">
                  <img src="http://placehold.it/150x150" alt="">
                  <span class="category-name"> Category </span>
                  <span class="tick"><i class="fa fa-check"></i></span>
                </a>
              </li>
              <li>
                <a href="#">
                  <img src="http://placehold.it/150x150" alt="">
                  <span class="category-name"> Category </span>
                  <span class="tick"><i class="fa fa-check"></i></span>
                </a>
              </li>
              <li>
                <a href="#">
                  <img src="http://placehold.it/150x150" alt="">
                  <span class="category-name"> Category </span>
                  <span class="tick"><i class="fa fa-check"></i></span>
                </a>
              </li>

              <li>
                <a href="#">
                  <img src="http://placehold.it/150x150" alt="">
                  <span class="category-name"> Category </span>
                  <span class="tick"><i class="fa fa-check"></i></span>
                </a>
              </li>
              <li>
                <a href="#">
                  <img src="http://placehold.it/150x150" alt="">
                  <span class="category-name"> Category </span>
                  <span class="tick"><i class="fa fa-check"></i></span>
                </a>
              </li>
              <li>
                <a href="#">
                  <img src="http://placehold.it/150x150" alt="">
                  <span class="category-name"> Category </span>
                  <span class="tick"><i class="fa fa-check"></i></span>
                </a>
              </li>
              <li>
                <a href="#">
                  <img src="http://placehold.it/150x150" alt="">
                  <span class="category-name"> Category </span>
                  <span class="tick"><i class="fa fa-check"></i></span>
                </a>
              </li>
              <li>
                <a href="#">
                  <img src="http://placehold.it/150x150" alt="">
                  <span class="category-name"> Category </span>
                  <span class="tick"><i class="fa fa-check"></i></span>
                </a>
              </li>
              <li>
                <a href="#">
                  <img src="http://placehold.it/150x150" alt="">
                  <span class="category-name"> Category </span>
                  <span class="tick"><i class="fa fa-check"></i></span>
                </a>
              </li>
            </ul>
          </div>

          <a href="#">View All</a>

        </div>
        
      </div>
    </div>

    <div class="row">
      <div class="container">

        <div class="full">

          <div class="left two-third">
            <div class="txts full">
              <label><br>
                <input class="" type="checkbox" name="entry_name" placeholder="example@mail.com"> I agree to all terms and conditions.
              </label>
              <br>
              <label>
                <input class="" type="checkbox" name="entry_name" placeholder="example@mail.com"> Subscribe to the newsletter.
              </label>
            </div>
          </div>
          
          <div class="right third">
            <input id="reg_submit" type="button" name="reg_submit" value="SUBMIT" class="btn-alpha btn-big right">
          </div>

        </div>
        
      </div>
    </div>

  </section>
	
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
  <script>
    $(document).ready(function(){

    	//submit the reg_form
	      $("#reg_submit").click(function(){
	        console.log("Submitting form");
	        $( ".reg_form" ).submit();
	      });

	     //Upload the profile img
	      $("#pic_form").on('submit', function(e) {
	        e.preventDefault();

	        $(".error-msg").empty();
          $(".error-msg").slideUp();
	        $('#loading').show();

	        var process_path = "<?php echo get_template_directory_uri(); ?>/ajax/profile_pic.php";
					var file      = $("#pic_input")[0].files[0];
					var imagefile = file.type;
					var match     = ["image/jpeg", "image/png", "image/jpg"];

          if (!((imagefile == match[0]) || (imagefile == match[1]) || (imagefile == match[2]))) {
            $(".error-msg").html("Please Select A valid Image File <span id='error_message'> Only jpeg, jpg and png Images type allowed </span>");
            $(".error-msg").slideDown();
            alert("Please select a valid image File, and Try again.");
            return false;
          } else {
			        $.ajax({
									url: process_path, // Url to which the request is send
									type: "POST", // Type of request to be send, called as method
									data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
									contentType: false, // The content type used when sending data to the server.
									cache: false, // To unable request pages to be cached
									processData: false, // To send DOMDocument or non processed data file it is set to false
				          success: function(data) {
				            console.log("ajax success function");
				            $('#loading').hide();
				            $(".error-msg").html(data);
                    $(".error-msg").slideDown();
				            alert(data);

				            //if data is pic id
				            if(1 == 2){
				            	$("#pic_input_uid").val(data);
				            } else {
				            	console.log("Response: "+data);
				            }
				          },
				          error: function(err) {
				            console.log("ajax error function");
				            $(".error-msg").html(err);
                    $(".error-msg").slideDown();
				          }
			        });
          }

	    	}); //img upload end
	    	

    });

    // Function to preview image after validation
    $(function() {
      $("#pic_input").change(function() {
      	console.log("changing file");

        $(".error-msg").empty(); // To remove the previous error message
        var file = this.files[0];
        var imagefile = file.type;
        var match = ["image/jpeg", "image/png", "image/jpg"];
        if (!((imagefile == match[0]) || (imagefile == match[1]) || (imagefile == match[2]))) {
          $('#previewing').attr('src', '');
          $(".error-msg").html("Please Select A valid Image File <span id='error_message'> Only jpeg, jpg and png Images type allowed </span>");
          return false;
        } else {
          var reader = new FileReader();
          reader.onload = imageIsLoaded;
          reader.readAsDataURL(this.files[0]);
        }
      });
    });
    function imageIsLoaded(e) {
    	console.log("loading image");
      $("#pic_input").css("color", "forestgreen");
      $('#previewing').attr('src', e.target.result);
    };

  </script>


<!-- the footer -->
<?php get_footer(); ?>
