<?php
/*
Template Name: Newsfeed-page-Template
*/
?>
<!-- the header -->
<?php get_header(); ?>


  <section class="page-banner">
    <div class="row">
      <div class="container">
        <div class="breadcrumb">
          <p>Home / Newsfeed</p>
        </div>
        <h2 class="page-title">Real Discussions</h2>
        <p class="page-descrip">Showing your newsfeed with most recent activity.</p>
      </div>
    </div>
  </section>


  <section class="newsfeed-page">
    <div class="row">
      <div class="container">
        <div class="colum fourth left">

          <div class="user-settings whitey gap-right">
            <div class="user-image full">
              <img class="image-actual" src="<?php echo get_template_directory_uri(); ?>/img/user1.jpg" alt="">
              <div class="clear"></div>
              <h3>Eva Connor</h3>
              <h5 class="greyed"><i class="fa fa-pencil-square-o" aria-hidden="true"></i><a href="#">Edit Profile</a></h5>
            </div>
            <div class="user-links">
              <ul>
                <li><a href="#"><i class="fa fa-globe" aria-hidden="true"></i> Activity</a></li>
                <li><a href="#"><i class="fa fa-cog" aria-hidden="true"></i> Settings</a></li>
              </ul>

              <ul>
                <li><a href="#"> <i class="fa fa-dot-circle-o" aria-hidden="true"></i> Circles</a>
                  <ul>
                    <li><a href="#"><span class="circle colr1"></span>#friends</a></li>
                    <li><a href="#"><span class="circle colr2"></span>#family</a></li>
                    <li><a href="#"><span class="circle colr3"></span>#work</a></li>
                    <li><a href="#"><span class="circle colr4"></span>#church</a></li>
                  </ul>
                </li>
              </ul>

            </div>
          </div>

        </div>
        <div class="colum half left">
          <div class="status-box whitey">
            <div class="txts full">
              <h3 class="titler left blu"> <i class="fa fa-rocket" aria-hidden="true"></i> Update Status</h3>
              <a class="left greyed" href="#"> <i class="fa fa-camera" aria-hidden="true"></i> Add Photos</a>
              <div class="clear"></div>
              <textarea class="txtarea" name="update_status" placeholder="Whats on your mind?"></textarea>
            </div>
          </div>

          <div class="newsfeed-wrap">
            <!-- in the loop -->


            <div class="newsfeed-item whitey">

              <div class="feed-head">
                <div class="left fifth">
                  <img src="<?php echo get_template_directory_uri(); ?>/img/user4.jpg" alt="">
                </div>
                <div class="left four-fifth">
                  <h4 class="feed-user"><strong>Diana Vic</strong> likes a Photo Album</h4>
                  <p class="greyed">
                    <span class="feed-category left">Category: Photos</span>
                    <span class="feed-date right">10:02AM, Aug 3, 2016</span>
                  </p>
                </div>
              </div>

              <div class="feed-images">
                <img class="image-main full" src="<?php echo get_template_directory_uri(); ?>/img/stock2.jpg" alt="">
                <ul class="extra-images">
                  <li class="left third">
                    <img class="image-main full" src="<?php echo get_template_directory_uri(); ?>/img/stock1.jpg" alt="">
                  </li>
                  <li class="left third">
                    <img class="image-main full" src="<?php echo get_template_directory_uri(); ?>/img/stock2.jpg" alt="">
                  </li>
                  <li class="left third">
                    <img class="image-main full" src="<?php echo get_template_directory_uri(); ?>/img/stock3.jpg" alt="">
                  </li>
                </ul>
              </div>

              <div class="feed-tools">
                <a href="#" class="greyed"> <i class="fa fa-comments-o" aria-hidden="true"></i> Comment</a>
                <a href="#" class="greyed"> <i class="fa fa-share" aria-hidden="true"></i> Share</a>
              </div>

              <div class="feed-comments hidden">
              <!-- in the loop -->
                <div class="comment-item bg-colr1">
                  <div class="left fifth">
                    <img class="commenter-image" src="<?php echo get_template_directory_uri(); ?>/img/user2.jpg" alt="">
                  </div>
                  <div class="left four-fifth">
                    <p class="comment-actual">
                      <span class="commenter-name">Diana Lanr</span>
                      <span class="commenter-comment">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</span>
                     </p> 
                    <p class="greyed">
                    <span class="comment-date right">10:02AM, Aug 3, 2016</span>
                  </p>
                  </div>
                </div>
                <div class="comment-item bg-colr2">
                  <div class="left fifth">
                    <img class="commenter-image" src="<?php echo get_template_directory_uri(); ?>/img/user3.jpg" alt="">
                  </div>
                  <div class="left four-fifth">
                    <p class="comment-actual">
                      <span class="commenter-name">Selina Kyle</span>
                      <span class="commenter-comment">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</span>
                     </p>
                    <p class="greyed">
                    <span class="comment-date right">10:02AM, Aug 3, 2016</span>
                  </p>
                  </div>
                </div>
                <div class="comment-item bg-colr3">
                  <div class="left fifth">
                    <img class="commenter-image" src="<?php echo get_template_directory_uri(); ?>/img/user4.jpg" alt="">
                  </div>
                  <div class="left four-fifth">
                    <p class="comment-actual">
                      <span class="commenter-name">Kat Rena</span>
                      <span class="commenter-comment">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</span>
                     </p>
                    <p class="greyed">
                    <span class="comment-date right">10:02AM, Aug 3, 2016</span>
                  </p>
                  </div>
                </div>
                <div class="comment-item bg-colr4">
                  <div class="left fifth">
                    <img class="commenter-image" src="<?php echo get_template_directory_uri(); ?>/img/user5.jpg" alt="">
                  </div>
                  <div class="left four-fifth">
                    <p class="comment-actual">
                      <span class="commenter-name">Seras Vic</span>
                      <span class="commenter-comment">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</span>
                     </p>
                    <p class="greyed">
                    <span class="comment-date right">10:02AM, Aug 3, 2016</span>
                  </p>
                  </div>
                </div>

              <!-- end the loop -->
              </div>

              <div class="feed-reply hidden">
                <div class="txts full">
                  <div class="left fifth">
                    <img class="user-image" src="<?php echo get_template_directory_uri(); ?>/img/user1.jpg" alt=""><br>
                    
                  </div>
                  <div class="left four-fifth">
                    <textarea class="txtarea" name="update_status" placeholder="Whats on your mind?"></textarea>
                    <select class="right">
                      <option>Public</option>
                      <option>Private</option>
                      <option>Me Only</option>
                    </select>
                    <button class="btn-mini" type="button">DONE</button>
                  </div>
                </div>
              </div>

            </div>

            <div class="newsfeed-item whitey">

              <div class="feed-head">
                <div class="left fifth">
                  <img src="<?php echo get_template_directory_uri(); ?>/img/user3.jpg" alt="">
                </div>
                <div class="left four-fifth">
                  <h4 class="feed-user"><strong>Selina Kyle</strong> Shared a Photo</h4>
                  <p class="greyed">
                    <span class="feed-category left">Category: Photos</span>
                    <span class="feed-date right">10:02AM, Aug 3, 2016</span>
                  </p>
                </div>
              </div>

              <div class="feed-images">
                <img class="image-main full" src="<?php echo get_template_directory_uri(); ?>/img/stock1.jpg" alt="">
                <ul class="hidden">
                  <li>
                    <img class="image-main full" src="<?php echo get_template_directory_uri(); ?>/img/stock2.jpg" alt="">
                  </li>
                  <li>
                    <img class="image-main full" src="<?php echo get_template_directory_uri(); ?>/img/stock3.jpg" alt="">
                  </li>
                  <li>
                    <img class="image-main full" src="<?php echo get_template_directory_uri(); ?>/img/stock1.jpg" alt="">
                  </li>
                </ul>
              </div>

              <div class="feed-tools">
                <a href="#" class="greyed"> <i class="fa fa-comments-o" aria-hidden="true"></i> Comment</a>
                <a href="#" class="greyed"> <i class="fa fa-share" aria-hidden="true"></i> Share</a>
              </div>

              <div class="feed-comments">
              <!-- in the loop -->
                <div class="comment-item bg-colr1">
                  <div class="left fifth">
                    <img class="commenter-image" src="<?php echo get_template_directory_uri(); ?>/img/user2.jpg" alt="">
                  </div>
                  <div class="left four-fifth">
                    <p class="comment-actual">
                      <span class="commenter-name">Diana Lanr</span>
                      <span class="commenter-comment">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</span>
                     </p> 
                    <p class="greyed">
                    <span class="comment-date right">10:02AM, Aug 3, 2016</span>
                  </p>
                  </div>
                </div>
                <div class="comment-item bg-colr2">
                  <div class="left fifth">
                    <img class="commenter-image" src="<?php echo get_template_directory_uri(); ?>/img/user3.jpg" alt="">
                  </div>
                  <div class="left four-fifth">
                    <p class="comment-actual">
                      <span class="commenter-name">Selina Kyle</span>
                      <span class="commenter-comment">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</span>
                     </p>
                    <p class="greyed">
                    <span class="comment-date right">10:02AM, Aug 3, 2016</span>
                  </p>
                  </div>
                </div>
                <div class="comment-item bg-colr3">
                  <div class="left fifth">
                    <img class="commenter-image" src="<?php echo get_template_directory_uri(); ?>/img/user4.jpg" alt="">
                  </div>
                  <div class="left four-fifth">
                    <p class="comment-actual">
                      <span class="commenter-name">Kat Rena</span>
                      <span class="commenter-comment">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</span>
                     </p>
                    <p class="greyed">
                    <span class="comment-date right">10:02AM, Aug 3, 2016</span>
                  </p>
                  </div>
                </div>
                <div class="comment-item bg-colr4">
                  <div class="left fifth">
                    <img class="commenter-image" src="<?php echo get_template_directory_uri(); ?>/img/user5.jpg" alt="">
                  </div>
                  <div class="left four-fifth">
                    <p class="comment-actual">
                      <span class="commenter-name">Seras Vic</span>
                      <span class="commenter-comment">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</span>
                     </p>
                    <p class="greyed">
                    <span class="comment-date right">10:02AM, Aug 3, 2016</span>
                  </p>
                  </div>
                </div>

              <!-- end the loop -->
              </div>

              <div class="feed-reply">
                <div class="txts full">
                  <div class="left fifth">
                    <img class="user-image" src="<?php echo get_template_directory_uri(); ?>/img/user1.jpg" alt=""><br>
                    
                  </div>
                  <div class="left four-fifth">
                    <textarea class="txtarea" name="update_status" placeholder="Whats on your mind?"></textarea>
                    <select class="right">
                      <option>Public</option>
                      <option>Private</option>
                      <option>Me Only</option>
                    </select>
                    <button class="btn-mini" type="button">DONE</button>
                  </div>
                </div>
              </div>

            </div>

            <!-- end the loop -->
          </div>

        </div>
        <div class="colum fourth left">
          <div class="side-links whitey gap-left">
            <ul>
              <li>
                <a href="#" class="active"> <i class="fa fa-newspaper-o" aria-hidden="true"></i> Real Discussions <span class="right"></span> </a>
              </li>
              <li>
                <a href="#"><i class="fa fa-empire" aria-hidden="true"></i> All Connections <span class="right">22</span> </a>
              </li>
              <li>
                <a href="#"><i class="fa fa-heart-o" aria-hidden="true"></i> Favorites <span class="right"></span> </a>
              </li>
              <li>
                <a href="#"><i class="fa fa-bullseye" aria-hidden="true"></i> Circles <span class="right">6</span> </a>
              </li>
              <li>
                <a href="#"><i class="fa fa-picture-o" aria-hidden="true"></i> Photos <span class="right">11</span> </a>
              </li>
              <li>
                <a href="#"><i class="fa fa-fire" aria-hidden="true"></i> Hot <span class="right"></span> </a>
              </li>
              <li>
                <a href="#"> <i class="fa fa-hourglass-half" aria-hidden="true"></i> Trending <span class="right">18</span> </a>
              </li>
            </ul>
            <a href="#" class="blu right">See All </a>

          </div>
          <div class="search-box whitey gap-left">
            <input type="text" class="txtbox" name="search-txt" placeholder="Search">
            <button type="button" class="btn-beta"> <i class="fa fa-search" aria-hidden="true"></i> </button>
          </div>

        </div>

      </div>
    </div>

  </section>


<!-- the footer -->
<?php get_footer(); ?>
