<div class="um-locked-content">

	<div class="um-locked-content-msg"><?php echo $lock_text; ?></div>

</div>