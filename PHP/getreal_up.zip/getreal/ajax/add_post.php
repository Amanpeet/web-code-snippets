<?php

  require_once( '../../../../wp-load.php' );

  if( !empty($_POST["entry_title"]) ){

      /* get post categories */
      /*
      $post_id = 165;
      $post_categories = wp_get_post_categories( $post_id );
      $cats = array();
      foreach($post_categories as $c){
          $cat = get_category( $c );
          $cats[] = array( 'name' => $cat->name, 'slug' => $cat->slug );
          echo $cat->name;
      }
      print_r ( $cats );
      */

      $user_id      = get_current_user_id();
      $current_user = wp_get_current_user();
      $user_name    = $current_user->user_login;

      $post_id       = "post123";
      $post_title    = $_POST["entry_title"];
      $post_content  = $_POST["entry_descrip"];
      $article_type  = $_POST["article_type"];
      $entry_title   = $_POST["entry_title"];
      $entry_descrip = $_POST["entry_descrip"];

      $category_type = $_POST["category_type"];
      $idObj = get_category_by_slug($category_type); 
      $category = $idObj->term_id;

      $entry_name    = $_POST["entry_name"];
      $entry_email   = $_POST["entry_email"];
      // $entry_terms   = $_POST["entry_terms"];

      //upload the image first
      if($_FILES["entry_image"]["error"] > 0){
          echo "ERROR: " . $_FILES["entry_image"]["error"] . "<br>";
      } else{
          $allowed = array("jpg" => "image/jpg", "jpeg" => "image/jpeg", "gif" => "image/gif", "png" => "image/png");
          $filename = $_FILES["entry_image"]["name"];
          $filetype = $_FILES["entry_image"]["type"];
          $filesize = $_FILES["entry_image"]["size"];

          $filesize_kb = round($_FILES["entry_image"]["size"] / 1024);
          $upload_path = $_SERVER['DOCUMENT_ROOT'] . '/getreal/uploads/post_images/';
          $new_pic_id  = uniqid("img", TRUE);
          $new_pic_id  = str_replace(".","",$new_pic_id);
      
          // Verify file extension
          $ext = pathinfo($filename, PATHINFO_EXTENSION);
          if(!array_key_exists($ext, $allowed)){
            echo "ERROR: Please select a valid file format.";
            die();    
          } 

          // Verify file size - 5MB maximum
          $maxsize = 5 * 1024 * 1024;
          if($filesize > $maxsize){
            echo "ERROR: File size is larger than the allowed limit.";
            die();
          } 
      
          // Verify MYME type of the file
          if(in_array($filetype, $allowed)){

              // MOVE the uploaded file to directory
              $uploaded_file_name = $new_pic_id . "." . $ext;
              $uploaded_file_url  = "/uploads/profile_pics/" . $uploaded_file_name;
              
              if( move_uploaded_file( $_FILES["entry_image"]["tmp_name"], $upload_path ."/". $uploaded_file_name ) ){
                //echo "Your file was uploaded successfully.";

                /*  INSERT IMAGE NAME TO DATABASE  */
                global $wpdb;
                $sql = "INSERT INTO post_images( user_id, user_name, img_name, img_url, post_id ) VALUES ( '$user_id', '$user_name', '$uploaded_file_name', '$uploaded_file_url', '$post_id' )";
                echo $result = ( $wpdb->query($sql) ) ? $uploaded_file_name : "ERROR: Image name not returned." ;
                
              } else {
                 echo "ERROR: Your file encountered some error.";
              }

          } else {
              echo "ERROR: There was a problem uploading your image - please try again.";
          }
      }

      //Insert the actual post
      if( $post_title != "" ){

        // Create post object
        $my_post = array(
          'post_title'     => wp_strip_all_tags( $post_title ),
          'post_content'   => $post_content,
          'post_status'    => 'private',
          'post_type'      => 'post',
          'post_author'    => $user_id,
          'post_category'  => array($category),
          'post_excerpt'   => '',
          'comment_status' => 'open',
          'meta_input'     => ''
        );
         
        // Insert the post into the database
        // wp_insert_post( $my_post );

        $post_id = 0;
        echo $post_id = wp_insert_post( $my_post, $wp_error );

        if( $post_id != 0 ){
          echo "post inserted with id:" . $post_id ;
        } else {
          echo "post failed ";
        }
        // print_r(wp_insert_post( $my_post, $wp_error ));

      } else {
        echo " oh no ";
      }

  } else {
      echo "ERROR: Form not found. Please try again.";
  }

?>