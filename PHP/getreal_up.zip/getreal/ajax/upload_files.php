<form action="" method="post" enctype="multipart/form-data">
  <input name="file" type="file" name="file" />
  <Input type="submit" value="submit">
</form>

<?php

//$uploaddir = $_SERVER['DOCUMENT_ROOT'] . 'getreal/uploads/uploaded_files/';

  require_once( '../../../../wp-load.php' );

  if( !empty($_FILES) ){

			$upload_path = $_SERVER['DOCUMENT_ROOT'] . '/getreal/uploads/uploaded_files/';

			$user_id   = "1337";
			$user_name = "user_name";
			$post_id   = "post123";

      if($_FILES["file"]["error"] > 0){
          echo "ERROR: " . $_FILES["file"]["error"] . "<br>";
      } else{
          $allowed = array(
          	"jpg" => "image/jpg", 
          	"jpeg" => "image/jpeg", 
          	"gif" => "image/gif", 
          	"png" => "image/png", 
          	"pdf" => "application/pdf"
          );

          $filename = $_FILES["file"]["name"];
          $filetype = $_FILES["file"]["type"];
          $filesize = $_FILES["file"]["size"];

          $filesize_kb = round($_FILES["file"]["size"] / 1024);          
          $new_file_id  = uniqid("file", TRUE);
          $new_file_id  = str_replace(".","",$new_file_id);
      
          // Verify file extension
          $ext = pathinfo($filename, PATHINFO_EXTENSION);
          if(!array_key_exists($ext, $allowed)){
            echo "ERROR: Please select a valid file format.";
            die();
          } 

          // Verify file size - 5MB maximum
          $maxsize = 10 * 1024 * 1024;
          if($filesize > $maxsize){
            echo "ERROR: File size is larger than the allowed limit.";
            die();
          } 
      
          // Verify MYME type of the file
          if(in_array($filetype, $allowed)){
              // MOVE the uploaded file to directory
              $uploaded_file_name = $new_file_id . "." . $ext;
              $uploaded_file_url  = "/uploads/profile_pics/" . $uploaded_file_name;
              
              if( move_uploaded_file( $_FILES["file"]["tmp_name"], $upload_path ."/". $uploaded_file_name ) ){
                //echo "Your file was uploaded successfully.";

                global $wpdb;
                $sql = "INSERT INTO uploaded_files( user_id, user_name, file_name, file_url, post_id ) VALUES ( '$user_id', '$user_name', '$uploaded_file_name', '$uploaded_file_url', '$post_id' )";
                echo $result = ( $wpdb->query($sql) ) ? $uploaded_file_name : "ERROR: Picture name not returned." ;
                
              } else {
                 echo "ERROR: Moving file encountered some error.";
              }

          } else {
              echo "ERROR: Unable to validate your file - Please try again.";
          }
      }
  } else {
      echo "ERROR: Files to upload not found. Please try again.";
  }

?>