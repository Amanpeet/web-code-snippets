<?php
/*
Template Name: Profile-page-Template
*/
?>
<!-- the header -->
<?php get_header(); ?>


  <section class="profile-cover">
    <div class="row cover-bg">
      <div class="cover-bar">
        <div class="container">

          <div class="left offset-left">
            <p> Connections: <span class="followers">00</span> <!-- Following: <span class="following">00</span> --> </p>
          </div>

          <div class="right">
            <p> <i class="fa fa-camera" aria-hidden="true"></i> </p>
          </div>

        </div>
      </div>      
    </div>
  </section>

  <section class="profile-details">
    <div class="container">
      <div class="mega left">
        <div class="profile-pic-box">
          <img class="profile-picture" src="http://placehold.it/400x400" alt="">
        </div>
        <div class="profile-name-box">
          <h2 class="profile-name">Jack Sparrow</h2>
          <h4 class="profile-tag"> <i class="fa fa-map-marker" aria-hidden="true"></i> <span> Los Angles, CA </span> </h4>
          <h4 class="profile-url"> <i class="fa fa-globe" aria-hidden="true"></i> <span> www.website.com </span> </h4>
        </div>

      </div>

      <div class="mini right realme">
        <div class="whitey">
          <h3 class="titler">The Real Me</h3>
          <textarea name="txtarea_realme" id="txtarea_realme" class="txtarea" maxlength="100" placeholder="Describe the real you."></textarea>
        </div>
      </div>

    </div>
  </section>

  <section class="profile-activity">
    <div class="container">
      
      <div class="colum mega left">

        <div class="whitey no-gap full">
          <div class="cicles-titles ghosty">
            <h3 class="titler">Circles</h3>
            <ul class="ghosty-list">
              <li class=""> <a href="#">Friends</a> </li>
              <li class="active"> <a href="#">Family</a> </li>
              <li class=""> <a href="#">Work</a> </li>
              <li class=""> <a href="#">Church</a> </li>
              <li class=""> <a href="#">Others</a> </li>
            </ul>
          </div>
          <div class="cicles-pics">
            <ul>
              <li> <img src="http://placehold.it/150x150" alt=""> <p><span class="circle-name">Selina Kyle</span> <span class="circle-tags">CEO, Cat Techs</span></p> </li>
              <li> <img src="http://placehold.it/150x150" alt=""> <p><span class="circle-name">Selina Kyle</span> <span class="circle-tags">CEO, Cat Techs</span></p> </li>
              <li> <img src="http://placehold.it/150x150" alt=""> <p><span class="circle-name">Selina Kyle</span> <span class="circle-tags">CEO, Cat Techs</span></p> </li>
              <li> <img src="http://placehold.it/150x150" alt=""> <p><span class="circle-name">Selina Kyle</span> <span class="circle-tags">CEO, Cat Techs</span></p> </li>
              <li> <img src="http://placehold.it/150x150" alt=""> <p><span class="circle-name">Selina Kyle</span> <span class="circle-tags">CEO, Cat Techs</span></p> </li>
            </ul>
          </div>

          <a href="#">View All</a>

        </div>

        <div class="whitey no-gap full">
          <div class="cicles-titles ghosty">
            <h3 class="titler">Your Recent Activity</h3>
            <ul class="ghosty-list">
              <li class=""> <a href="#">Updates</a> </li>
              <li class="active"> <a href="#">Comments</a> </li>
              <li class=""> <a href="#">Connections</a> </li>
              <li class=""> <a href="#">Shared</a> </li>
            </ul>
          </div>
          
          <!-- in the loop -->

          <div class="comments-box">
            <div class="comment-img">
              <img src="http://placehold.it/80x80" alt="">
            </div>
            <div class="comment-tools">
              <p class="comment-actual">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
              tempor incididunt ut labore et dolore magna aliqua.</p>
              <a class="blu" href="#"> <i class="fa fa-trash-o" aria-hidden="true"></i> Delete</a>
              <a class="blu" href="#"> <i class="fa fa-share" aria-hidden="true"></i> Share</a>
              <span class="right comments-date"> 09:30AM, Aug 15, 2016</span>
            </div>
          </div>

          <div class="comments-box circle-friend">
            <div class="comment-img">
              <img src="http://placehold.it/80x80" alt="">
            </div>
            <div class="comment-tools">
              <p class="comment-actual">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
              tempor incididunt ut labore et dolore magna aliqua.</p>
              <a class="blu" href="#">Share</a>
              <a class="blu" href="#">Delete</a>
              <span class="right"> 26 July, 2016</span>
            </div>
          </div>

          <div class="comments-box">
            <div class="comment-img">
              <img src="http://placehold.it/80x80" alt="">
            </div>
            <div class="comment-tools">
              <p class="comment-actual">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
              tempor incididunt ut labore et dolore magna aliqua.</p>
              <a class="blu" href="#">Share</a>
              <a class="blu" href="#">Delete</a>
              <span class="right"> 26 July, 2016</span>
            </div>
          </div>

          <!-- loop end -->

        </div><br>
        <a class="right blu" href="#">Load More</a>

      </div>

      <div class="colum mini right">
        <div class="whitey full">
          <h3 class="titler">Activity</h3>
          <h4 class="titler-small">Forums</h4>
          <div class="canvas">
            <img src="http://placehold.it/400x240" alt="">
          </div>
        </div>

        <div class="whitey full">
          <h3 class="titler">Make Connections</h3>
          <div class="follow-who">
            <!-- in the loop -->

            <div class="follow-box">
              <div class="follow-img">
                <img src="http://placehold.it/80x80" alt="">
              </div>
              <div class="follow-content">
                <h4>Dumm Namero</h4>
                <p>Connected to Selina Kyle</p>
              </div>
              <div class="follow-icon">
                <i class="fa fa-user-plus" aria-hidden="true"></i>
              </div>
            </div>

            <div class="follow-box">
              <div class="follow-img">
                <img src="http://placehold.it/80x80" alt="">
              </div>
              <div class="follow-content">
                <h4>Dumm Namero</h4>
                <p>Connected to Selina Kyle</p>
              </div>
              <div class="follow-icon">
                <i class="fa fa-user-plus" aria-hidden="true"></i>
              </div>
            </div>

            <div class="follow-box">
              <div class="follow-img">
                <img src="http://placehold.it/80x80" alt="">
              </div>
              <div class="follow-content">
                <h4>Dumm Namero</h4>
                <p>Connected to Selina Kyle</p>
              </div>
              <div class="follow-icon">
                <i class="fa fa-user-plus" aria-hidden="true"></i>
              </div>
            </div>

            <!-- loop end -->            
          </div>
          <a class="blu right" href="#">Find Connections</a>

        </div>


        <div class="interests full">
          <h3 class="titler"> <i class="fa fa-star-o" aria-hidden="true"></i> Your Interests</h3>
          <div class="interests-box">
            <ul class="interests-list">
              <li> Web </li>
              <li> Internet </li>
              <li> Games </li>
              <li> Blogs </li>
              <li> Photography </li>
              <li> Movies </li>
              <li> TV-Shows </li>
              <li> Nature </li>
            </ul>
          </div>
          <a class="right blu" href="#">Edit</a>

        </div>

      </div>

    </div>
  </section>



<!-- the footer -->
<?php get_footer(); ?>
