<?php
/*
Template Name: Submit-content-Template
*/
?>
<!-- the header -->
<?php get_header(); ?>

<!-- dropzone animation css -->
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/dropzone.css">

  
  <section class="output_bar">
    <div class="row">
      <div class="container">
        <p class="error-msg">
          <?php echo (!empty($reg_output)) ? $reg_output : ''; ?>
        </p>
      </div>
    </div>
  </section>

  <section class="page-banner">
    <div class="row">
      <div class="container">
        <div class="breadcrumb">
          <p>Home / Submit Content</p>
        </div>
        <h2 class="page-title">Submit Content</h2>
        <p class="page-descrip">Upload your content to you us for discussions.</p>
      </div>
    </div>
  </section>


  <section class="submit-content">
    <div class="row">
      <div class="container high">

        <!-- <div class="fourth left medal">
          <div>
            <div>
              <img src="img/medal.png" alt="">            
            </div>
          </div>
        </div> -->

        <!-- <div class="three-fourth right whitey"> -->
        <div class="full whitey">
          <h3 class="hedler"> <i class="fa fa-trophy" aria-hidden="true"></i> Give it a shot </h3>
          <p>You can submit your content to our panel for review. If your entry is chosen, it will be displayed on the GetReal site. Please follow the guidelines and fill in the information below. Good luck!</p>
        </div>

      </div>
    </div>

    <div class="row">
      <div class="container">
        <div class="colum mega left">

          <form class="entryform" name="entryform" action="<?php echo get_template_directory_uri(); ?>/ajax/add_post.php" method="POST" enctype="multipart/form-data">
            
            <div class="whitey full">

              <div class="txts full">
                <div class="half">
                  <h3 class="titler"> Select Entry Type</h3>
                  <select class="sltbox" name="article_type">
                    <option value="">Article</option>
                    <option>Video</option>
                    <option>Other</option>
                  </select>
                </div>
              </div>

              <div class="txts full">
                <h3 class="titler"> Entry Title</h3>
                <input class="txtbox" type="text" name="entry_title" placeholder="Give it a nice name">
              </div>

              <div class="txts full">
                <h3 class="titler"> Describe Your Entry</h3>
                <textarea class="txtarea" name="entry_descrip" placeholder="Some brief about your submission"></textarea> 
                <p class="right">Max Chracters: 400</p>
              </div>

              <div class="txts full">
                <div class="half left">
                  <h3 class="titler"> Upload Image</h3>
                  <input class="filebox" type="file" name="entry_image" placeholder="Give it a nice name">
                </div>
              </div>
              
            </div>

            <div class="whitey full">
              <h3 class="titler"> Additional information</h3><br>

              <div class="txts full">
                <div class="half">
                  <h3 class="titler"> Select Category</h3>
                  <select class="sltbox" name="category_type">
                    <option value="entertainment">Entertainment</option>
                    <option value="politics">Politics</option>
                    <option value="travel">Travel</option>
                  </select>
                </div>
              </div>

              <div class="txts full">
                <h3 class="titler"> Name</h3>
                <input class="txtbox" type="text" name="entry_name" placeholder="Jack Sparrow">
              </div>

              <div class="txts full">
                <h3 class="titler"> Email</h3>
                <input class="txtbox" type="email" name="entry_email" placeholder="example@mail.com">
              </div>
              
              <br>
              <a class="blu" href="#">View Terms and Conditions</a>

            </div>

            <div class="left two-third">
              <div class="txts full">
                <label><br>
                  <input class="" type="checkbox" name="entry_terms"> I agree to all terms and conditions.
                </label>
              </div>
            </div>
            <div class="right third">
              <input type="submit" id="entryform_submit" name="entryform_submit" value="SUBMIT" class="btn-alpha btn-big right">
              <h4 id='loading' style="display:none;">loading..</h4>
            </div>

          </form>
        </div>
        <div class="colum mini right">

          <div class="whitey full">

            <div class="txts">
              <h3 class="titler"> Upload Files</h3>

                <div class="file-uploader">
                  <form action="<?php echo get_template_directory_uri(); ?>/ajax/upload_files.php" class="dropzone" id="my-awesome-dropzone">
                      <div class="inner">
                        <h3>Add Files</h3>
                        <h4>Drag Multiple files here <br> or <br> Click to browse</h4>
                        <!-- <input type="file" name="file_uploads"> -->
                      </div>
                  </form>
                </div>

            </div>

            <div class="txts hidden">
              <h3 class="titler"> Upload Files</h3>
              <div class="file-progress">
                <div class="left">
                  <i class="fa fa-picture-o" aria-hidden="true"></i>
                </div>
                <div class="right">
                  <h4 class="left">Photo.png <span class="file-size">2.1 mb</span></h4>
                  <div class="right cancel-btn">X</div>
                  <div class="clear"></div>
                  <div class="progress-bar"><div class="bar"></div></div>
                  <h4 class="percent left"> 40% done </h4>
                </div>
              </div>
            </div>

          </div>

          <div class="blank full">
            <h3 class="titler"> <i class="fa fa-book" aria-hidden="true"></i> Key points</h3>
            <ul class="points-list">
              <li>We are looking for quality content that will spark meaningful conversations.</li>
              <li>Content can be articles, pictures, videos, questions, statements, quotes, etc. you get the idea. Anything that will create real discussions on real topics.</li>
              <li>Please include a relevant image with all entries. </li>
              <li>If selected, your name will appear on the site alongside your entry. </li>
              <li>Please ensure that you have read all guidelines carefully before submitting an entry.</li>
            </ul>
            
          </div>
        </div>

      </div>
    </div>

  </section>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="<?php echo get_template_directory_uri(); ?>/js/dropzone.min.js"></script>
  <script>
    $(document).ready(function(){

      //submit the reg_form
        $("#entryform_submit").click(function(event){
          event.preventDefault();
          // console.log("run Validations");
          // runValidations();
          console.log("Submitting form");
          $( ".entryform" ).submit();
        });

       //Upload the entry form with files
        $(".entryform").on('submit', function(e) {
          e.preventDefault();

          $(".error-msg").empty();
          $(".error-msg").slideUp();
          $('#loading').show();

          var process_path = "<?php echo get_template_directory_uri(); ?>/ajax/add_post.php";
          var formData = new FormData($(this)[0]);

          //check if errors
          if ( 1 == 2 ) {
            $(".error-msg").html("Please Select A valid Image File <span id='error_message'> Only jpeg, jpg and png Images type allowed </span>");
            $(".error-msg").slideDown();
            alert("Please select a valid image File, and Try again.");
            return false;
          } else {
              $.ajax({
                  url: process_path,
                  type: "POST",
                  data: formData,
                  async: false,
                  cache: false,
                  contentType: false,
                  processData: false, 
                  success: function(data) {
                    console.log("ajax success function");
                    $('#loading').hide();
                    $(".error-msg").html(data);
                    $(".error-msg").slideDown();
                    console.log("Response: "+data);

                    //if data is pic id
                    if(1 == 2){
                      // $("#pic_input_uid").val(data);
                    } else {
                      // console.log("Response: "+data);
                    }

                  },
                  error: function(err) {
                    console.log("ajax error function");
                    $(".error-msg").html(err);
                    $(".error-msg").slideDown();
                  }
              });
          }

        }); //entry form end
        

    });

  </script>


<!-- the footer -->
<?php get_footer(); ?>
