<?php
/**
 * The template for displaying the header
 *
 * Displays all of the head element and everything up until the "site-content" div.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">

	<link rel="profile" href="http://gmpg.org/xfn/11">
	<?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
		<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php endif; ?>

	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/normalize.min.css">
	<!-- <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/main.css"> -->

	<script src="<?php echo get_template_directory_uri(); ?>/js/vendor/modernizr-2.8.3.min.js"></script>

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
	<!-- wrapper start -->
	<div class="wrapper">

		<div id="page" class="site">

			<a class="hidden skip-link screen-reader-text" href="#content"><?php _e( 'Skip to content', 'twentysixteen' ); ?></a>

			<header class="site-header <?php if( is_front_page() ) { echo 'bleed'; } ?>" id="masthead">
			  <div class="row top-bar">
			    <div class="container">
			      <div class="right">
			        <!-- <a class="btn-mini" href="#">Login </a> -->
			        <!-- <a class="btn-mini blu" href="#">Signup</a> -->
			        <?php
					        if (is_user_logged_in()) {
		                echo '<a class="btn-mini" href="'. site_url() .'/logout"> Log Out</a>';
		                echo '<a class="btn-mini blu" href="'. site_url() .'/account"> Account </a>';
		              } else {
		                echo '<a class="btn-mini" href="'. site_url() .'/login">Login</a>';
		                echo '<a class="btn-mini blu" href="'. site_url() .'/register"> Signup </a>';
		              }
			        ?>

			      </div>
			    </div>
			  </div>

			  <div class="row main-head">
			    <div class="container">
			      <div class="left">
			        <div class="logo">
			          <!-- <h1>GetReal</h1> -->
			          <img class="logo-img" src="<?php echo get_template_directory_uri(); ?>/img/getreal_logo.png" alt="getreal">
			        </div>
			      </div>
			      <div class="right">
			        <div class="nav-menu-head">

			          <?php if ( has_nav_menu( 'head-menu' ) ) : ?>
			          	<nav id="site-navigation" class="main-navigation">
			          		<?php
			          			wp_nav_menu( array(
			          				'theme_location' => 'head-menu',
			          				'menu_class'     => 'head-menu',
			          			 ) );
			          		?>
			          	</nav>
			          <?php endif; ?>

			        </div>
			      </div>
			    </div>
			  </div>

		  	<!-- IF HOME PAGE -->
		    <?php if ( is_front_page() ) : ?>
		    	<div class="row objects">
		    	  <div class="container">

		    	    <div class="objects-box">
		    	      <div class="left mega">
		    	        <h1><strong> what are you </strong> <br> searching for? </h1>
									
									<!-- check searchform.php in theme folder -->
									<?php get_search_form(); ?>

		    	        <div class="clear"></div>
		    	        <p class="search-form-links">
		    	          <a href="#">Featured</a> | 
		    	          <a href="#">Sports</a> | 
		    	          <a href="#">News</a>
		    	        </p>
		    	        
		    	      </div>

		    	      <div class="left mini">
		    	        <div class="head-chat">
		    	          <ul class="head-chat-list">
		    	            <li> <p> Hi, How are you doing? </p></li>
		    	            <li> <p> yeah, i am more than alright. you know why, just guess </p> <p>believe me, you have no idea!</p> </li>
		    	            <li> <p> I am fine, how are you, i hope u are alright. </p> </li>
		    	            <li> <p> I give up, plz do tell. </p> </li>
		    	          </ul>
		    	        </div>
		    	      </div>

		    	    </div>

		    	  </div>

		    	  <div class="third-eye">
		    	    <div class="eye-circle">
		    	      <ul class="entries-list">
		    	        <li class="width--1">
		    	          <img src="http://placehold.it/100x100" alt="">
		    	          <label><input type="radio" name="eye_select"></label>
		    	        </li>
		    	        <li class="width--2">
		    	          <img src="http://placehold.it/100x100" alt="">
		    	          <label><input type="radio" name="eye_select"></label>
		    	        </li>
		    	        <li class="width--3">
		    	          <img src="http://placehold.it/100x100" alt="">
		    	          <label><input type="radio" name="eye_select"></label>
		    	        </li>
		    	        <li class="width--4">
		    	          <img src="http://placehold.it/100x100" alt="">
		    	          <label><input type="radio" name="eye_select"></label>
		    	        </li>
		    	        <li class="width--5">
		    	          <img src="http://placehold.it/100x100" alt="">
		    	          <label><input type="radio" name="eye_select"></label>
		    	        </li>
		    	        <li class="width--6">
		    	          <img src="http://placehold.it/100x100" alt="">
		    	          <label><input type="radio" name="eye_select"></label>
		    	        </li>
		    	        <li class="width--7">
		    	          <img src="http://placehold.it/100x100" alt="">
		    	          <label><input type="radio" name="eye_select"></label>
		    	        </li>
		    	      </ul>
		    	    </div>
		    	  </div>


		    	</div>
		    <?php endif; ?>


			  <div class="row menu-bar">
			    <div class="container">
			      <div class="nav-menu-pages">

	        		<?php if ( has_nav_menu( 'primary' ) ) : ?>
	        			<nav id="site-navigation" class="main-navigation">
	        				<?php
	        					wp_nav_menu( array(
	        						'theme_location' => 'primary',
	        						'menu_class'     => 'primary-menu',
	        					 ) );
	        				?>
	        			</nav>
	        		<?php endif; ?>

			      </div>
			    </div>
			  </div>
				



			  <!-- custom header end -->

				<div class="site-header-main hidden">

					<div class="site-branding">
						<?php twentysixteen_the_custom_logo(); ?>

						<?php if ( is_front_page() && is_home() ) : ?>
							<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
						<?php else : ?>
							<p class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></p>
						<?php endif;

						$description = get_bloginfo( 'description', 'display' );
						if ( $description || is_customize_preview() ) : ?>
							<p class="site-description"><?php echo $description; ?></p>
						<?php endif; ?>
					</div><!-- .site-branding -->

					<?php if ( has_nav_menu( 'primary' ) || has_nav_menu( 'social' ) ) : ?>
						<button id="menu-toggle" class="menu-toggle"><?php _e( 'Menu', 'twentysixteen' ); ?></button>

						<div id="site-header-menu" class="site-header-menu">
							<?php if ( has_nav_menu( 'primary' ) ) : ?>
								<nav id="site-navigation" class="main-navigation" role="navigation" aria-label="<?php esc_attr_e( 'Primary Menu', 'twentysixteen' ); ?>">
									<?php
										wp_nav_menu( array(
											'theme_location' => 'primary',
											'menu_class'     => 'primary-menu',
										 ) );
									?>
								</nav><!-- .main-navigation -->
							<?php endif; ?>

							<?php if ( has_nav_menu( 'social' ) ) : ?>
								<nav id="social-navigation" class="social-navigation" role="navigation" aria-label="<?php esc_attr_e( 'Social Links Menu', 'twentysixteen' ); ?>">
									<?php
										wp_nav_menu( array(
											'theme_location' => 'social',
											'menu_class'     => 'social-links-menu',
											'depth'          => 1,
											'link_before'    => '<span class="screen-reader-text">',
											'link_after'     => '</span>',
										) );
									?>
								</nav><!-- .social-navigation -->
							<?php endif; ?>
						</div><!-- .site-header-menu -->
					<?php endif; ?>

				</div><!-- .site-header-main -->

				<div class="hidden">
					<?php if ( get_header_image() ) : ?>
						<?php
							$custom_header_sizes = apply_filters( 'twentysixteen_custom_header_sizes', '(max-width: 709px) 85vw, (max-width: 909px) 81vw, (max-width: 1362px) 88vw, 1200px' );
						?>
						<div class="header-image">
							<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
								<img src="<?php header_image(); ?>" srcset="<?php echo esc_attr( wp_get_attachment_image_srcset( get_custom_header()->attachment_id ) ); ?>" sizes="<?php echo esc_attr( $custom_header_sizes ); ?>" width="<?php echo esc_attr( get_custom_header()->width ); ?>" height="<?php echo esc_attr( get_custom_header()->height ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>">
							</a>
						</div><!-- .header-image -->
					<?php endif; // End header image check. ?>
				</div>

			</header><!-- .site-header -->

			<div id="content" class="site-content">
