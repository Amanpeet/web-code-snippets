<?php
/*
Template Name: Home-Page-Template
*/
?>
<!-- the header -->
<?php get_header(); ?>


  <!-- Masonary grid -->

  <section class="home-masonary">
    <div class="row">
      <div class="container">

        <div class="grid">
            <div class="grid-item grid-item--width1"> 
              <div class="grid-content"> 
                <img src="<?php echo get_template_directory_uri(); ?>/img/masonary-1.jpg" alt="">
                <h3> BMW title text </h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                tempor incididunt ut labore et dolore magna aliqua. Ut .</p>
                <div class="grid-content-tools">
                  <p> 
                    <span class="left mini"> <i class="fa fa-thumbs-o-up" aria-hidden="true"></i> 1232 </span>
                    <span class="right mega"> <i class="fa fa-comments-o" aria-hidden="true"></i> 100 Comments</span>
                  </p>
                </div>
              </div>
            </div>
            <div class="grid-item grid-item--width3"> 
              <div class="grid-content"> 
                <img src="<?php echo get_template_directory_uri(); ?>/img/masonary-2.jpg" alt="">
                <h3> heading title text </h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea.</p>
                <div class="grid-content-tools">
                  <p> 
                    <span class="left mini"> <i class="fa fa-thumbs-o-up" aria-hidden="true"></i> 1232 </span>
                    <span class="right mega"> <i class="fa fa-comments-o" aria-hidden="true"></i> 100 Comments</span>
                  </p>
                </div>
              </div>
            </div>
            <div class="grid-item grid-item--width2"> 
              <div class="grid-content"> 
                <img src="<?php echo get_template_directory_uri(); ?>/img/masonary-3.jpg" alt="">
                <h3> heading title text </h3>
                <p>Lorem ipsum dolor sit amet, consectetur a.</p>
                <div class="grid-content-tools">
                  <p> 
                    <span class="left mini"> <i class="fa fa-thumbs-o-up" aria-hidden="true"></i> 1232 </span>
                    <span class="right mega"> <i class="fa fa-comments-o" aria-hidden="true"></i> 100 Comments</span>
                  </p>
                </div>
              </div>
            </div>
            <div class="grid-item grid-item--width4"> 
              <div class="grid-content"> 
                <img src="<?php echo get_template_directory_uri(); ?>/img/masonary-5.jpg" alt="">
                <h3> heading title text </h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                .</p>
                <div class="grid-content-tools">
                  <p> 
                    <span class="left mini"> <i class="fa fa-thumbs-o-up" aria-hidden="true"></i> 1232 </span>
                    <span class="right mega"> <i class="fa fa-comments-o" aria-hidden="true"></i> 100 Comments</span>
                  </p>
                </div>
              </div>
            </div>
            <div class="grid-item grid-item--width3"> 
              <div class="grid-content"> 
                <img src="<?php echo get_template_directory_uri(); ?>/img/masonary-4.jpg" alt="">
                <h3> heading title text </h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                tempor incididunt ut labore et dolore mag.</p>
                <div class="grid-content-tools">
                  <p> 
                    <span class="left mini"> <i class="fa fa-thumbs-o-up" aria-hidden="true"></i> 1232 </span>
                    <span class="right mega"> <i class="fa fa-comments-o" aria-hidden="true"></i> 100 Comments</span>
                  </p>
                </div>
              </div>
            </div>
            <div class="grid-item grid-item--width4"> 
              <div class="grid-content"> 
                <img src="<?php echo get_template_directory_uri(); ?>/img/masonary-4.jpg" alt="">
                <h3> heading title text </h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                tempor incididunt ut labore et dolore magna aliqua. Ut .</p>
                <div class="grid-content-tools">
                  <p> 
                    <span class="left mini"> <i class="fa fa-thumbs-o-up" aria-hidden="true"></i> 1232 </span>
                    <span class="right mega"> <i class="fa fa-comments-o" aria-hidden="true"></i> 100 Comments</span>
                  </p>
                </div>
              </div>
            </div>
            <div class="grid-item grid-item--width1"> 
              <div class="grid-content"> 
                <img src="<?php echo get_template_directory_uri(); ?>/img/masonary-3.jpg" alt="">
                <h3> heading title text </h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                tempor incididunt ut labore et.</p>
                <div class="grid-content-tools">
                  <p> 
                    <span class="left mini"> <i class="fa fa-thumbs-o-up" aria-hidden="true"></i> 1232 </span>
                    <span class="right mega"> <i class="fa fa-comments-o" aria-hidden="true"></i> 100 Comments</span>
                  </p>
                </div>
              </div>
            </div>
            <div class="grid-item grid-item--width3"> 
              <div class="grid-content"> 
                <!-- <img src="<?php echo get_template_directory_uri(); ?>/img/masonary-2.jpg" alt=""> -->
                <h3> heading title text </h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                quis nostrud exercitation u.</p>
                <div class="grid-content-tools">
                  <p> 
                    <span class="left mini"> <i class="fa fa-thumbs-o-up" aria-hidden="true"></i> 1232 </span>
                    <span class="right mega"> <i class="fa fa-comments-o" aria-hidden="true"></i> 100 Comments</span>
                  </p>
                </div>
              </div>
            </div>

        </div>
      </div>
     
    </div>
  </section>

  <section class="home-trendy">
    <div class="container">

      <h2>Trending Questions</h2>
      
      <ul class="home-trendy-list">

        <li>
          <div class="left half">
            <img class="ques-icon" src="<?php echo get_template_directory_uri(); ?>/img/ques_icon.png" alt="">
            <h3 class="ques-title">What are we even doing on earth?</h3>
            <p class="greyed">Category- <span class="ques-category">Nature and Space</span> </p>
          </div>
          <div class="right half">
            <p>
              <span class="greyed">Last Updated</span> <span class="ques-updated"> Today at 4:24AM </span>
              <i class="fa fa-comments-o" aria-hidden="true"></i> <span class="ques-comments"> 123 </span>
              <span class="ques-emoji">
                <i style="color:forestgreen" class="fa fa-smile-o" aria-hidden="true"></i>
                <i style="color:dodgerblue" class="fa fa-smile-o" aria-hidden="true"></i>
                <i style="color:orange" class="fa fa-smile-o" aria-hidden="true"></i>
                <i style="color:crimson" class="fa fa-smile-o" aria-hidden="true"></i>
              </span>
            </p>
          </div>
        </li>  

        <li>
          <div class="left half">
            <img class="ques-icon" src="<?php echo get_template_directory_uri(); ?>/img/ques_icon.png" alt="">
            <h3 class="ques-title">What are we even doing on earth?</h3>
            <p class="greyed">Category- <span class="ques-category">Nature and Space</span> </p>
          </div>
          <div class="right half">
            <p>
              <span class="greyed">Last Updated</span> <span class="ques-updated"> Today at 4:24AM </span>
              <i class="fa fa-comments-o" aria-hidden="true"></i> <span class="ques-comments"> 123 </span>
              <span class="ques-emoji">
                <i style="color:forestgreen" class="fa fa-smile-o" aria-hidden="true"></i>
                <i style="color:dodgerblue" class="fa fa-smile-o" aria-hidden="true"></i>
                <i style="color:orange" class="fa fa-smile-o" aria-hidden="true"></i>
                <i style="color:crimson" class="fa fa-smile-o" aria-hidden="true"></i>
              </span>
            </p>
          </div>
        </li>  

        <li>
          <div class="left half">
            <img class="ques-icon" src="<?php echo get_template_directory_uri(); ?>/img/ques_icon.png" alt="">
            <h3 class="ques-title">What are we even doing on earth?</h3>
            <p class="greyed">Category- <span class="ques-category">Nature and Space</span> </p>
          </div>
          <div class="right half">
            <p>
              <span class="greyed">Last Updated</span> <span class="ques-updated"> Today at 4:24AM </span>
              <i class="fa fa-comments-o" aria-hidden="true"></i> <span class="ques-comments"> 123 </span>
              <span class="ques-emoji">
                <i style="color:forestgreen" class="fa fa-smile-o" aria-hidden="true"></i>
                <i style="color:dodgerblue" class="fa fa-smile-o" aria-hidden="true"></i>
                <i style="color:orange" class="fa fa-smile-o" aria-hidden="true"></i>
                <i style="color:crimson" class="fa fa-smile-o" aria-hidden="true"></i>
              </span>
            </p>
          </div>
        </li>  

        <li>
          <div class="left half">
            <img class="ques-icon" src="<?php echo get_template_directory_uri(); ?>/img/ques_icon.png" alt="">
            <h3 class="ques-title">What are we even doing on earth?</h3>
            <p class="greyed">Category- <span class="ques-category">Nature and Space</span> </p>
          </div>
          <div class="right half">
            <p>
              <span class="greyed">Last Updated</span> <span class="ques-updated"> Today at 4:24AM </span>
              <i class="fa fa-comments-o" aria-hidden="true"></i> <span class="ques-comments"> 123 </span>
              <span class="ques-emoji">
                <i style="color:forestgreen" class="fa fa-smile-o" aria-hidden="true"></i>
                <i style="color:dodgerblue" class="fa fa-smile-o" aria-hidden="true"></i>
                <i style="color:orange" class="fa fa-smile-o" aria-hidden="true"></i>
                <i style="color:crimson" class="fa fa-smile-o" aria-hidden="true"></i>
              </span>
            </p>
          </div>
        </li>  

        <li>
          <div class="left half">
            <img class="ques-icon" src="<?php echo get_template_directory_uri(); ?>/img/ques_icon.png" alt="">
            <h3 class="ques-title">What are we even doing on earth?</h3>
            <p class="greyed">Category- <span class="ques-category">Nature and Space</span> </p>
          </div>
          <div class="right half">
            <p>
              <span class="greyed">Last Updated</span> <span class="ques-updated"> Today at 4:24AM </span>
              <i class="fa fa-comments-o" aria-hidden="true"></i> <span class="ques-comments"> 123 </span>
              <span class="ques-emoji">
                <i style="color:forestgreen" class="fa fa-smile-o" aria-hidden="true"></i>
                <i style="color:dodgerblue" class="fa fa-smile-o" aria-hidden="true"></i>
                <i style="color:orange" class="fa fa-smile-o" aria-hidden="true"></i>
                <i style="color:crimson" class="fa fa-smile-o" aria-hidden="true"></i>
              </span>
            </p>
          </div>
        </li>        
      </ul>

      <a class="btn-mini" href="#">LOAD MORE</a>

    </div>
  </section>

  <section class="home-about">

    <div class="row">
      <div class="container">
        
        <div class="left mega">
          <h2>About us</h2>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
          tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
          quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
          consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
          cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
          proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        </div>

        <div class="right mini">
          <div class="home-about-circles"> <h2>How we works?</h2> </div>
          <div class="home-about-circles"> <h2>Why we made it?</h2> </div>
        </div>
        
      </div>      
    </div>

  </section>


<!-- the footer -->
<?php get_footer(); ?>
