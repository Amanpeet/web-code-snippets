<?php
echo "This is the header content<br>";
echo "This is the main content<br>";
echo "This is the footer content<br>";
include "counter.php";
?>