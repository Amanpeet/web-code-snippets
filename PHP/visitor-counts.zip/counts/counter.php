<!-- for html/php  -->
<?php
	$counter_name = "counter.txt";
	if (!file_exists($counter_name)) {
	  $f = fopen($counter_name, "w");
	  fwrite($f,"0"); fclose($f);
	}
	$f = fopen($counter_name,"r");
	$counterVal = fread($f, filesize($counter_name));
	fclose($f);
	$counterVal++;
	$f = fopen($counter_name, "w");
	fwrite($f, $counterVal);
	fclose($f);
	echo "visitor number $counterVal";
?>

<!-- for wordpress -->
<div class="visitor-counter">
  <?php
    global $wpdb;
    $user_count = $wpdb->get_var( "SELECT visits FROM counter" );
    $user_count = $user_count + 1;
    $result = $wpdb->query( $wpdb->prepare("UPDATE counter SET visits = $user_count ") );
    if($result > 0){
      echo "Successfully Updated";
    }
    else{
      exit( var_dump( $wpdb->last_query ) );
    }
  ?>
  <p>Total Visits: <span> <?php echo $user_count; ?> </span> </p>
</div>