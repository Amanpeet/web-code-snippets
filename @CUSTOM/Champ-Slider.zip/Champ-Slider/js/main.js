// calling all the functions
$(document).ready(function(){

	champSlider(5);

});


// functions definitions

/**************************************************
  champSlider v1.0 for home page
**************************************************/

function champSlider(time) {

  var slideChangeTime = time * 1000;
  // $("#champ-slider-list li").css("transition","all 0.5s ease");

  //declaring current next and previous cards 
  var current = $(".active-slide");
  var nextx = $(".active-slide").next();
  var prevx = $("#champ-slider-list li:last-child");

  //for first time moving
  current.nextAll().addClass("move-right");

  //fucntion to change slides
  function changeSlide(e) {
  	//removing all classes
    current.removeClass("active-slide");    
    $("#champ-slider-list li").removeClass("move-left");
    $("#champ-slider-list li").removeClass("move-right");

    //adding class to current slide
    $(e).addClass("active-slide");

    //reset variables
    current = $(".active-slide");
    nextx = $(".active-slide").next();
    prevx = $(".active-slide").prev();

    //moving all other slides
    current.nextAll().addClass("move-right");
    current.prevAll().addClass("move-left");

    //if no prev slide
    if (prevx.length === 0) {
      prevx = $("#champ-slider-list li:last-child");
    }

    //if no next slide
    if (nextx.length === 0) {
      nextx = $("#champ-slider-list li:first-child");
    }

    //clear interval and restart autoTimer
    clearInterval(resetTimer);
    autoTimer();

  }


  //declaring dots
  var currentControl = $(".active-control");
  var nextxControl = $(".active-control").next();
  var prevxControl = $("#champ-controls-list li:last-child");

  //changing the dots
  function changeControls(f) {  	

    $("#champ-controls-list li").removeClass("active-control");
    $(f).addClass("active-control");

    //reset dots
    currentControl = $(".active-control");
    nextxControl = $(".active-control").next();
    prevxControl = $(".active-control").prev();

    //if no prev dot
    if (prevxControl.length === 0) {
      prevxControl = $("#champ-controls-list li:last-child");
    }

    //if no next dot
    if (nextxControl.length === 0) {
      nextxControl = $("#champ-controls-list li:first-child");
    }

    //clear interval and restart autoTimer
    clearInterval(resetTimer);
    autoTimer();
  }


  //////////////////////////////////////////////


  //the automatic timer with clear
  var resetTimer;

  //checking parameter from function call
	function autoTimer() {
    resetTimer = setInterval(function() {
      changeSlide(nextx);
      changeControls(nextxControl);
    }, slideChangeTime);
	}
  
  //calling autoTimer for first start
  autoTimer();


  //on next Button click
  $("#slider-next").click(function() {
    //calling the change
    changeSlide(nextx);
    changeControls(nextxControl);
  });

  //on previous Button click
  $("#slider-prev").click(function() {
    //calling the change
    changeSlide(prevx);
    changeControls(prevxControl);
  });



  /*controls*/

  $("#champ-controls-list li").click(function(event) {
  	event.preventDefault();
  	//get index of clicked li
  	var listElement = $(this).index() + 1;
  	//alert(listElement);

  	//change slides n controls
    changeSlide("#champ-slider-list li:nth-child("+ listElement +")");
    changeControls("#champ-controls-list li:nth-child("+ listElement +")");
  });



  //NOW FOR THE TOUCH SWIPE CONTROLS
  function isTouchDevice() {
      return true === ("ontouchstart" in window || window.DocumentTouch && document instanceof DocumentTouch);
  }
  if (isTouchDevice() === true) {
      //your logic for touch device here
      //alert('Touch Device');
      $("header").on( "swipeleft", function(){        
        //calling the change
        // alert("swiped left");
        changeSlide(prevx);
        changeControls(prevxControl);
        changeTitles(prevxTitle);
      });  

      $("header").on( "swiperight", function(){        
        //calling the change
        // alert("swiped right");
        changeSlide(nextx);
        changeControls(nextxControl);
        changeTitles(nextxTitle);
      });

  } else {
      //your logic for non touch device here
      //alert('Not a Touch Device');
  }

} //champSlider end
