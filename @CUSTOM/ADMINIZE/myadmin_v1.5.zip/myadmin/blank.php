<!-- include header -->
<?php include('inc/header.php'); ?>

<!-- content goes here -->

<h1>Welcome Admin</h1>
<p>Click on link in left sidebar to proceed to further controls.</p>


<!-- include header -->
<?php include('inc/footer.php'); ?>