<?php
session_start();
include("connection.php");

$error = "";
if(isset($_POST["submit"])) {

  if(empty($_POST["username"]) || empty($_POST["password"])) {
    $error = "Both fields are required.";
  } else  {
    $username=$_POST['username'];
    $password=$_POST['password'];

    // To protect from MySQL injection
    $username = stripslashes($username);
    $password = stripslashes($password);
    $username = mysqli_real_escape_string($conn, $username);
    $password = mysqli_real_escape_string($conn, $password);
    $password = md5($password);

    //Check username and password from database
    $sql = "SELECT * FROM users WHERE username='$username' and password='$password'";
    $result = mysqli_query($conn,$sql);
    $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
    // echo $row['username'];
    //If exist in our database then create session else echo error.
    if(mysqli_num_rows($result) == 1) {
      $_SESSION['username'] = $row['username']; // Initializing Session
      header("location: main.php"); // Redirect
    } else {
      $error = "Incorrect username or password.";
    }
  }
} else {
  echo "Bad request";
}
 
?>