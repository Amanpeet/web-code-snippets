<!-- include header -->
<?php include('inc/header.php'); ?>

<!-- content goes here -->
<h3>Add New Data</h3>
<p>New Data registration form.</p>
<hr>

<div class="row">
  <div class="col-md-8 col-lg-8">
    <div class="form-box">
      <form id="id_card_form" name="id_card_form" action="" method="post" enctype="multipart/form-data">
        <div class="form-row">
          <div class="form-group col-sm-6">
            <label for="">Enrollment Number</label>
            <input type="text" class="form-control" name="enroll_num" required placeholder="Enrollment Number">
          </div>
          <div class="form-group col-sm-6">
            <label for="">ID Number</label>
            <input type="text" class="form-control" name="roll_num" required placeholder="ID Number">
          </div>
        </div>
        <hr>
        <div class="form-row">
          <div class="form-group col-sm-8">
            <label for="">Full Name</label>
            <input type="text" class="form-control" name="sname" required placeholder="Full Name">
          </div>
          <div class="form-group col-sm-4">
            <label for="">Date of Birth</label>
            <input type="text" class="form-control" name="sdob" required placeholder="Date Of Birth">
          </div>
        </div>
        <div class="form-row">
          <div class="form-group col-sm-6">
            <label for="">Father Name</label>
            <input type="text" class="form-control" name="sfather" required placeholder="Father Name">
          </div>
          <div class="form-group col-sm-6">
            <label for="">Mother Name</label>
            <input type="text" class="form-control" name="smother" required placeholder="Mother Name">
          </div>
        </div>
        <div class="form-row">
          <div class="form-group col-sm-6">
            <label for="">Course</label>
            <input type="text" class="form-control" name="scourse" required placeholder="Course">
          </div>
          <div class="form-group col-sm-6">
            <label for="">Session</label>
            <input type="text" class="form-control" name="ssession" required readonly placeholder="Session">
          </div>
        </div>
        <div class="form-row">
          <div class="form-group col-sm-6">
            <label for="">Upload Signature</label>
            <input type="file" class="form-control-file" name="spic_sign">
          </div>
          <div class="form-group col-sm-6">
            <label for="">Upload Image</label>
            <input type="file" class="form-control-file" name="spic_face">
          </div>
        </div>
        <hr>
        <div class="text-left mt-3 pt-2">
          <input type="submit" class="btn btn-primary" name="add_student" value="Add Data"> 
          <br><br>
        </div>
      </form>
    </div>
  </div>
</div>
<!-- End row -->

<?php
	if(isset($_POST['add_student'])){
		$upload     = '';
		$enroll_num = mysqli_real_escape_string($conn, $_POST['enroll_num']);
		$roll_num   = mysqli_real_escape_string($conn, $_POST['roll_num']);
		$sname      = mysqli_real_escape_string($conn, $_POST['sname']);
		$sfather    = mysqli_real_escape_string($conn, $_POST['sfather']);
		$smother    = mysqli_real_escape_string($conn, $_POST['smother']);
		$sdob       = mysqli_real_escape_string($conn, $_POST['sdob']);
		$scourse    = mysqli_real_escape_string($conn, $_POST['scourse']);
		$ssession   = mysqli_real_escape_string($conn, $_POST['ssession']);

    if( empty($enroll_num) || empty($roll_num) || empty($sname) || empty($sfather) || empty($smother) || empty($sdob) || empty($scourse) || empty($ssession) ){
      echo "<strong>ERROR: Invalid or Empty Fields. Please try again.</strong>";
    } else {
      // check if not existing      
      $checkexisting = "SELECT * FROM student_details WHERE enroll_num = '$enroll_num' ";
      $checkque = mysqli_query($conn, $checkexisting);
      if(mysqli_num_rows($checkque) > 0){
        echo "<strong>ERROR: Student with same Enrollment number already exists.</strong>";
      } else {
        // finally upload images
        $uniqd = round(microtime(true));

        $temp1        = explode(".", $_FILES["spic_sign"]["name"]);
        $newfilename1 = $uniqd . '_sign' . '.' . end($temp1);
        $imagetmp1    = trim($_FILES['spic_sign']['tmp_name']);
        $path1        = "upload/".$newfilename1;
        move_uploaded_file($imagetmp1, $path1);

        $temp2        = explode(".", $_FILES["spic_face"]["name"]);
        $newfilename2 = $uniqd . '_face' . '.' . end($temp2);
        $imagetmp2    = trim($_FILES['spic_face']['tmp_name']);
        $path2        = "upload/".$newfilename2;
        move_uploaded_file($imagetmp2, $path2);

        // add student to db
    		$insert = "INSERT INTO student_details(enroll_num, roll_num, sname, sfather, smother, sdob, scourse, ssession, spic_sign, spic_face) VALUES('$enroll_num','$roll_num','$sname','$sfather','$smother','$sdob','$scourse','$ssession','$newfilename1','$newfilename2')";
    		$que = mysqli_query($conn, $insert);
    		if($que){
    			echo "<strong>SUCCESS: New Student Added.";
    		}
    		else{
    			echo "<strong>ERROR: Student not added. Please try again later.</strong>";
    		}
      }
    }
	}
?>

<!-- include header -->
<?php include('inc/footer.php'); ?>