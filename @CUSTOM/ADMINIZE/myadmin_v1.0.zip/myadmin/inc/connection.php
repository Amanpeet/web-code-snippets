<?php
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'admin');
define('DB_PASSWORD', 'password0');
define('DB_DATABASE', 'admin_db');
$conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_DATABASE) 
or die("Connection error: " . mysqli_connect_error());
?>