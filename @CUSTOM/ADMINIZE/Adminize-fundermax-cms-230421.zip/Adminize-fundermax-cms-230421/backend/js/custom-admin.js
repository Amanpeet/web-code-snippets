(function($) {


})(jQuery); // End of use strict
