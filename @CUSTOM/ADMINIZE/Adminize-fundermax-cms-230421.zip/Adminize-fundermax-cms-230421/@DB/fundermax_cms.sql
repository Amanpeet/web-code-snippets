-- phpMyAdmin SQL Dump
-- version 4.9.11
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 21, 2023 at 09:59 PM
-- Server version: 5.7.42
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `careerpointchd_fundermax_cms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `uid` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `fullname` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  `dated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`uid`, `username`, `password`, `role`, `email`, `phone`, `fullname`, `status`, `dated`) VALUES
(1, 'admin', '1e36159b6624810385a47004abba06ab', 'admin', 'binarymatter@gmail.com', '', '', '', '2022-08-15 12:17:58'),
(5, 'master', 'a01a5d67cb853b6658b3728bcea71fdc', 'admin', 'example@mail.com', '', '', '', '2022-08-15 12:17:59');

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `bid` int(11) NOT NULL,
  `blog_title` text NOT NULL,
  `blog_permalink` text NOT NULL,
  `blog_image` varchar(400) NOT NULL,
  `blog_content` text NOT NULL,
  `blog_date` varchar(100) NOT NULL,
  `blog_description` text NOT NULL,
  `blog_keywords` text NOT NULL,
  `dated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`bid`, `blog_title`, `blog_permalink`, `blog_image`, `blog_content`, `blog_date`, `blog_description`, `blog_keywords`, `dated`) VALUES
(1, 'New Tech Requires a Broader Approach', 'new-tech-requires-a-broader-approach', 'blog_1661414576.jpg', '<p>For quite a long time web pages were the alpha and omega of the internet experience. However, in the last few years the software market has evolved with a speed that was never seen before. We read about new devices every day, and smartphones and tablets have become ubiquitous in our lives.</p>\r\n<p>Designing for mobile screen is different from designing for the desktop, but it can\'t be compared to extra-small screens such as the watchface of a smartwatch. There\'s not too much place for glossy design elements on most wearables.</p>\r\n<p>They need to be functional, and designers need to <strong>focus more on how users interact with the screen</strong>. Interaction with the screen also has many new methods such as <strong>gestures, voice control </strong>and<strong> facial expressions</strong>.</p>', '18/08/2022', 'For quite a long time web pages were the alpha and omega of the internet experience. ', 'key1, key2', '2022-08-15 17:17:17'),
(2, 'Traditional LAMP Development', 'traditional-lamp-development', 'blog_1661414614.jpg', '<p>Most developers should know about the traditional LAMP stack because its been around since the early web. <strong>LAMP</strong> stands for <strong>Linux, Apache, MySQL</strong> and <strong>PHP</strong>. Each of these are individual software packs that are combined to form a versatile server solution. The biggest reason to stick with LAMP is security and widespread support. It has been around for decades, and its a proven method of hosting websites.</p>\r\n<p>All the backend tech like PHP and MySQL are well known, and <strong>supported by every major hosting provider</strong>. If you work on a LAMP stack you can basically host anywhere. Additionally, you get <strong>access to the most popular CMS engines</strong>. WordPress, Drupal, and Joomla all run on PHP/MySQL.</p>', '21/08/2022', 'Most developers should know about the traditional LAMP stack because its been around since the early web. ', 'word1, word2, word3', '2022-08-15 17:17:17'),
(3, 'Cyberpunk is incoming 2020', 'cyberpunk-is-incoming-2020', 'blog_1661414632.jpg', 'Global software solution company, we use the latest in trend technologies including Blockchain, NLP, AI and ML to scale up your business web applications to the upcoming technologies. We also develop the best in-class IT applications from scratch by accelerating speed to get you on new technologies platforms with aim to deliver the industry solutioning the best ever wether it is web, mobile or any other devices.Our in-depth technologies experts helped various customers across globe in designing and developing realistic business use cases to performing IT application with integration to various industries junctions through exemplary APIâ€™s developments.', '12/08/2022', '', '', '2022-08-15 17:17:17'),
(4, 'Lending a Helping Hand', 'lending-a-helping-hand', 'blog_1661414660.jpg', 'Really wish i didn\'t have to compress the images and convert to jpg to be under 5 mb. They lose so much quality :(. For some reason it wont let me post anything over 5mb. the original 4k versions all clock in at around 10-13mb. If anyone knows how to change this, please let me know. They still look good. Sorry i forget to remove the HUD sometimes. Aequinoctium is still my only go to weather mod though.', '22/08/2022', '', '', '2022-08-15 17:17:17'),
(7, 'test', 'test', 'blog_1664957875.jpg', '<h2>heading</h2><p>Use our powerful mobile-<sup>first </sup><strong>flexbox </strong>grid to build <em>layouts </em>of all \r\nshapes and <del>sizes </del><a href=\"#\"><del xmlns=\"http://www.w3.org/1999/xhtml\"></del>thanks</a>to a twelve column system, six default \r\nresponsive tiers, Sass variables and mixins, and dozens of predefined \r\nclasses.</p><ul><li>Use our powerful mobile-first <strong>flexbox </strong>grid to <br></li><li>build layouts of all \r\nshapes and sizes thanks to a twelve <br></li><li>column <em>system</em>, six <strong>default \r\n</strong>responsive tiers, Sass <del>variables</del></li><li>&nbsp;and mixins, and dozens of predefined \r\nclasses.</li></ul><p><br></p>', '29/09/2022', '', '', '2022-09-29 18:27:30');

-- --------------------------------------------------------

--
-- Table structure for table `documents`
--

CREATE TABLE `documents` (
  `did` int(11) NOT NULL,
  `doc_file` varchar(200) NOT NULL,
  `doc_caption` text NOT NULL,
  `doc_link` text NOT NULL,
  `doc_category` text NOT NULL,
  `doc_tags` text NOT NULL,
  `dated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `documents`
--

INSERT INTO `documents` (`did`, `doc_file`, `doc_caption`, `doc_link`, `doc_category`, `doc_tags`, `dated`) VALUES
(9, 'bcom-post.pdf', 'other one', '', 'other', 'interior-products', '2022-09-01 14:45:35'),
(13, 'exterior_kollektion_2019.pdf', 'Exterior_Kollektion_2019', '', 'other', '', '2022-09-02 22:07:51'),
(14, 'exterior_mlook_technik_gb_2019.pdf', 'Exterior_MLOOK_Technik_GB_2019', '', 'other', '', '2022-09-02 22:14:14'),
(15, 'interior_2019_gb_web.pdf', 'Interior_2019_GB_web', '', 'other', '', '2022-09-02 22:26:05'),
(16, 'interior_max_resistance_gb_web.pdf', 'Interior_Max_Resistance_GB_web', '', 'other', '', '2022-09-02 22:26:11'),
(17, 'interior_maxcabinacatalouge2020.pdf', 'Interior_Max-Cabina-catalouge-2020', '', 'other', '', '2022-09-02 22:26:16'),
(21, 'bba_certificate_max_exterior_cladding_panels_2015_to_2018.pdf', 'BBA Certificate Max Exterior Cladding Panels (2015 - 2018)', '', 'certificates', '', '2023-04-18 15:07:02'),
(22, 'chipboard_hfa_inspection_confirmations_homogen_2018.pdf', 'Chipboard HFA Inspection Confirmations Homogen 2018', '', 'certificates', '', '2023-04-18 15:11:20'),
(23, 'eu_-_fire_test_en13501-1_max_exterior_f-qualitaet_6-20_mm__en_.pdf', 'EU - Fire test EN13501-1 MAX Exterior F-Qualitaet 6-20 mm', '', 'certificates', '', '2023-04-18 15:11:56'),
(24, 'exterior_technik_2018_gb_web.pdf', 'Exterior Technik 2018 GB web', '', 'certificates', '', '2023-04-18 15:12:24'),
(25, 'exterior_technik_2018_material_handling.pdf', 'Exterior Technik 2018 Material Handling', '', 'certificates', '', '2023-04-18 15:13:19'),
(26, 'fire_en13501_-classification_b-s1_d0_-_particle_board_20170727.pdf', 'Fire EN13501 -Classification B-s1 - Particle Board', '', 'certificates', '', '2023-04-18 15:16:45'),
(27, 'fsc_certificate_sgsch-coc-110046-1_fsc_en_de.pdf', 'FSC certificate SGSCH-COC-110046-1 FSC', '', 'certificates', '', '2023-04-18 15:17:50'),
(28, 'fundermax_cleaning_decor_process.pdf', 'Fundermax Cleaning Decor Process', '', 'certificates', '', '2023-04-18 15:19:24'),
(29, 'gb_-_fire_test_bs_476-6_max_compact_f-quality_6_mm_engl.pdf', 'GB - Fire test BS 476-6 MAX Compact F quality 6mm', '', 'certificates', '', '2023-04-18 15:19:53'),
(30, 'gb_-_fire_test_bs_476-7_max_compact_6_mm_engl.pdf', 'GB - Fire test BS 476-7 MAX Compact 6mm', '', 'certificates', '', '2023-04-18 15:21:27'),
(31, 'gb_-_fire_test_bs_476-7_max_compact_f-quality_6_mm_engl.pdf', 'GB - Fire test BS 476-7 MAX Compact F-Quality 6mm', '', 'certificates', '', '2023-04-18 15:22:05'),
(32, 'greenguard_certification_max_compact.pdf', 'GREENGUARD Certification Max Compact', '', 'certificates', '', '2023-04-18 15:24:20'),
(33, 'greenguard_certification_max_compact_interior_plus.pdf', 'GREENGUARD Certification Max Compact Interior Plus', '', 'certificates', '', '2023-04-18 15:24:48'),
(34, 'greenguard_certification_max_resistance2.pdf', 'GREENGUARD Certification Max Resistance', '', 'certificates', '', '2023-04-18 15:25:04'),
(35, 'iso_9001_iso_14001_iso_50001_iso_45001__en_.pdf', 'ISO 9001 ISO 14001 ISO 50001 ISO 45001', '', 'certificates', '', '2023-04-18 15:25:32'),
(36, 'iso_9001_iso_14001_ohsas_18001_iso_50001__en_.pdf', 'ISO 9001 ISO 14001 OHSAS 18001 ISO 50001', '', 'certificates', '', '2023-04-18 15:27:39'),
(37, 'm_look_en_reaction_to_fire_classification.pdf', 'M-look EN Reaction to Fire Classification', '', 'certificates', '', '2023-04-18 15:28:17'),
(38, 'pefc_certificate_sgsch_17_1060_00-1_pefc_en.pdf', 'PEFC certificate SGSCH 17 1060.00-1 PEFC', '', 'certificates', '', '2023-04-18 15:28:39'),
(39, 'sg_bs_476-6_universal_f_6_mm_f_psb_54s076071_2a_okh_b_e.pdf', 'SG BS 476-6 Universal F 6mm F PSB 54S076071 2A OKH BE', '', 'certificates', '', '2023-04-18 15:33:03'),
(40, 'sg_bs_476-7_universal_f_6_mm_f_psb_54s076071_1a_okh_b_e.pdf', 'SG BS 476-7 Universal F 6mm F PSB 54S076071 1A OKH BE', '', 'certificates', '', '2023-04-18 15:37:25'),
(41, 'us_-_fire_test_astm_e_84_max_exterior_f-quality_6_mm.pdf', 'US - Fire test ASTM E 84 MAX Exterior F-Quality 6mm', '', 'certificates', '', '2023-04-18 15:38:05'),
(42, 'exterior_technik_2020_gb_web.pdf', 'Exterior Technique 2020 GB', '', 'technical-information', '', '2023-04-18 15:54:44'),
(43, 'ti_compact_interior_gb_2020.pdf', 'Interior Technique 2020 GB', '', 'technical-information', '', '2023-04-18 15:58:16'),
(44, 'mlook_technique_gb_2020.pdf', 'M.look Technique 2020 GB', '', 'technical-information', '', '2023-04-18 15:59:33'),
(45, 'pi-produktdatenblatt_star_favorit-18905en.pdf', 'Star Favorit & Superfront Technical Datasheet', '', 'technical-information', 'Particleboard & Melamine Faced Chipboards', '2023-04-18 16:03:12'),
(46, 'how-green-is-your-cladding.pdf', 'How Green is your Cladding', '', 'knowledge-corner', '', '2023-04-18 16:09:58'),
(47, 'tips-extract-bestperformancefromfundermax-highpressurelaminates.pdf', 'Tips to extract best performance from Fundermax High Pressure Laminates (HPL)', '', 'knowledge-corner', '', '2023-04-18 16:10:16'),
(48, 'antaraya_2013.pdf', 'Antaraya 2013', '', 'in-the-news', '', '2023-04-18 16:19:13'),
(49, 'antarya_may-june15_10-13.pdf', 'Antarya May - June', '', 'in-the-news', '', '2023-04-18 16:20:00'),
(50, 'app_ache_june_2019.pdf', 'App Ache June 2019', '', 'in-the-news', '', '2023-04-18 16:23:57'),
(51, 'architect___interiors_india.pdf', 'Architect Interiors India', '', 'in-the-news', '', '2023-04-18 16:24:12'),
(52, 'article_in_w_f_magazine_-_june15.pdf', 'Article in W F Magazine - June,15', '', 'in-the-news', '', '2023-04-18 16:24:31'),
(53, 'home_review_-_may2015.pdf', 'Home Review - May 2015', '', 'in-the-news', '', '2023-04-18 16:24:49'),
(54, 'ia_b_2014.pdf', 'IA B 2014', '', 'in-the-news', '', '2023-04-18 16:28:15'),
(55, 'material_poetries_1_surfaces_oct_2019.pdf', 'Material Poetries 1 Surfaces Oct 2019', '', 'in-the-news', '', '2023-04-18 16:28:31'),
(56, 'surfacesreporter_jan_2020.pdf', 'Surfaces Reporter Jan 2020', '', 'in-the-news', '', '2023-04-18 16:28:47'),
(57, '', 'Kinematic Facades are the Future - Interview with Ashwani Khanna, AVP Marketing, Fundermax - Issuu', 'https://issuu.com/wfm-india/docs/36th_edition__sep-oct20___1_/s/11104823', 'in-the-news', '', '2023-04-21 21:43:49'),
(58, '', 'Trending Cladding Material in the Indian Exterior Cladding Industry (wfmmedia.com)', 'https://wfmmedia.com/trends-in-the-indian-exterior-cladding-industry/', 'in-the-news', '', '2023-04-21 21:53:32'),
(59, '', 'Design Debate rediscovers Udaipur! - Architect and Interiors India', 'https://www.architectandinteriorsindia.com/events/design-debate-edition-7-udaipur', 'in-the-news', '', '2023-04-21 21:54:00'),
(60, '', 'Roofing, cladding & waterproofing: Make them strong - Construction Week India (constructionweekonline.in)', 'https://www.constructionweekonline.in/business/17953-roofing-cladding-waterproofing-make-them-strong', 'in-the-news', '', '2023-04-21 21:54:13'),
(61, '', 'The way High Pressure Laminates are weaving its way into construction - Construction Week India (constructionweekonline.in)', 'https://www.constructionweekonline.in/business/12426-the-way-high-pressure-laminates-are-weaving-its-way-into-construction', 'in-the-news', '', '2023-04-21 21:54:28'),
(62, '', 'Rear-ventilated faÃ§ade system is a design that is trending today. - Top Construction & Infrastructure magazine (constructiontimes.co.in)', 'https://constructiontimes.co.in/rear-ventilated-facade-system-is-a-design-that-is-trending-today/', 'in-the-news', '', '2023-04-21 21:54:42'),
(63, '', 'Cladding Elements contributing to Sustainable Facade Systems (wfmmedia.com)', 'https://wfmmedia.com/cladding-elements-contributing-to-sustainable-facade-systems/', 'in-the-news', '', '2023-04-21 21:54:55'),
(64, '', 'Exterior Cladding Ideas | How to Handle Problems with High Pressure Laminates? (surfacesreporter.com)', 'https://surfacesreporter.com/articles/51340/how-to-handle-problems-with-high-pressure-laminates', 'in-the-news', '', '2023-04-21 21:55:07');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `gid` int(11) NOT NULL,
  `gal_image` varchar(200) NOT NULL,
  `gal_tags` text NOT NULL,
  `gal_caption` text NOT NULL,
  `gal_featured` varchar(10) NOT NULL,
  `dated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`gid`, `gal_image`, `gal_tags`, `gal_caption`, `gal_featured`, `dated`) VALUES
(9, 'gal_1661841759.jpg', 'exterior-products', 'Max Lato', '', '2022-08-30 12:12:38'),
(10, 'gal_1661841778.jpg', 'exterior-products', 'Facade Lapsiding', '1', '2022-08-30 12:12:58'),
(11, 'gal_1661842089.jpg', 'exterior-products', 'Soffit', '', '2022-08-30 12:18:08'),
(12, 'gal_1661842094.jpg', 'exterior-products', 'Perforation', '', '2022-08-30 12:18:13'),
(13, 'gal_1661842100.jpg', 'exterior-products', 'Signage', '1', '2022-08-30 12:18:19'),
(14, 'gal_1661842105.jpg', 'exterior-products', 'Gates', '1', '2022-08-30 12:18:24'),
(15, 'gal_1661842110.jpg', 'exterior-products', 'Facade', '1', '2022-08-30 12:18:30'),
(16, 'gal_1661842132.jpg', 'exterior-products', 'Balcony', '1', '2022-08-30 12:18:51'),
(17, 'gal_1661843091.jpg', 'exterior-products', 'M.look', '1', '2022-08-30 12:34:50'),
(18, 'gal_1661846409.jpg', '', 'Restroom Cubicles', '1', '2022-08-30 13:30:09'),
(21, 'gal_1661846452.jpg', '', 'Fumehoods', '1', '2022-08-30 13:30:51'),
(22, 'gal_1661846437.jpg', '', 'Laboratory Table Tops', '1', '2022-08-30 13:30:37'),
(23, 'gal_1661846425.jpg', 'interior-products', 'Star Favorit', '1', '2022-08-30 13:30:24'),
(24, 'gal_1662138721.jpg', 'interior-products', 'star favorit 2', '1', '2022-09-02 22:42:01'),
(25, 'gal_1681890340.jpg', 'success-stories', 'Anything but Convention-al', '', '2023-04-19 13:15:40'),
(26, 'gal_1681890358.jpg', 'success-stories', 'A residence that glows with warmth and premium finish', '', '2023-04-19 13:15:57'),
(27, 'gal_1681890372.jpg', 'success-stories', 'When light and shadow had fun in a playschool', '', '2023-04-19 13:16:12'),
(28, 'gal_1681890385.jpg', 'success-stories', 'Welcoming Guests with the Glow of Sunrise', '', '2023-04-19 13:16:24'),
(29, 'gal_1681890397.jpg', 'success-stories', 'An Amalgamation of Traditional & Contemporary', '', '2023-04-19 13:16:37'),
(30, 's6.jpg', 'success-stories', 'Gold plated looks. Glamorous experience', '', '2023-04-19 13:16:48'),
(31, 'gal_1681890447.jpg', 'success-stories', 'Nirguna Mandir: A CSR Initiative with GNA', '', '2023-04-19 13:17:27'),
(32, 'gal_1681890466.jpg', 'success-stories', 'Vasudhara Bhavan â€“ A treatise in conservation and modernism', '', '2023-04-19 13:17:45'),
(33, 'gal_1681890483.jpg', 'success-stories', 'Inspired by Cubism. Delivered by FunderMax.', '', '2023-04-19 13:18:02'),
(34, 'gal_1681890498.jpg', 'success-stories', 'Rani Residence: The house that turned into a traffic landmark', '', '2023-04-19 13:18:17'),
(35, 'gal_1681890510.jpg', 'success-stories', 'Making a statement. In white.', '', '2023-04-19 13:18:29'),
(36, 'gal_1681890527.jpg', 'success-stories', 'When the well-planned city gets a well-planned bungalow', '', '2023-04-19 13:18:47'),
(37, 'gal_1681890542.jpg', 'success-stories', 'Renovation done right', '', '2023-04-19 13:19:01'),
(38, 'gal_1681890578.jpg', 'success-stories', 'An office with a soft view of the hills', '', '2023-04-19 13:19:37'),
(39, 'gal_1681890592.jpg', 'success-stories', 'The finish of real wood', '', '2023-04-19 13:19:51'),
(40, 'gal_1681890606.jpg', 'success-stories', 'Stylish modernity in a historic city', '', '2023-04-19 13:20:05');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `pid` int(11) NOT NULL,
  `page_title` text NOT NULL,
  `page_permalink` text NOT NULL,
  `page_template` varchar(200) NOT NULL,
  `page_content` text NOT NULL,
  `page_image` varchar(200) NOT NULL,
  `page_sideimg` varchar(200) NOT NULL,
  `page_media` text NOT NULL,
  `page_description` text NOT NULL,
  `page_keywords` text NOT NULL,
  `dated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`pid`, `page_title`, `page_permalink`, `page_template`, `page_content`, `page_image`, `page_sideimg`, `page_media`, `page_description`, `page_keywords`, `dated`) VALUES
(2, 'About us', 'about-us', 'about-us.php', '<h2 class=\"mega-title\">Fundermax - Top Quality â€œMade in Austriaâ€</h2>\r\n\r\n<p>Fundermax values and processes natural raw materials. In the course of our sustainable production processes, we create high-quality wood-based materials and compact laminates. The result: a comprehensive portfolio that combines top quality and innovative design to impress. Fundermax offers the following products:</p>\r\n\r\n<ul>\r\n  <li>Raw chipboard panels</li>\r\n  <li>Coated chipboard panels (Star Favorit)</li>\r\n  <li>Laminate panels (HPL)</li>\r\n  <li>Compact panels (Max Compact Exterior and Max Compact Interior)</li>\r\n  <li>Biofaser panels (raw and decorative)</li>\r\n  <li>m.look Interior and Exterior</li>\r\n  <li>Premium Star</li>\r\n</ul>', '', 'page_1661847417.png', '', '', '', '2022-08-27 13:45:01'),
(5, 'Privacy Policy', 'privacy-policy', '', '<h3>General information</h3>\r\n\r\n<p>Thank you for visiting our website, and for your interest. The following notes give a simple overview of what happens to your personal information when you do so. Personal data is all data that personally identifies you. Detailed information on the subject of data protection can be found in our privacy policy below.<br>\r\n<br>\r\n<strong>How to contact us</strong><br>\r\nThe person responsible for the processing of personal data is the natural or legal person who, alone or in collaboration with others, decides on the purposes and means of processing personal data. FunderMax GmbH (Klagenfurter Strasse 87 - 89, A-9300 St.Veit / Glan, E-Mail: datenschutz@fundermax.biz) is responsible for data processing on this website in accordance with Art. 4 para. 7 of the General Data Protection Regulation (GDPR).<br>\r\n<br>\r\nIf you have any concerns/questions or would like to assert your rights in relation to the processing/use of your personal data, please use the contact info above. (See point 10).<br>\r\n<br>\r\n<strong>Third parties</strong><br>\r\nIn part, we use external service providers to process personal data (so-called processors). All of whom have been carefully selected and commissioned by us, are bound by our instructions and are regularly inspected.<br>\r\n<br>\r\nThe following processors/3rd parties are working on our behalf:<br>\r\n<strong>Google LLC,&nbsp;</strong>1600 Amphitheater Parkway, Mountain View, CA 94043, USA (See points 6, 7, 8, 9 below)<br>\r\n<strong>Hotjar Ltd</strong>, Level 2, St Julian\'s Business Center, 3, Elia Zammit Street, St Julian\'s STJ 1000, Malta, Europe (See point 8 below)<br>\r\n<br>\r\n<strong>Transactions outside the EEA</strong><br>\r\nAs a processor, we use, among others, Google LLC (\"Google\"), located at 1600 Amphitheater Parkway, Mountain View, CA 94043, USA, as well as&nbsp;VIMEO Inc. located at 555 West 18th Street, New York 10011.&nbsp;We will provide Google with your IP address (at most in anonymised form), information about website access (URL) and estimates of demographics and age. The legal basis for this transmission is our legitimate interest in the statistical analysis of user behaviour for the optimisation of our website and for marketing purposes (Art. 6 (1) (f) GDPR).\r\n</p>\r\n\r\n<p><br>\r\nGoogle and Vimeo are certified for the US-European Data Protection Convention \"Privacy Shield\", which ensures compliance with the data protection level applicable in the EU. In addition to our general and group-wide security policies, data will only be transmitted pseudonymously. A specific connection of the data to your person is therefore not possible.<br>\r\n<br>\r\nShould any recipients of your data be based in a state outside the European Economic Area (EEA), we will inform you about this fact and the guarantees relating to data security before any of your data is processed (eg. in the case of contract conclusion).<br>\r\n<br>\r\n<strong>Data collection on our website</strong><br>\r\n<br>\r\n<strong>How do we collect your data?</strong><br>\r\nShould you merely browse our website to gather information, ie if you do not register or otherwise provide us with information, we only collect data that your browser transmits to our server (so-called \"server log files\"). When you visit our website, we collect the following information that is technically necessary for us to display the website:<br>\r\n&nbsp;\r\n</p>\r\n\r\n<ul>\r\n<li>The pages you visited</li>\r\n<li>Date and time at the time of access</li>\r\n<li>Time Zone Difference to Greenwich Mean Time (GMT)</li>\r\n<li>Amount of data sent in bytes</li>\r\n<li>Source / reference from which you came to the page</li>\r\n<li>Access Status / HTTP status code</li>\r\n<li>Browser details</li>\r\n<li>Operating system used and its interface</li>\r\n<li>Language and version of the browser software</li>\r\n<li>Used IP address</li>\r\n</ul>\r\n\r\n<p><br>\r\nThe processing is carried out in accordance with Art. 6 para. 1 lit. f GDPR based on our legitimate interest in improving the stability and functionality of our website. A transfer or other use of data does not take place. However, we reserve the right to retrospectively check the server log files should concrete evidence point to unlawful use.<br>\r\n<br>\r\nThe data will be deleted as soon as it is no longer necessary for the purpose of its collection. Other personal data will only be saved if you use it by yourself, e.g. in the context of a registration, an application, a survey, a competition, an information request, order or to conclude or execute a contract.<br>\r\n<br>\r\n<strong>What do we use your data for?</strong><br>\r\n<br>\r\nPart of the data is collected to ensure a flawless performance of the website. Other data can be used to analyse your user behaviour.\r\n</p>\r\n\r\n\r\n\r\n\r\n<h2>Cookies</h2>\r\n\r\n<p>In order to make the visit to our website as enjoyable as possible, and to enable the use of certain functions, we use so-called cookies on various pages. These are small text files that are stored on your device. Some of the cookies we use are deleted after the end of the browser session, ie after closing your browser (so-called session cookies). Other cookies remain on your device and allow us, or our affiliates (third-party cookies) to recognise your browser on your next visit (persistent cookies). If cookies are set, they collect and process individual user information such as browser and location data as well as IP address values on an individual basis. Persistent cookies are automatically deleted after a specified period, which may differ depending on the cookie.<br>\r\n<br>\r\nIn some cases, cookies are used to simplify the ordering process by storing settings (for example, remembering the contents of a virtual shopping cart for a later visit to the website). Should personal data be processed using individual cookies implemented by us, the processing is carried out in accordance with Art. 6 para. 1 lit. b GDPR either for the execution of the contract or in accordance with Art. 6 para. 1 lit. f GDPR for safeguarding our legitimate interests and to offer the best possible functionality of the website, as well as ensure a customer-friendly and effective design for visitors.<br>\r\n<br>\r\nWe may work with advertising partners to help us make our website more interesting to you. In this case, when you visit our website, cookies from partner companies are stored on your hard disk (third-party cookies). If we cooperate with aforementioned advertising partners, you will be informed individually and separately about the use of such cookies and the scope of the information collected in the following paragraphs.<br>\r\n<br>\r\nPlease note that you can set your browser so that you are informed about the setting of cookies and individually decide on their acceptance or can exclude the acceptance of cookies for specific cases or in general. Each browser differs in the way it manages the cookie settings. This is described in the Help menu of each browser, which explains how to change your cookie settings. These can be found for the respective browser under the following links:<br>\r\n&nbsp;\r\n</p>\r\n\r\n<ul>\r\n<li><strong>Internet Explorer</strong>:&nbsp;<a href=\"http://windows.microsoft.com/en-US/windows-vista/Block-or-allow-cookie\" target=\"_blank\">windows.microsoft.com/en-US/windows-vista/Block-or-allow-cookie</a></li>\r\n<li><strong>Firefox</strong>:&nbsp;<a href=\"http://support.mozilla.org/en/kb/cookies-learn-and-approve\" target=\"_blank\">support.mozilla.org/en/kb/cookies-learn-and-approve</a></li>\r\n<li><strong>Chrome</strong>:&nbsp;<a href=\"http://support.google.com/chrome/bin/answer.py\" target=\"_blank\">support.google.com/chrome/bin/answer.py</a></li>\r\n<li><strong>Safari</strong>:&nbsp;<a href=\"http://support.apple.com/kb/ph21411\" target=\"_blank\">support.apple.com/kb/ph21411</a></li>\r\n<li><strong>Opera</strong>:&nbsp;<a href=\"http://help.opera.com/Windows/10.20/en/cookies.html\" target=\"_blank\">help.opera.com/Windows/10.20/en/cookies.html</a>&nbsp;</li>\r\n</ul>\r\n\r\n<p>Please note that if you do not accept cookies, the functionality of our website may be limited.</p>\r\n\r\n<p>Specifically, we use the following cookies:<br>\r\n&nbsp;&nbsp;<br>\r\nPHPSESSID (session)<br>\r\nPurpose: This cookie stores your current session with respect to PHP applications, ensuring that all features of this website based on the PHP programming language are fully displayed. Memory duration: Until the end of the browser session (will be cleared when closing your internet browser).</p>\r\n\r\n<p>Google Analytics<br>\r\n(_ga, _gat, _gat_UAXXXXXX-X, _gat_india, _gat_UA-56244915-1, _gid, __utma, __utmb, __utmc, __utmt, __utmz)<br>\r\nPurpose: These cookies are used to generate statistical information about our website access in order to generate reports and improve the usability of our website. For detailed information about all Google Analytics cookies, visit policies.google.com/technologies/types.</p>\r\n\r\n<p>Storage duration: For details, see developers.google.com/analytics/devguides/collection/analyticsjs/cookie-usage<br>\r\ncookie_notice_accepted / cookie_accept / disableCookieInfo<br>\r\nPurpose: When a user has consented, this cookie stores info on accepting the cookie statement.</p>\r\n\r\n<p>Storage duration: 1 month.</p>\r\n\r\n<p>_fbp<br>\r\nThis cookie is set by Facebook to deliver ads when they visit Facebook or a digital platform supported by Facebook ads after visiting this website.<br>\r\nStorage duaration: 3 months</p>\r\n\r\n<p>fr<br>\r\nThe cookie is set by Facebook to show, measure and improve relevant ads to users. The cookie also tracks the user\'s behavior across the web on pages that have the Facebook Pixel or Facebook Social Plugin. Storage duration: 3 months</p>\r\n\r\n<p>Vuid<br>\r\nThe domain of this cookie is owned by Vimeo. This cookie is used by Vimeo to collect tracking information. It sets a unique ID to embed videos on the website. Storage duration: 2 years</p>\r\n\r\n<p>_hjFirstSeen<br>\r\nThis cookie is set by Hotjar to identify the first session of a new user. It stores a true/false value indicating whether Hotjar has seen this user for the first time. It is used by record filters to identify new user sessions. Storage duration: 30 minutes</p>\r\n\r\n<p>_hjTLDtest<br>\r\nStorage duration: session</p>\r\n\r\n<p>_hjid<br>\r\nThis cookie is set by Hotjar. This cookie is set when the client first lands on a page with the Hotjar script. It is used to store the random user ID, unique to that page, in the browser. This ensures that behavior on subsequent visits to the same page is associated with the same user ID. Storage duration: 1 year</p>\r\n\r\n<p>_hjAbsoluteS<br>\r\nStorage duration: 30 minutes</p>\r\n\r\n\r\n\r\n<h2>Contact</h2>\r\n\r\n<p>When contacting us (for example via contact form or e-mail), personal data is collected. The data collected, in the case of a contact form, can be seen from the respective fields within the contact form. This information is stored and used solely for the purpose of answering your request or for establishing contact and the associated technical administration. The legal basis for processing the data is our legitimate interest in answering your request in accordance with Art. 6 para. 1 lit. f GDPR. If your contact is aimed at concluding a contract, then the additional legal basis for the processing is Art. 6 para. 1 lit. b GDPR. Your data will be deleted after final processing of your request, this is the case if it can be inferred from the circumstances that the matter in question is finally clarified and provided that no statutory storage requirements are in conflict.</p>\r\n\r\n\r\n\r\n<h2>Data processing when opening a customer account and for the execution of the contract</h2>\r\n\r\n<p>According to Art. 6 para. 1 lit. b GDPR, personal data will continue to be collected and processed when you provide it to us for the purpose of concluding a contract or opening a customer account. The respective input forms detail the information that is being collected. A customer account can be deleted at any time by sending a request to the afore mentioned address of the person responsible. We save and use the data you have provided for the execution of the contract. After completion of the contract or deletion of your customer account, your data will be securely stored until the end of the taxation and commercial retention periods and deleted after expiration of these periods, unless you have expressly consented to a further use of your data or we are legally permitted to further data use from our side, in which case you will be informed accordingly.</p>\r\n\r\n\r\n\r\n\r\n<h2>Use of your data for direct marketing Registration for our e-mail newsletter</h2>\r\n\r\n<p>If you subscribe to our e-mail newsletter, we will send you regular information about our offers. The mandatory information we need for sending the newsletter is your e-mail address alone. The specification of additional data (such as name, salutation and title) is voluntary and will be used to address you personally. For sending the newsletter, we use the so-called double opt-in procedure. This means that we will only send you an e-mail newsletter if you have explicitly confirmed to us that you agree to the sending of newsletters. We will then send you a confirmation e-mail asking you to confirm by clicking on a link that you wish to receive newsletters in the future.<br>\r\n<br>\r\nBy activating the confirmation link, you give us your consent to the use of your personal data in accordance with Art. 6 para. 1 lit. a GDPR. When registering for the newsletter, we will save your IP address entered by the Internet Service Provider (ISP) as well as the date and time of registration in order to be able to trace a possible misuse of your e-mail address at a later date. The data collected by us when registering for the newsletter will be used exclusively for promotional purposes by means of the newsletter. You can unsubscribe from the newsletter at any time using the link provided in the newsletter or by sending a message to the person in charge. After cancellation, your e-mail address will be deleted from our newsletter distribution immediately, unless you have expressly consented to a further use of your data or we reserve the legal right to further data usage. Further details can be found in this statement.<br>\r\n<br>\r\n<strong>Sending e-mail newsletters to existing customers</strong><br>\r\nIf you have provided us with your e-mail address when purchasing goods or services, we reserve the right to send you regular offers for similar goods or services, such as those already purchased from our range by e-mail. For this we do not have to obtain separate consent from you according to&nbsp; 107 Abs. 3 TKG. In this respect, data processing takes place solely on the basis of our legitimate interest in personalised direct mail in accordance with Art. 6 (1) lit. f GDPR. If you have initially objected to the use of your e-mail address for this purpose, we will not send you an e-mail. You are entitled to object to the use of your e-mail address for the purpose described above at any time with effect for the future by a message to the person previously named. Upon receipt of your objection, the use of your e-mail address for advertising purposes will cease immediately.<br>\r\n<br>\r\n<strong>Direct mail advertising</strong><br>\r\nBased on our legitimate interest in personalised direct mail, we reserve the right to choose your first and last name, mailing address and, as far as we have received this additional information from you as part of the contractual relationship, your title, academic degree, year of birth and professional, branch or business name according to Art. 6 para. 1 lit. f GDPR to store and use for sending interesting offers and information about our products by mail.<br>\r\n<br>\r\nYou can object to the storage and use of your data for this purpose at any time by contacting the afore mentioned person responsible. Upon receipt of your objection, the use of your address for advertising purposes will cease immediately.\r\n</p>\r\n\r\n\r\n\r\n<h2>Use of Social Media: Videos</h2>\r\n\r\n<p>This site uses Youtube Embedding feature to display and play videos from \"Youtube\", which is owned by Google LLC, 1600 Amphitheater Parkway, Mountain View, CA 94043, USA (\"Google\").<br>\r\n<br>\r\nHere, the extended privacy mode is used, which according to the provider\'s information, only stores users\' information when the video is in play mode. When playback of the embedded Youtube video begins, the provider \"Youtube\" uses cookies to collect information about user behaviour. According to \"Youtube\" hints, these are used, among other things, to capture video statistics, improve user-friendliness and prevent abusive practices. If you\'re logged in to Google, your data will be assigned directly to your account when you click a video. If you do not wish to be associated with your profile on YouTube, you must log out of your Google Account before activating the button. Google stores your data (even for non-logged-in users) as usage profiles and evaluates them. According to Art. 6 (1) (f) of the GDPR, such an evaluation is based on the legitimate interests of Google in respect to the displaying of personalised advertising, market research and / or the tailor-made design of its website. You have the right to object to the creation of these User Profiles, and you must be directed to YouTube to use them.<br>\r\n<br>\r\nRegardless of any playback of the embedded video, every time you visit this website, it will connect to the Google Network \"DoubleClick\", which may trigger further data processing without our having any influence.<br>\r\n<br>\r\nUS-based Google LLC is certified under the US Privacy Shield, which ensures compliance with the level of data protection in the EU.<br>\r\n<br>\r\nFurther information on data protection at \"YouTube\" can be found in the provider\'s privacy policy at:&nbsp;<a href=\"http://www.google.de/intl/de/policies/privacy\" target=\"_blank\">www.google.de/intl/de/policies/privacy</a><br>\r\n<br>\r\n<strong>Use of VIMEO videos</strong><br>\r\nVimeo videos are embedded on our website. Operator of the respective plugins is Vimeo LLC, located at 555 West 18th Street, New York 10011, USA. Vimeo LLC is qualified for the US Privacy Shield, which ensures compliance with data protection levels in the EU. If you visit any of our sites equipped with a Vimeo plugin, you will be connected to Vimeo\'s servers when you start playing a video. This tells the Vimeo server which of our pages you have visited. We have no influence on possible storage and evaluation of the data and cant see any data analysis. Further information on Vimeos data protection policies can be found at:&nbsp;<a href=\"https://vimeo.com/privacy\" target=\"_blank\" title=\"\">https://vimeo.com/privacy</a>\r\n</p>\r\n\r\n\r\n<h2>Online-Marketing</h2>\r\n\r\n<p><strong>Use of Google AdWords Conversion Tracking</strong><br>\r\nThis website uses the Google AdWords online advertising program. As part of Google AdWords, Google LLC conversion tracking, 1600 Amphitheater Parkway, Mountain View, CA 94043, USA (\"Google\"), we use certain offers/Google Adwords to draw attention to our attractive offers, with the help of tailored advertising (so-called Google Adwords) on external websites. In relation to the data of the advertising campaigns, we can determine how successful specific advertising campaigns are. We are keen to show you advertisements that are of interest to you, to make our website more interesting, and to achieve a fair calculation of advertising costs.<br>\r\n<br>\r\nThe conversion tracking cookie is set when a user clicks on a Google-served AdWords ad. Cookies are small text files that are stored on your computer system. These cookies usually lose their validity after 30 days and are not used for personal identification. If the user visits certain pages of this website and the cookie has not expired yet, Google and FunderMax can recognise that the user clicked on the ad and was redirected to this page. Each Google AdWords customer receives a different cookie. Cookies cannot be tracked through AdWords advertisers\' websites. The information gathered using the conversion cookie is used to generate conversion statistics for AdWords advertisers who have opted for conversion tracking. Customers are told the total number of users who clicked on their ad and were redirected to a conversion tracking tag page. However, they do not receive information that personally identifies users. If you do not want to participate in tracking, you can block this usage by disabling the Google Conversion Tracking cookie through its Internet browser under User Preferences. You will not be included in the conversion tracking statistics. We use Google Adwords based on our legitimate interest in a targeted advertising gem. Art. 6 para. 1 lit. f GDPR.<br>\r\n<br>\r\nUS-based Google LLC is certified under the US Privacy Shield, which ensures compliance with the level of data protection in the EU.<br>\r\n<br>\r\nFor more information about Google\'s privacy policy, visit the following Internet address:&nbsp;<a href=\"http://www.google.com/policies/privacy/\" target=\"_blank\">www.google.com/policies/privacy/</a>&nbsp;&nbsp;<br>\r\n<br>\r\nYou can permanently deactivate cookies by: blocking them; setting your browser software accordingly; or by downloading and installing the browser plug-in available at the following link:&nbsp;<a href=\"http://www.google.com/settings/ads/plugin\" target=\"_blank\">www.google.com/settings/ads/plugin</a><br>\r\n<br>\r\nPlease note that certain functions of this website may not be used or may only be of limited use if you have deactivated the use of cookies.\r\n</p>\r\n\r\n\r\n\r\n<h2>Web analytics services</h2>\r\n<ul>\r\n<li>Google Analytics&nbsp;</li>\r\n</ul>\r\n\r\n<p>This website uses Google Analytics, a web analytics service of Google LLC, 1600 Amphitheater Parkway, Mountain View, CA 94043, USA (\"Google\"). Google Analytics uses so-called \"cookies\", text files that are stored on your computer and allow an analysis of website use. The information generated by the cookie about your use of this website (including the shortened IP address) is usually transmitted to a Google server in the USA and stored there.<br>\r\n<br>\r\nThis website uses Google Analytics exclusively with the extension \"_anonymizeIp ()\", which ensures anonymisation of the IP address by curtailment and excludes a direct personal reference. The extension will truncate your IP address beforehand by Google within member states of the European Union or in other contracting states of the Agreement on the European Economic Area. Only in exceptional cases will the full IP address be sent to a Google server in the US and shortened there. In these exceptional cases, this processing is carried out in accordance with Art. 6 para. 1 lit. f GDPR based on our legitimate interest in the statistical analysis of user behaviour for optimisation and marketing purposes.<br>\r\n<br>\r\nGoogle will use this information on our behalf to evaluate your use of the website, to compile reports on website activity, and to provide us with other services related to website activity and internet usage. The IP address provided by Google Analytics will not be merged with other Google data.<br>\r\n<br>\r\nYou can prevent the storage of cookies by a corresponding setting of your browser software; however, please note that if you do this you may not be able to use all the features of this website to the fullest extent possible. In addition, you may prevent Google collecting this data related to your use of the website, including your IP address, and the processing of data, by downloading and installing the browser plug-in available under the following link:&nbsp;<a href=\"http://tools.google.com/dlpage/gaoptout\" target=\"_blank\">tools.google.com/dlpage/gaoptout</a><br>\r\n<br>\r\nGoogle LLC, based in the United States, is certified under the US Privacy Shield, which ensures compliance with the level of data protection in the EU. For more information on how Google Analytics handles user data, please refer to Google\'s Privacy Policy:&nbsp;<a href=\"http://support.google.com/analytics/answer/6004245\" target=\"_blank\">support.google.com/analytics/answer/6004245</a>\r\n</p>\r\n\r\n\r\n\r\n<h2>Tools and Miscellaneous</h2>\r\n\r\n<p><strong>Google Maps</strong><br>\r\nWe use Google Maps on our website (API) from Google LLC, 1600 Amphitheater Parkway, Mountain View, CA 94043, USA (\"Google\"). Google Maps is a web service for displaying interactive (land) maps to visually display geographic information. The use of this service will show you our location and facilitate your arrival.<br>\r\n<br>\r\nWhen you visit any of the subpages where Google Maps map is incorporated, information about your use of our website (such as your IP address) is transmitted to Google\'s servers in the United States and stored there. This is done regardless of whether Google provides a user account that you are logged in to, or if there is no user account. When you\'re logged-in to Google, your data will be assigned directly to your account. If you do not wish to be associated with your profile on Google, you must log out before activating the button. Google stores your data (even for non-logged-in users) as usage profiles and evaluates them. According to Art. 6 (1) (f) of the GDPR, such an evaluation is based on the legitimate interests of Google to display personalised adverts, market research and / or to tailor the design of its website. You have the right to object to this and should do so directly via Google.<br>\r\n<br>\r\nUS-based Google LLC is certified under the US Privacy Shield, which ensures compliance with the level of data protection in the EU.<br>\r\n<br>\r\nIf you disagree with the future transmission of your data to Google when using Google Maps, you can also disable the Google Maps web service completely by turning off the JavaScript application in your browser. Doing this will stop you from using Google Maps and the maps displayed on this website cannot be used.<br>\r\n<br>\r\nGoogle\'s terms of service can be viewed at&nbsp;<a href=\"http://www.google.com/intl/en/policies/terms/regional.html,\" target=\"_blank\">www.google.com/intl/en/policies/terms/regional.html</a>, and the additional Google Maps terms of service can be found at&nbsp;<a href=\"https://www.google.com/intl/en_US/help/terms_maps.html\" target=\"_blank\">https://www.google.com/intl/en_US/help/terms_maps.html</a><br>\r\n<br>\r\nFor details on privacy related to the use of Google Maps, please visit the Google Privacy Policy:&nbsp;<a href=\"http://www.google.com/intl/en/policies/privacy/\" target=\"_blank\">http://www.google.com/intl/en/policies/privacy/</a>\r\n</p>\r\n\r\n<p><strong>Lead Forensics</strong></p>\r\n\r\n<p>This website uses the Lead Forensics software tool to identify company prospects for marketing purposes. Lead Forensics provides us with insights into company-related information of our website visitors. The software works on the basis of reverse business IP tracking.<br>\r\n&nbsp;<br>\r\nLead Forensics matches the identified business IP address with a global database of companies. In doing so, Lead Forensics uses business-related information to link a business IP address to broader business data to provide us with business visitor information. Lead Forensics does not identify after any personal IP addresses, mobile devices, or other data that is not associated with a business. Lead Forensics is used in accordance with Art. 6 (1) lit. f GDPA and serves our legitimate economic interests.&nbsp;</p>\r\n\r\n<p>The collection and storage of data by Lead Forensics for this website can be objected to at any time with effect for the future under. To do so, please click on this <a href=\"https://optout.leadforensics.com/?clientID=178885\" target=\"_blank\">link.</a>&nbsp;</p>\r\n\r\n\r\n\r\n<h2>Right of Data Subjects</h2>\r\n\r\n<p>The applicable data protection law grants you comprehensive data protection rights (information and intervention rights) over the person responsible with regard to the processing of your personal data, which you can learn more about below:<br>\r\n&nbsp;</p>\r\n\r\n<ul>\r\n<li>Right of access by the data subject according to Art. 15 GDPR: In particular, you have the right to obtain information about the personal data processed by us, the processing purposes, the categories of processed personal data, the recipients or categories of recipients to whom your data was or is being disclosed, the planned Period of storage or the criteria for determining the duration of storage, the right of rectification, deletion, limitation of processing, objection to processing, complaint to a supervisory authority, the origin of your data, (if it was not collected by us), the existence of automated decision-making including profiling and possibly meaningful information on the logic involved and the scope and intended impact of such processing, as well as your right to be informed of what guarantees under Art. 46 GDPR can be given should your data be shared in third countries</li>\r\n</ul>\r\n\r\n<ul>\r\n<li>Right to recitifcation according to Art. 16 GDPR: You have the right to immediate correction of incorrect data concerning you and / or completion of your incomplete data stored by us.</li>\r\n</ul>\r\n\r\n<ul>\r\n<li>Right to erasure according to Art. 17 GDPR: You have the right to demand the deletion of your personal data if the requirements of Art. 17 (1) GDPR are met. However, that right does not apply, in particular, where the processing is necessary for the exercise of the right of freedom to expression and information, for the fulfilment of a legal obligation, for reasons of public interest or for the pursuit, exercise or defence of legal claims.</li>\r\n</ul>\r\n\r\n<ul>\r\n<li>Right to restriction of processing according to Art. 18 GDPR: You have the right to demand the restriction of the processing of your personal data for as long as it takes to ascertain the correctness of your data, if you ask not to delete your data due to inadmissible data processing and instead opt to restrict the processing of your data, if you need your data for the assertion, exercise or defence of legal claims, after we no longer need the data because the original purpose is fulfilled or if you have objected for reasons of your particular situation, as long as it is not certain, whether our valid reasons predominate.</li>\r\n</ul>\r\n\r\n<ul>\r\n<li>Notification obligation in accordance with Art. 19 GDPR: If you have exerted your right and requested from the person responsible that your data should be rectified or deleted or that its processing is to be limited, than s/he is obliged to inform all recipients to whom your personal data has been disclosed about the requested to rectify or delete or limit its processing, unless this proves to be impossible or involves a disproportionate effort. You have the right to be informed about these recipients.</li>\r\n</ul>\r\n\r\n<ul>\r\n<li>Right to data portability according to Art. 20 GDPR: You have the right to receive your personal data provided to us in a structured, common and machine-readable format or to request transmission to another person responsible, insofar as this is technically feasible.</li>\r\n</ul>\r\n\r\n<ul>\r\n<li>Right to withdraw consent according to Art. 7 para. 3 GDPR: You have the right to withdraw your consent once given in the processing of data at any time with effect for the future. Should you revoke your consent, all data concerned will be deleted immediately, as long as further processing is not supported by any legal basis for consentless processing. The revocation of consent does not affect the lawfulness of the processing carried out on the basis of the consent until the revocation.</li>\r\n</ul>\r\n\r\n<ul>\r\n<li>Right to complain under Art. 77 GDPR: If you are of the opinion that the processing of your personal data violates the GDPR, you have the right (without prejudice to any other administrative or judicial remedy) to complain to a supervisory authority, in particular within your own Member State, place of work or place of alleged infringement. In Austria, the competent supervisory authority is the Data Protection Authority.</li>\r\n</ul>\r\n\r\n<ul>\r\n<li>Right to object: If we process your personal data in the context of a balance of interests based on our predominant legitimate interest, you have the right at any time, for reasons that arise from your particular situation, to object to this processing from that point forward.</li>\r\n</ul>\r\n\r\n<p><br>\r\nIf you exercise your right of objection, we will stop the processing of the data concerned. We reserve the right to further processing, if we have compelling overriding reasons for processing that outweigh your interests, fundamental rights and fundamental freedoms or if the processing serves the assertion, exercise or defence of legal claims.<br>\r\n<br>\r\nIf your personal data is processed by ourselves for the purpose of direct mail, you have the right to object at any time to the processing of personal data concerning you for the purpose of such advertising. You can exercise the fight to object as described above.If you exercise your right of objection, we will stop the processing of the data concerned for direct marketing purposes.<br>\r\n<br>\r\nFor inquiries please contact datenschutz@fundermax.biz.\r\n</p>\r\n\r\n<p><br>\r\n<strong>Contact us:</strong><br>\r\nPlease send all your inquiries for the subject of data protection to datenschutz@fundermax.biz or contact our Legal Department, Address:<br>\r\n<strong>Fundermax GmbH<br>\r\nKlagenfurter Strae&nbsp; 87-89<br>\r\n9300 St. Veit/Glan.</strong>\r\n</p>\r\n', '', '', '', '', '', '2022-08-28 15:14:25'),
(6, 'Legal', 'legal', '', '<h3>Terms & conditions of sale &amp; delivery Fundermax GmbH</h3>\r\n<p>\r\n<a href=\"https://www.fundermax.com/AGBs/AV-Terms_and_Conditions_of_Sale_and_Delivery_FunderMax_GmbH-19165__1_.pdf\" target=\"_blank\">Terms and Conditions of Sale and Delivery Fundermax GmbH</a><br>\r\n<a href=\"https://www.fundermax.com/AGBs/Terms%20%26%20Conditions%20Fundermax%20North%20America%20Inc.pdf\" target=\"_blank\">Terms &amp; Conditions Fundermax North America Inc</a><br>\r\n<a href=\"https://www.fundermax.com/AGBs/Procurement%20conditions%20Constantia%20Industries%20AG.pdf\" target=\"_blank\">Procurement conditions Constantia Industries AG</a><br>\r\n</p>\r\n', '', '', '', '', '', '2022-08-28 22:42:35'),
(7, 'Imprint', 'imprint', '', '\r\n\r\n\r\n\r\n<p>In accessing and using the fundermax.at website you hereby unreservedly accept the terms and conditions without limitation.</p>\r\n<p>Access to the fundermax.at website is thus subject to these terms and conditions and all applicable laws. </p>\r\n\r\n<p>\r\n<strong>Media owner and responsible for content: </strong> <br>\r\nFundermax GmbH  <br>\r\nKlagenfurter Strae 87-89  <br>\r\nA-9300 St. Veit/Glan  <br>\r\nTel.: +43 (0)5/9494-0  <br>\r\nFax: +43 (0)5/9494-4200  <br>\r\nwww.fundermax.com  <br>\r\noffice@fundermax.at  <br>\r\n</p>\r\n\r\n<p>\r\nDVR 0385344 <br>\r\nFirmenbuchnummer: 90081y <br>\r\nLandesgericht Klagenfurt <br>\r\nUID-Nr.: ATU 26130102 <br>\r\nAufsichtsbehrde: Bezirkshauptmannschaft St.Veit/Glan <br>\r\nKammer: Wirtschaftskammer Krnten <br>\r\nUnternehmensgegenstand: Entwicklung, Produktion und Vertrieb von Hartfaser- und beschichteten Spanplatten, Rohspanplatten und Hochdrucklaminaten <br>\r\n</p>\r\n\r\n<p>\r\nRBI Raiffeisen Bank International AG <br>\r\nIBAN Nr: AT66 3100 0001 0033 2353 <br>\r\nBIC: RZBAATWW <br>\r\n</p>\r\n\r\n\r\n<h2><strong>Legal Information</strong></h2>\r\n<h4><strong>Copyright</strong></h4>\r\n\r\n<p>The contents including images, downloads and videos as well as the design of the FunderMax Insider website are subject to copyright protection and other laws for the protection of intellectual property irrespective of any designation. The download, print and storage of any contents of this website shall only be permitted for personal and informative use. Any additional use of the contents such as copying, distribution, reproduction and transmission that may be retrieved or used directly or indirectly from the website of FunderMax GmbH shall only be permissible with a written approval by FunderMax GmbH. Any modification of the contents of these pages including the so-called framing and similar measures shall not be permitted. This website shall not grant a licence for use the intellectual property of any enterprises of FunderMax GmbH. All trademarks used on the website of FunderMax GmbH are protected under trademark law, unless stated otherwise. This shall apply in particular for company logos and distinguishing marks.</p>\r\n\r\n<h4><strong>Warranty and Liability</strong></h4>\r\n\r\n<p>All contents of the website and the parts thereof were prepared and monitored with the greatest possible care. However, FunderMax GmbH shall not warrant or guarantee, neither explicitly or tacitly, for the accuracy and completeness of the information on this website and shall reject any liability for its use. FunderMax GmbH reserves the right to modify this website at any time without prior notice. </p>\r\n\r\n<h4><strong>Links to Third-party Websites</strong></h4>\r\n\r\n<p>This website and, if applicable, also the newsletter include links or references to the websites of third parties. These links to the websites of third parties shall not constitute any approval of their contents by FunderMax GmbH. FunderMax GmbH shall not accept any responsibility for the availability or the contents of such websites or any liability for damages or injuries that may result from whatever type of use of such contents. Links to other websites shall be provided to the users of this website merely for convenience. Any connection to these websites shall be established at the own risk of the user. </p>\r\n\r\n<h4><strong>Storage of Personal Data</strong></h4>\r\n\r\n<p>Information supplied via newsletter subscription or in other forms on the website, data shall be transmitted, which shall be stored on a server of FunderMax GmbH. As a result, any deliveries by e-mail made by FunderMax GmbH shall be accepted by the registered visitors. The approval may be revoked at any time in writing. The data shall not be passed on to any third parties. </p>\r\n\r\n<p>Plug-ins from the social network facebook.com are being used on the FunderMax Insider website; these plug-ins are operated by Facebook Inc., 1601 S. California Ave, Palo Alto, CA 94304, USA (\"Facebook\"). If webpages from FunderMax GmbH containing such a plug-in are loaded, a connection to the Facebook servers is made and the plug-in is thereby displayed on the webpage by communicating with your browser. In this manner, the FunderMax Insider webpages that you have visited are communicated to the Facebook server. If you are logged on to Facebook as a member, Facebook will associate this information with your personal Facebook user account. When using the plug-in functions (e.g., clicking the \"Like\" button), these data will also be automatically associated with your Facebook account, which you can prevent only by logging out of your Facebook account prior to using the plug-in. For further information on the collection and usage of data by Facebook and on your appurtenant rights, as well as options for protecting your privacy, please read Facebook\'s Privacy Policy.</p>\r\n\r\n<h4><strong>Data Protection Policies for Google Analytics</strong></h4>\r\n\r\n<p>Both this website and the newsletter use Google Analytics, a web analysis service by Google Inc. (\"Google\"). Google Analytics uses so-called \"cookies\", text files that are stored on your computer and which permit an analysis of your use of the website. The information created by the cookie about your use of this website (including your IP address) shall be transmitted to a server of Google in the USA and stored there. Google shall use this information to analyse your use of this website, to prepare reports on the website activities for the website operator and to provide other services associated with the use of the website and the Internet. If applicable, Google shall also transmit this information to third parties, insofar as this is stipulated by law or insofar as this data is processed by third parties on behalf of Google. Under no circumstances shall Google bring your IP address in connection with other data of Google. You can prevent the cookies from being installed by setting your browser software accordingly. However, we point out that in this case you might not be able to use all functions of this website to their full extent. With the use of this website, you agree that the data collected about you shall be processed by Google in the way and manner described above and for the aforementioned purpose.</p>\r\n', '', '', '', '', '', '2022-08-28 22:43:21'),
(8, 'Data Protection', 'data-protection', '', '<h2>Duration of storage of personal data</h2>\r\n<p>The duration of the storage of personal data is based on the respective legal retention period (eg commercial and tax retention periods). At the end of a retention period, the corresponding data is routinely deleted, if no longer required to fulfil a contract or to initiate a contract and / or no legitimate interest in continued storage persists on our part.</p>\r\n\r\n<h2>Data Protection Notice for Contract Partners</h2>\r\n\r\n<p>In the context of contractual relationships and in support of our business processes, FunderMax GmbH (hereinafter \"we\", \"us\" or \"our\") processes in its capacity as the controller within the meaning of Article 4(7) of the General Data Protection Regulation (Regulation (EU) 2016/679; hereinafter \"GDPR\") the personal data of contract partners and their employees and/or their corporate bodies (hereinafter \"you\" or \"your\"). Personal data is understood to be all content that relates to a specific or identifiable person, such as his or her name, date of birth, address and phone number (hereinafter \"data\").  For further clarification, refer to the contact details at the end of this data protection notice. </p>\r\n\r\n<p>Please bring this data protection notice to the attention of all your employees.</p>\r\n\r\n<ul>\r\n<li><strong>For what purposes do we process your data </strong><br>\r\nWe process your data for the following purposes: Performing and executing the contract concluded with your business, accounting, operating a database (CRM), marketing purposes and complying with legal provisions and industry standards. Processing the data made available in the course of the contractual relationship is necessary to implement the contractual relationship or to meet statutory obligations.<br>\r\nThe processing of your data for marketing purposes is necessary for the purpose of pursuing our legitimate interest enshrined under Article 6(1)(f) GDPR to inform you about our products. </li>\r\n<li><strong>Who receives your data?</strong><br>\r\nWhere necessary, your data is disclosed in particular to the following recipients: IT service providers, such as providers of content management services, banks, insurance companies, lawyers, courts and authorities  as well as tax consultants. If personal data is transmitted to a third country outside the EU or EEA, we will use standard EU model clauses, if necessary. </li>\r\n<li><strong>How long will your personal data be retained?</strong><br>\r\nIn principle, we retain your data until the contractual relationship is fulfilled or has ended. Furthermore, we are subject to multiple retention obligations, in accordance with the type of data that is also required to be retained beyond the term of the contract, as stipulated for instance on the basis of retention periods provided under tax law. We also retain your data, where appropriate, as long as legal claims can be made in connection with your agreement. In the case of pending administrative or judicial proceedings, your data will be retained until termination of the respective proceedings. </li>\r\n<li><strong>Your rights in connection with the processing of your data: </strong><br>\r\nYou have a right to request information from us regarding the data we have processed about you (Right of access, Article 15 GDPR). You are also entitled to request that incorrect data is corrected (Right to rectification, Article 16 GDPR) and that data processed unlawfully is deleted (Right to erasure, Article 17 GDPR). Furthermore, subject to certain conditions, you are entitled to restrict the processing (Right to restriction of processing, Article 18 GDPR) and portability of data (Right to data portability, Article 20 GDPR) and you have the  right to object (Right to object, Article 21 GDPR). To invoke and exercise these rights, see contact details below.If, in your opinion, processing the personal data relating to you breaches the provisions of the GDPR, please do not hesitate to communicate your concerns to us. In addition, in such a case you have the right to appeal to a supervisory body. </li>\r\n</ul>\r\n\r\n', '', '', '', '', '', '2022-08-28 22:45:47'),
(9, 'Interior Products', 'interior-products', '', '<div class=\"nav nav-tabs\" id=\"pageTabs\" role=\"tablist\">\r\n  <a class=\"nav-link active\" id=\"tab1\" data-bs-toggle=\"tab\" data-bs-target=\"#tab1-pane\" aria-selected=\"true\" role=\"tab\"> Max Interior </a>\r\n  <a class=\"nav-link\" id=\"tab2\" data-bs-toggle=\"tab\" data-bs-target=\"#tab2-pane\" aria-selected=\"false\" role=\"tab\" tabindex=\"-1\"> Max RE2 </a>\r\n  <a class=\"nav-link\" id=\"tab3\" data-bs-toggle=\"tab\" data-bs-target=\"#tab3-pane\" aria-selected=\"false\" role=\"tab\" tabindex=\"-1\"> Star Favorit </a>\r\n</div>\r\n<div class=\"tab-content\" id=\"pageTabsContent\">\r\n<div class=\"tab-pane fade active show\" id=\"tab1-pane\" role=\"tabpanel\" aria-labelledby=\"#tab1\">\r\n\r\n  Max Compact panels are high-pressure laminates (HPL) in accordance with EN 438-4 Type CGS for heavy-duty areas of application (e.g., wet rooms, wall cladding, office furniture, etc.). Classification according to EN 13501-1: Euroclass D-s2, d0 (CWFT). <br><br>\r\n<a class=\"btn btn-secondary btn-sm\" target=\"_blank\" href=\"../uploads/documents/interior_maxcabinacatalouge2020.pdf\">Download Brochure</a>\r\n\r\n</div>\r\n<div class=\"tab-pane fade\" id=\"tab2-pane\" role=\"tabpanel\" aria-labelledby=\"#tab2\">\r\n\r\n  Max Resistance is a duromer high pressure laminate (HPL), produced in laminate presses, under high pressure at high temperature, in accordance with EN 438-4, type CGS. Due to its scientifically developed, double-cured polyurethane acrylic coating, Max Resistance stands up to the toughest tests unaffected by solvents, most acids and the harshest chemicals. Easy-to-clean and disinfect and at the same time wear and scratch resistant, this innovative material significantly extends the life cycle of your laboratory work surface.<br><br>\r\n<a class=\"btn btn-secondary btn-sm\" target=\"_blank\" href=\"../uploads/documents/interior_max_resistance_gb_web.pdf\">Download Brochure</a>\r\n\r\n</div>  \r\n<div class=\"tab-pane fade\" id=\"tab3-pane\" role=\"tabpanel\" aria-labelledby=\"#tab3\">\r\n\r\n  Fundermax Star Favorit panels are melamine resin laminated flat-pressed panels of type MFB in compliance with EN 14322 and 14323. In their standard implementation, they are produced from E1 P2 chipboard and resin-impregnated decor films. Star Favorit panels are suitable for interior applications for all types of carcass furniture in apartment and commercial buildings.<br><br>\r\n<a class=\"btn btn-secondary btn-sm\" target=\"_blank\" href=\"../uploads/documents/interior_2019_gb_web.pdf\">Download Brochure</a>\r\n\r\n</div>  \r\n</div>', 'page_1661790661.jpg', 'page_1661790661.png', '18,19,20,21,22', '', '', '2022-08-29 21:43:14');
INSERT INTO `pages` (`pid`, `page_title`, `page_permalink`, `page_template`, `page_content`, `page_image`, `page_sideimg`, `page_media`, `page_description`, `page_keywords`, `dated`) VALUES
(10, 'Exterior Products', 'exterior-products', '', '<div class=\"nav nav-tabs\" id=\"pageTabs\" role=\"tablist\">\r\n  <a class=\"nav-link\" id=\"tab1\" data-bs-toggle=\"tab\" data-bs-target=\"#tab1-pane\" aria-selected=\"false\" role=\"tab\" tabindex=\"-1\"> Max Exterior </a>\r\n  <a class=\"nav-link active\" id=\"tab2\" data-bs-toggle=\"tab\" data-bs-target=\"#tab2-pane\" aria-selected=\"true\" role=\"tab\"> M.look </a>\r\n</div>\r\n<div class=\"tab-content\" id=\"pageTabsContent\">\r\n<div class=\"tab-pane fade\" id=\"tab1-pane\" role=\"tabpanel\" aria-labelledby=\"#tab1\">\r\n  Max Exterior from Fundermax, is a highly durable exterior wall cladding product that is constantly undergoing further development to ensure both of these aspects can be depended upon. Just as the range of rainscreen applications is becoming increasingly diverse, so the range of decors is also achieving continually new dimensions in terms of nuances and variety. <br><br>\r\n  Now you can even choose your very own individual decor for your rainscreen cladding so that you can really express your creativity. FunderMax exterior wall cladding collection remains true to its success factors and, whatever decor is used, will always stand for consistent protection and uncompromising strength. As a contemporary, cost effective rainscreen facade it is resistant in the face of all external influences. <br><br>\r\n  <a class=\"btn btn-secondary btn-sm\" target=\"_blank\" href=\"../uploads/documents/exterior_kollektion_2019.pdf\">Download Brochure</a>\r\n</div>\r\n<div class=\"tab-pane fade active show\" id=\"tab2-pane\" role=\"tabpanel\" aria-labelledby=\"#tab2\">\r\n  M.look is an architectural facade panel with heavy duty, reinforced glass fiber, predominantly mineral, non-combustible core with a highly weather resistant decorative surface. The decorative surface is characterized above all by high scratch resistance, light fastness, impact resistance, anti-graffiti properties, ease of cleaning and hail resistance. Properties tested in accordance with EN438-2. <br><br>\r\n  The greatest degree of freedom and creativity in fire-resistant material for architecturally limitless ideas. m.look Exterior stands up to even the most adverse weather and environmental influences and skillfully combines the required safety with style. m.look Exterior decorates buildings like a fine piece of clothing - inside and out. And all the while, it resists exterior influences without complaint. m.look is suitable for all applications that must adhere to the reaction to fire classification of A2-s1,d0 according to EN 13501-1, combining the desired safety with style.<br><br>\r\n  <a class=\"btn btn-secondary btn-sm\" target=\"_blank\" href=\"../uploads/documents/exterior_mlook_technik_gb_2019.pdf\">Download Brochure</a>\r\n</div>  \r\n</div>', 'page_1661845163.jpg', 'page_1661837537.png', '', '', '', '2022-08-29 22:39:28'),
(11, 'CSR', 'csr', '', '<p>Fundermax India regularly participates in CSR initiatives, independently as well as in collaboration with NGOs and other bodies. We have provided support to underprivileged students in many schools, provided free panels to facilities serving the needy and contributed to PM cares fund during the COVID-19 pandemic, among many other support to the society.<br></p>', '', '', '', '', '', '2023-04-21 10:58:22'),
(12, 'Careers', 'careers', 'careers.php', '<h2 class=\"mega-title text-center\"> Innovative. Creative. Sustainable. </h2>\r\n<h6 class=\"text-center\">â€¢ Leader in the industry - exterior segment. </h6>\r\n<h6 class=\"text-center\">â€¢ PAN India presence with a network of trained business partners. </h6>\r\n<h6 class=\"text-center\">â€¢ Great place to work 2022 certified. </h6>\r\n<h6 class=\"text-center\">â€¢ Culture of innovation, collaboration, and teamwork. </h6>', '', '', '', '', '', '2023-04-21 20:46:58');

-- --------------------------------------------------------

--
-- Table structure for table `templates`
--

CREATE TABLE `templates` (
  `pid` int(11) NOT NULL,
  `page_title` text NOT NULL,
  `page_permalink` text NOT NULL,
  `page_content` text NOT NULL,
  `page_data_one` text NOT NULL,
  `page_data_two` text NOT NULL,
  `page_data_three` text NOT NULL,
  `page_data_four` text NOT NULL,
  `page_image` varchar(400) NOT NULL,
  `page_sideimg` text NOT NULL,
  `page_media` text NOT NULL,
  `page_description` text NOT NULL,
  `page_keywords` text NOT NULL,
  `dated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `templates`
--

INSERT INTO `templates` (`pid`, `page_title`, `page_permalink`, `page_content`, `page_data_one`, `page_data_two`, `page_data_three`, `page_data_four`, `page_image`, `page_sideimg`, `page_media`, `page_description`, `page_keywords`, `dated`) VALUES
(1, 'Fundermax India - Home', '', '<h1><strong>About us</strong></h1>\r\n\r\nFundermax, an Austrian MNC with a legacy of more than 130+ years, has Design at its core and caters to varied segments like Exterior Facades, Architectural Interiors, Furniture, Packaging, Automotive, Healthcare &amp; many other Allied Industries. \r\n<br><br>\r\nWe offer Unique solutions where Aesthetics meets Functionality and strive towards Perfection with the constant pursuit of delivering World Class Products &amp; Services aimed toward Customer Centricity through Brand Leadership and Digital Transformation leading to Business Excellence for a Sustainable Future with People First &amp; ESG at the helm. \r\n<br><br>\r\nAt Fundermax, we are open to Ideas, Innovation &amp; Collaboration, for you to create a world of limitless possibilities.', 'Fundermax India; the leader in architectural products for interior and exterior applications. With over 32000 SKUs offering high design freedom. Fundermax panels provide a high degree of design freedom for you to create. They improve the life and sustainability of a building by adhering to green building standards.\r\n<br><br>\r\nWe are a complete solution provider, supplying not only Max Exterior and Interior panels but also Fundermax developed installation system. A network of trained & experienced Fundermax-authorized business partners, across the country, supports the installation of a complete system at the site.\r\n', '<h5>Exterior segment</h5>\r\n<ul>\r\n  <li>Installation system (made for India), and designed to withstand extreme weather conditions of India. </li>\r\n  <li>The entire system is designed on the principles of the \"Rear Ventilated Facade System\" and is long-lasting, easy to maintain, and easy to clean.</li>\r\n  <li>Fundermax panels can also be customized via CNC cutting into any motifs that the architect wants, without losing the sustainability of the system.</li>\r\n  <li>Max Lato sun shading system designed, heeding to the market demand.</li>\r\n  <li>Rivetless soffit system called FS01 to provide seamless finish.</li>\r\n</ul>\r\n', '<h5>Interior segment</h5>\r\n<ul>\r\n  <li>Max Interior panels suitable for durable partition system for restrooms, cubicles & internal wall claddings.</li>\r\n  <li>MFC (Melamine-faced chipboards) & MDF for interior furniture and kitchens.</li>\r\n  <li>Max Resistance2 is a niche offering that is specifically used for laboratory tabletops.</li>\r\n</ul>\r\n', 'Fundermax India regularly participates in CSR initiatives, independently as well as in collaboration with NGOs and other bodies. We have provided support to underprivileged students in many schools, provided free panels to facilities serving the needy and contributed to PM cares fund during the COVID-19 pandemic, among many other support to the society.', '', 'page_1662113186.jpg', '', '', '', '2022-08-29 19:11:50');

-- --------------------------------------------------------

--
-- Table structure for table `userdata`
--

CREATE TABLE `userdata` (
  `uidx` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `phone2` varchar(200) NOT NULL,
  `fullname` varchar(200) NOT NULL,
  `address` text NOT NULL,
  `pincode` varchar(200) NOT NULL,
  `dob` varchar(200) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `education` text NOT NULL,
  `experience` text NOT NULL,
  `skills` text NOT NULL,
  `website` text NOT NULL,
  `file_resume` text NOT NULL,
  `file_profile_pic` text NOT NULL,
  `dated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `details` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userdata`
--

INSERT INTO `userdata` (`uidx`, `username`, `email`, `phone`, `phone2`, `fullname`, `address`, `pincode`, `dob`, `gender`, `education`, `experience`, `skills`, `website`, `file_resume`, `file_profile_pic`, `dated`, `updated`, `details`) VALUES
(1, 'emplo', 'emplo@mailx.com', '+1 (454) 255-2528', '+1 (799) 849-3718', 'Empo Leon', 'Iure nostrud optio', 'Ipsam nihil eos ra', 'Provident est ips', 'M', '', '', '', 'https://www.linkedin.com/example', '', 'emplo_pic.jpg', '2019-09-28 12:26:01', '2022-08-25 22:05:11', 'notes or information'),
(2, 'kapil', 'intiger.com@mail.net', '+1 (996) 734-5612', '+1 (728) 857-5947', 'Ryan Orr', 'Sit mollitia asperna', 'Molestiae officia ap', '2006-04-16', 'M', '', '', '', '', '', '', '2019-09-02 11:15:40', '2022-08-25 22:05:14', ''),
(3, 'ajay', 'ajay@mail.com', '+1 (731) 467-5442', '+1 (793) 214-6076', 'Hadassah Ross', 'Sunt aut quisquam', 'Modi voluptatem I', 'Dolor nostrud nobi', 'M', 'bca', '2years', 'xbox', '', 'ajay_resume.pdf', 'ajay_pic.png', '2019-09-09 12:19:54', '2022-08-25 22:05:39', ''),
(4, 'widow', 'widow@dark.com', '24352345345', 'na', 'Black Widower', 'Maiores cupidatat ', 'Non ea voluptatem', 'Voluptatem Ipsam ', 'F', 'mca', '1year', 'ps', 'instagram', 'widow_resume.jpg', 'widow_pic.jpg', '2019-09-23 15:28:59', '2022-08-25 23:41:23', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

CREATE TABLE `userlog` (
  `uid` int(11) NOT NULL,
  `user_name` varchar(200) NOT NULL,
  `user_role` varchar(200) NOT NULL,
  `action_term` varchar(200) NOT NULL,
  `action_on` varchar(200) NOT NULL,
  `action_details` text NOT NULL,
  `dated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userlog`
--

INSERT INTO `userlog` (`uid`, `user_name`, `user_role`, `action_term`, `action_on`, `action_details`, `dated`) VALUES
(72, 'admin', 'admin', 'login', '', 'user logged in using login panel', '2022-08-25 13:21:17'),
(73, 'admin', 'admin', 'login', '', 'user logged in using login panel', '2022-08-25 21:55:18'),
(74, 'admin', 'admin', 'login', '', 'user logged in using login panel', '2022-08-28 15:09:11'),
(75, 'admin', 'admin', 'login', '', 'user logged in using login panel', '2022-09-02 22:54:48'),
(76, 'admin', 'admin', 'login', '', 'user logged in using login panel', '2022-09-02 22:55:58'),
(77, 'admin', 'admin', 'login', '', 'user logged in using login panel', '2022-09-02 22:59:20'),
(78, 'admin', 'admin', 'login', '', 'user logged in using login panel', '2022-09-02 22:59:26'),
(79, 'admin', 'admin', 'login', '', 'user logged in using login panel', '2022-09-02 23:09:03'),
(80, 'admin', 'admin', 'login', '', 'user logged in using login panel', '2022-09-02 23:18:54'),
(81, 'admin', 'admin', 'login', '', 'user logged in using login panel', '2022-09-02 23:19:24'),
(82, 'admin', 'admin', 'login', '', 'user logged in using login panel', '2022-09-03 22:06:08'),
(83, 'admin', 'admin', 'admin_edit', '', 'Edited admin info with id: 5', '2022-09-03 22:16:29'),
(84, 'master', 'admin', 'login', '', 'user logged in using login panel', '2022-09-03 22:16:48'),
(85, 'master', 'admin', 'login', '', 'user logged in using login panel', '2022-09-14 16:00:07'),
(86, 'admin', 'admin', 'login', '', 'user logged in using login panel', '2022-09-29 13:30:00'),
(87, 'admin', 'admin', 'login', '', 'user logged in using login panel', '2022-09-29 14:39:06'),
(88, 'admin', 'admin', 'login', '', 'user logged in using login panel', '2022-09-29 17:55:03'),
(89, 'master', 'admin', 'login', '', 'user logged in using login panel', '2022-10-03 14:54:26'),
(90, 'admin', 'admin', 'login', '', 'user logged in using login panel', '2022-10-05 13:42:40'),
(91, 'admin', 'admin', 'login', '', 'user logged in using login panel', '2022-10-13 11:22:30'),
(92, 'admin', 'admin', 'login', '', 'user logged in using login panel', '2022-10-13 13:18:07'),
(93, 'admin', 'admin', 'login', '', 'user logged in using login panel', '2022-10-13 14:08:29'),
(94, 'master', 'admin', 'login', '', 'user logged in using login panel', '2022-10-13 15:53:03'),
(95, 'master', 'admin', 'login', '', 'user logged in using login panel', '2022-10-17 15:38:29'),
(96, 'master', 'admin', 'login', '', 'user logged in using login panel', '2022-10-18 15:03:51'),
(97, 'admin', 'admin', 'login', '', 'user logged in using login panel', '2022-11-25 11:29:02'),
(98, 'admin', 'admin', 'login', '', 'user logged in using login panel', '2022-11-30 11:52:34'),
(99, 'master', 'admin', 'login', '', 'user logged in using login panel', '2023-03-17 11:28:30'),
(100, 'master', 'admin', 'login', '', 'user logged in using login panel', '2023-03-17 11:31:13'),
(101, 'master', 'admin', 'login', '', 'user logged in using login panel', '2023-03-17 11:46:02'),
(102, 'master', 'admin', 'login', '', 'user logged in using login panel', '2023-03-17 11:57:25'),
(103, 'admin', 'admin', 'login', '', 'user logged in using login panel', '2023-03-24 11:28:31'),
(104, 'admin', 'admin', 'login', '', 'user logged in using login panel', '2023-04-18 14:51:26'),
(105, 'admin', 'admin', 'login', '', 'user logged in using login panel', '2023-04-18 17:51:51'),
(106, 'admin', 'admin', 'login', '', 'user logged in using login panel', '2023-04-19 13:13:52'),
(107, 'admin', 'admin', 'login', '', 'user logged in using login panel', '2023-04-21 10:48:54'),
(108, 'admin', 'admin', 'login', '', 'user logged in using login panel', '2023-04-21 15:08:48'),
(109, 'admin', 'admin', 'login', '', 'user logged in using login panel', '2023-04-21 15:16:22'),
(110, 'admin', 'admin', 'login', '', 'user logged in using login panel', '2023-04-21 20:46:38');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `uid` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `fullname` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  `dated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `username`, `password`, `role`, `email`, `phone`, `fullname`, `status`, `dated`) VALUES
(1, 'emplo', 'e10adc3949ba59abbe56e057f20f883e', 'editor', 'emplo@mailx.com', '', 'Empo Leon', 'pending', '2022-08-20 12:26:01'),
(2, 'kapil', 'e10adc3949ba59abbe56e057f20f883e', 'user', 'kapil@mail.in', '', 'Kapil Dev', 'active', '2022-08-20 00:00:00'),
(3, 'ajay', 'e10adc3949ba59abbe56e057f20f883e', 'editor', 'ajay@mail.com', '', 'Ajay Sen', 'active', '2022-08-20 21:57:32'),
(4, 'widow', 'fcea920f7412b5da7be0cf42b8c93759', 'user', 'widow@dark.com', '', 'Black Widower', 'active', '2022-08-20 15:28:59');

-- --------------------------------------------------------

--
-- Table structure for table `users_resetpass`
--

CREATE TABLE `users_resetpass` (
  `rid` int(11) NOT NULL,
  `email` varchar(300) NOT NULL,
  `token` varchar(300) NOT NULL,
  `expDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`bid`);

--
-- Indexes for table `documents`
--
ALTER TABLE `documents`
  ADD PRIMARY KEY (`did`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`gid`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `templates`
--
ALTER TABLE `templates`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `userdata`
--
ALTER TABLE `userdata`
  ADD PRIMARY KEY (`uidx`);

--
-- Indexes for table `userlog`
--
ALTER TABLE `userlog`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `user_email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `users_resetpass`
--
ALTER TABLE `users_resetpass`
  ADD PRIMARY KEY (`rid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `bid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `documents`
--
ALTER TABLE `documents`
  MODIFY `did` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `gid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `templates`
--
ALTER TABLE `templates`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `userdata`
--
ALTER TABLE `userdata`
  MODIFY `uidx` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `userlog`
--
ALTER TABLE `userlog`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users_resetpass`
--
ALTER TABLE `users_resetpass`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
