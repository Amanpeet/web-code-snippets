<!-- include header -->
<?php include('inc/header.php'); ?>

<?php
// error_reporting(0);
/* IF DELETE MEMBER */
if(isset($_REQUEST['del'])) {
  $form_id = $_REQUEST['del'];
  ?>
    <div class="p-2 border-bottom">
      <h3> <strong>Delete Item</strong> </h3>
      <p>Confirm deletion of Specific Item.</p>
    </div>
    <div class="form-box p-2">
      <form id="id_card_form" name="id_card_form" action="" method="post">
        <?php
          $select = "SELECT * FROM formdata_main WHERE form_id = '$form_id'";
          $que = mysqli_query($conn, $select);
          $fet = mysqli_fetch_array($que);
        ?>
        <h5>Do you really want to delete application <strong><?php echo $fet['form_id']; ?> (Email: <?php echo $fet['user_email']; ?>) </strong>from database? </h5>
        <h6 class="text-danger"> Note: This action cannot be undone. </h6>
        <div class="text-left my-4">
          <input type="submit" class="btn btn-danger" name="deletemon" value="Delete">
          <a class="btn btn-dark" href="applications.php">Cancel</a>
        </div>
      </form>
    </div>

    <div id="response" class="h4">
      <?php
      if(isset($_POST['deletemon'])){
        $delete = "DELETE FROM formdata_main WHERE form_id = '$form_id' ";
        $quer = mysqli_query($conn, $delete);
        if($quer){
          echo "<strong>SUCCESS: Application Deleted. Redirecting back...";
          echo '<script>window.location="applications.php";</script>';
        } else{
          echo "<strong>ERROR: Application not deleted. Please try again later.</strong>";
        }
      }
      ?>
    </div>
    <?php

/* IF UPDATE MEMBER */
} else if(isset($_REQUEST['edit'])) {
  $form_id = $_REQUEST['edit'];
  ?>
  <div class="p-2 border-bottom">
    <h3> <strong>Edit Application</strong> </h3>
    <p>Edit Fields and Hit <strong>UPDATE</strong> on bottom. Some fields can't be changed. <br> <strong>Please Note Once values are updated, they cannot be reversed or undo.</strong> </p>
  </div>

  <!-- Operation updatemon -->
  <div id="response" class="h5">
    <?php
    if(isset($_POST['updatemon'])) {

      //Form 1 Vars
      $form_type       = mysqli_real_escape_string($conn, $_POST['form_type']);
      $f1_pass_type    = mysqli_real_escape_string($conn, $_POST['f1_pass_type']);
      $f1_nationality  = mysqli_real_escape_string($conn, $_POST['f1_nationality']);
      $f1_port_arrival = mysqli_real_escape_string($conn, $_POST['f1_port_arrival']);
      $f1_dob          = mysqli_real_escape_string($conn, $_POST['f1_dob']);
      $f1_email        = mysqli_real_escape_string($conn, $_POST['f1_email']);
      $f1_date_arrival = mysqli_real_escape_string($conn, $_POST['f1_date_arrival']);
      $e_visa_type     = mysqli_real_escape_string($conn, $_POST['e_visa_type']);
      $e_visa_subtype  = mysqli_real_escape_string($conn, $_POST['e_visa_subtype']);

      //Form 2 Vars
      $f2_surname                = mysqli_real_escape_string($conn, $_POST['f2_surname']);
      $f2_given_name             = mysqli_real_escape_string($conn, $_POST['f2_given_name']);
      $f2_name_changed           = mysqli_real_escape_string($conn, $_POST['f2_name_changed']);
      $f2_previous_surname       = mysqli_real_escape_string($conn, $_POST['f2_previous_surname']);
      $f2_previous_name          = mysqli_real_escape_string($conn, $_POST['f2_previous_name']);
      $f2_gender                 = mysqli_real_escape_string($conn, $_POST['f2_gender']);
      $f2_dob                    = mysqli_real_escape_string($conn, $_POST['f2_dob']);
      $f2_birth_city             = mysqli_real_escape_string($conn, $_POST['f2_birth_city']);
      $f2_birth_country          = mysqli_real_escape_string($conn, $_POST['f2_birth_country']);
      $f2_national_id            = mysqli_real_escape_string($conn, $_POST['f2_national_id']);
      $f2_religion               = mysqli_real_escape_string($conn, $_POST['f2_religion']);
      $f2_religion_others        = mysqli_real_escape_string($conn, $_POST['f2_religion_others']);
      $f2_visible_marks          = mysqli_real_escape_string($conn, $_POST['f2_visible_marks']);
      $f2_edu_qualification      = mysqli_real_escape_string($conn, $_POST['f2_edu_qualification']);
      $f2_nationality            = mysqli_real_escape_string($conn, $_POST['f2_nationality']);
      $f2_acquire_nationality    = mysqli_real_escape_string($conn, $_POST['f2_acquire_nationality']);
      $f2_previous_nationality   = mysqli_real_escape_string($conn, $_POST['f2_previous_nationality']);
      $f2_lived_years            = mysqli_real_escape_string($conn, $_POST['f2_lived_years']);
      $f2_passport_num           = mysqli_real_escape_string($conn, $_POST['f2_passport_num']);
      $f2_issue_place            = mysqli_real_escape_string($conn, $_POST['f2_issue_place']);
      $f2_issue_date             = mysqli_real_escape_string($conn, $_POST['f2_issue_date']);
      $f2_expiry_date            = mysqli_real_escape_string($conn, $_POST['f2_expiry_date']);
      $f2_other_passport         = mysqli_real_escape_string($conn, $_POST['f2_other_passport']);
      $f2_other_issue_country    = mysqli_real_escape_string($conn, $_POST['f2_other_issue_country']);
      $f2_other_passport_num     = mysqli_real_escape_string($conn, $_POST['f2_other_passport_num']);
      $f2_other_issue_date       = mysqli_real_escape_string($conn, $_POST['f2_other_issue_date']);
      $f2_other_issue_place      = mysqli_real_escape_string($conn, $_POST['f2_other_issue_place']);
      $f2_other_pass_nationality = mysqli_real_escape_string($conn, $_POST['f2_other_pass_nationality']);

      //Form 3 Vars
      $f3_house_num             = mysqli_real_escape_string($conn, $_POST['f3_house_num']);
      $f3_village_town          = mysqli_real_escape_string($conn, $_POST['f3_village_town']);
      $f3_state_province        = mysqli_real_escape_string($conn, $_POST['f3_state_province']);
      $f3_country               = mysqli_real_escape_string($conn, $_POST['f3_country']);
      $f3_zip_code              = mysqli_real_escape_string($conn, $_POST['f3_zip_code']);
      $f3_phone_num             = mysqli_real_escape_string($conn, $_POST['f3_phone_num']);
      $f3_mobile_num            = mysqli_real_escape_string($conn, $_POST['f3_mobile_num']);
      $f3_email                 = mysqli_real_escape_string($conn, $_POST['f3_email']);
      $f3_same_address          = mysqli_real_escape_string($conn, $_POST['f3_same_address']);
      $f3_perma_house_num       = mysqli_real_escape_string($conn, $_POST['f3_perma_house_num']);
      $f3_perma_village_town    = mysqli_real_escape_string($conn, $_POST['f3_perma_village_town']);
      $f3_perma_state_province  = mysqli_real_escape_string($conn, $_POST['f3_perma_state_province']);
      $f3_fathers_name          = mysqli_real_escape_string($conn, $_POST['f3_fathers_name']);
      $f3_fathers_nationality   = mysqli_real_escape_string($conn, $_POST['f3_fathers_nationality']);
      $f3_fathers_birth_place   = mysqli_real_escape_string($conn, $_POST['f3_fathers_birth_place']);
      $f3_fathers_birth_country = mysqli_real_escape_string($conn, $_POST['f3_fathers_birth_country']);
      $f3_mothers_name          = mysqli_real_escape_string($conn, $_POST['f3_mothers_name']);
      $f3_mothers_nationality   = mysqli_real_escape_string($conn, $_POST['f3_mothers_nationality']);
      $f3_mothers_birth_place   = mysqli_real_escape_string($conn, $_POST['f3_mothers_birth_place']);
      $f3_mothers_birth_country = mysqli_real_escape_string($conn, $_POST['f3_mothers_birth_country']);
      $f3_martial_status        = mysqli_real_escape_string($conn, $_POST['f3_martial_status']);
      $f3_present_occupation    = mysqli_real_escape_string($conn, $_POST['f3_present_occupation']);
      $f3_employer_business     = mysqli_real_escape_string($conn, $_POST['f3_employer_business']);
      $f3_work_address          = mysqli_real_escape_string($conn, $_POST['f3_work_address']);

      $f3_fathers_prev_nationality = mysqli_real_escape_string($conn, $_POST['f3_fathers_prev_nationality']);
      $f3_mothers_prev_nationality = mysqli_real_escape_string($conn, $_POST['f3_mothers_prev_nationality']);
      $f3_spouse_name              = mysqli_real_escape_string($conn, $_POST['f3_spouse_name']);
      $f3_spouse_nationality       = mysqli_real_escape_string($conn, $_POST['f3_spouse_nationality']);
      $f3_spouse_prev_nationality  = mysqli_real_escape_string($conn, $_POST['f3_spouse_prev_nationality']);
      $f3_spouse_birth_place       = mysqli_real_escape_string($conn, $_POST['f3_spouse_birth_place']);
      $f3_spouse_birth_country     = mysqli_real_escape_string($conn, $_POST['f3_spouse_birth_country']);
      $f3_grand_in_pak             = mysqli_real_escape_string($conn, $_POST['f3_grand_in_pak']);
      $f3_grand_in_pak_more        = mysqli_real_escape_string($conn, $_POST['f3_grand_in_pak_more']);
      $f3_occupation_more          = mysqli_real_escape_string($conn, $_POST['f3_occupation_more']);
      $f3_designation              = mysqli_real_escape_string($conn, $_POST['f3_designation']);
      $f3_work_phone               = mysqli_real_escape_string($conn, $_POST['f3_work_phone']);
      $f3_past_occupation          = mysqli_real_escape_string($conn, $_POST['f3_past_occupation']);
      $f3_past_occupation_more     = mysqli_real_escape_string($conn, $_POST['f3_past_occupation_more']);
      $f3_military_past            = mysqli_real_escape_string($conn, $_POST['f3_military_past']);
      $f3_military_past_details    = mysqli_real_escape_string($conn, $_POST['f3_military_past_details']);
      $f3_military_organisation    = mysqli_real_escape_string($conn, $_POST['f3_military_organisation']);
      $f3_military_designation     = mysqli_real_escape_string($conn, $_POST['f3_military_designation']);
      $f3_military_rank            = mysqli_real_escape_string($conn, $_POST['f3_military_rank']);
      $f3_military_posting         = mysqli_real_escape_string($conn, $_POST['f3_military_posting']);

      //Form 4 Vars
      $f4_visa_type               = mysqli_real_escape_string($conn, $_POST['f4_visa_type']);
      $f4_visa_subtype            = mysqli_real_escape_string($conn, $_POST['f4_visa_subtype']);
      $f4_places_visit            = mysqli_real_escape_string($conn, $_POST['f4_places_visit']);
      $f4_places_visit_more       = mysqli_real_escape_string($conn, $_POST['f4_places_visit_more']);
      $f4_tour_operator           = mysqli_real_escape_string($conn, $_POST['f4_tour_operator']);
      $f4_operator_name           = mysqli_real_escape_string($conn, $_POST['f4_operator_name']);
      $f4_operator_address        = mysqli_real_escape_string($conn, $_POST['f4_operator_address']);
      $f4_operator_hotel          = mysqli_real_escape_string($conn, $_POST['f4_operator_hotel']);
      $f4_operator_place          = mysqli_real_escape_string($conn, $_POST['f4_operator_place']);
      $f4_expected_duration       = mysqli_real_escape_string($conn, $_POST['f4_expected_duration']);
      $f4_expected_entries        = mysqli_real_escape_string($conn, $_POST['f4_expected_entries']);
      $f4_port_arrival            = mysqli_real_escape_string($conn, $_POST['f4_port_arrival']);
      $f4_port_exit               = mysqli_real_escape_string($conn, $_POST['f4_port_exit']);
      $f4_visited_india           = mysqli_real_escape_string($conn, $_POST['f4_visited_india']);
      $f4_visited_address         = mysqli_real_escape_string($conn, $_POST['f4_visited_address']);
      $f4_visited_cities          = mysqli_real_escape_string($conn, $_POST['f4_visited_cities']);
      $f4_visited_visa_num        = mysqli_real_escape_string($conn, $_POST['f4_visited_visa_num']);
      $f4_visited_visa_type       = mysqli_real_escape_string($conn, $_POST['f4_visited_visa_type']);
      $f4_visited_visa_place      = mysqli_real_escape_string($conn, $_POST['f4_visited_visa_place']);
      $f4_visited_visa_issue      = mysqli_real_escape_string($conn, $_POST['f4_visited_visa_issue']);
      $f4_permission_refused      = mysqli_real_escape_string($conn, $_POST['f4_permission_refused']);
      $f4_permission_refused_more = mysqli_real_escape_string($conn, $_POST['f4_permission_refused_more']);
      $f4_saarc_last              = mysqli_real_escape_string($conn, $_POST['f4_saarc_last']);
      $f4_saarc_visited           = mysqli_real_escape_string($conn, $_POST['f4_saarc_visited']);
      $f4_india_ref_name          = mysqli_real_escape_string($conn, $_POST['f4_india_ref_name']);
      $f4_india_ref_address       = mysqli_real_escape_string($conn, $_POST['f4_india_ref_address']);
      $f4_india_ref_phone         = mysqli_real_escape_string($conn, $_POST['f4_india_ref_phone']);
      $f4_home_ref_name           = mysqli_real_escape_string($conn, $_POST['f4_home_ref_name']);
      $f4_home_ref_address        = mysqli_real_escape_string($conn, $_POST['f4_home_ref_address']);
      $f4_home_ref_phone          = mysqli_real_escape_string($conn, $_POST['f4_home_ref_phone']);
      $f4_crime_1                 = mysqli_real_escape_string($conn, $_POST['f4_crime_1']);
      $f4_crime_2                 = mysqli_real_escape_string($conn, $_POST['f4_crime_2']);
      $f4_crime_3                 = mysqli_real_escape_string($conn, $_POST['f4_crime_3']);
      $f4_crime_4                 = mysqli_real_escape_string($conn, $_POST['f4_crime_4']);
      $f4_crime_5                 = mysqli_real_escape_string($conn, $_POST['f4_crime_5']);
      $f4_crime_6                 = mysqli_real_escape_string($conn, $_POST['f4_crime_6']);
      $f4_crime_details           = mysqli_real_escape_string($conn, $_POST['f4_crime_details']);

      // saarc fields
      $f4_saarc_countries = mysqli_real_escape_string($conn, $_POST['f4_saarc_countries']);
      $f4_saarc_years = mysqli_real_escape_string($conn, $_POST['f4_saarc_years']);
      $f4_saarc_visits = mysqli_real_escape_string($conn, $_POST['f4_saarc_visits']);

      // business only fields
      $f4_company_name        = mysqli_real_escape_string($conn, $_POST['f4_company_name']);
      $f4_company_address     = mysqli_real_escape_string($conn, $_POST['f4_company_address']);
      $f4_company_website     = mysqli_real_escape_string($conn, $_POST['f4_company_website']);
      $f4_ind_company_name    = mysqli_real_escape_string($conn, $_POST['f4_ind_company_name']);
      $f4_ind_company_address = mysqli_real_escape_string($conn, $_POST['f4_ind_company_address']);
      $f4_ind_company_website = mysqli_real_escape_string($conn, $_POST['f4_ind_company_website']);
      $f4_company_business    = mysqli_real_escape_string($conn, $_POST['f4_company_business']);
      $f4_business_details = $f4_company_name.';'.$f4_company_address.';'.$f4_company_website.';'.$f4_ind_company_name.';' .$f4_ind_company_address.';'.$f4_ind_company_website.';'.$f4_company_business;

      // medical only fields
      $f4_hospital_name      = mysqli_real_escape_string($conn, $_POST['f4_hospital_name']);
      $f4_hospital_address   = mysqli_real_escape_string($conn, $_POST['f4_hospital_address']);
      $f4_hospital_state     = mysqli_real_escape_string($conn, $_POST['f4_hospital_state']);
      $f4_hospital_district  = mysqli_real_escape_string($conn, $_POST['f4_hospital_district']);
      $f4_hospital_phone     = mysqli_real_escape_string($conn, $_POST['f4_hospital_phone']);
      $f4_hospital_treatment = mysqli_real_escape_string($conn, $_POST['f4_hospital_treatment']);
      $f4_medical_details = $f4_hospital_name.';' .$f4_hospital_address.';' .$f4_hospital_state.';' .$f4_hospital_district.';' .$f4_hospital_phone.';' .$f4_hospital_treatment;

      // conference only fields
      $f4_conf_name        = mysqli_real_escape_string($conn, $_POST['f4_conf_name']);
      $f4_conf_duration    = mysqli_real_escape_string($conn, $_POST['f4_conf_duration']);
      $f4_conf_address     = mysqli_real_escape_string($conn, $_POST['f4_conf_address']);
      $f4_conf_state       = mysqli_real_escape_string($conn, $_POST['f4_conf_state']);
      $f4_conf_district    = mysqli_real_escape_string($conn, $_POST['f4_conf_district']);
      $f4_conf_pincode     = mysqli_real_escape_string($conn, $_POST['f4_conf_pincode']);
      $f4_conf_org_name    = mysqli_real_escape_string($conn, $_POST['f4_conf_org_name']);
      $f4_conf_org_address = mysqli_real_escape_string($conn, $_POST['f4_conf_org_address']);
      $f4_conf_org_email   = mysqli_real_escape_string($conn, $_POST['f4_conf_org_email']);
      $f4_conference_details = $f4_conf_name.';' .$f4_conf_duration.';' .$f4_conf_address.';' .$f4_conf_state.';' .$f4_conf_district.';' .$f4_conf_pincode.';' .$f4_conf_org_name.';' .$f4_conf_org_address.';' .$f4_conf_org_email;

      //Form 5 Vars

      //Form main Vars
      $fmain_payment_status = mysqli_real_escape_string($conn, $_POST['fmain_payment_status']);
      $fmain_final_status   = mysqli_real_escape_string($conn, $_POST['fmain_final_status']);
      $fmain_comments       = mysqli_real_escape_string($conn, $_POST['fmain_comments']);

      // set queries to update
      $query_sql1 = "UPDATE formdata_form1 SET f1_nationality = '$f1_nationality', f1_nationality = '$f1_nationality', f1_port_arrival = '$f1_port_arrival', f1_dob = '$f1_dob', f1_email = '$f1_email', f1_date_arrival = '$f1_date_arrival', e_visa_type = '$e_visa_type', e_visa_subtype = '$e_visa_subtype' WHERE form_id = '$form_id' ";

      $query_sql2 = "UPDATE formdata_form2 SET form_type = '$form_type', f2_surname = '$f2_surname', f2_given_name = '$f2_given_name', f2_name_changed = '$f2_name_changed', f2_previous_surname = '$f2_previous_surname', f2_previous_name = '$f2_previous_name', f2_gender = '$f2_gender', f2_dob = '$f2_dob', f2_birth_city = '$f2_birth_city', f2_birth_country = '$f2_birth_country', f2_national_id = '$f2_national_id', f2_religion = '$f2_religion', f2_religion_others = '$f2_religion_others', f2_visible_marks = '$f2_visible_marks', f2_edu_qualification = '$f2_edu_qualification', f2_nationality = '$f2_nationality', f2_acquire_nationality = '$f2_acquire_nationality', f2_previous_nationality = '$f2_previous_nationality', f2_lived_years = '$f2_lived_years', f2_passport_num = '$f2_passport_num', f2_issue_place = '$f2_issue_place', f2_issue_date = '$f2_issue_date', f2_expiry_date = '$f2_expiry_date', f2_other_passport = '$f2_other_passport', f2_other_issue_country = '$f2_other_issue_country', f2_other_passport_num = '$f2_other_passport_num', f2_other_issue_date = '$f2_other_issue_date', f2_other_issue_place = '$f2_other_issue_place', f2_other_pass_nationality = '$f2_other_pass_nationality' WHERE form_id = '$form_id' ";

      $query_sql3 = "UPDATE formdata_form3 SET form_type = '$form_type', f3_house_num = '$f3_house_num', f3_village_town = '$f3_village_town', f3_state_province = '$f3_state_province', f3_country = '$f3_country', f3_zip_code = '$f3_zip_code', f3_phone_num = '$f3_phone_num', f3_mobile_num = '$f3_mobile_num', f3_email = '$f3_email', f3_same_address = '$f3_same_address', f3_perma_house_num = '$f3_perma_house_num', f3_perma_village_town = '$f3_perma_village_town', f3_perma_state_province = '$f3_perma_state_province', f3_fathers_name = '$f3_fathers_name', f3_fathers_nationality = '$f3_fathers_nationality', f3_fathers_birth_place = '$f3_fathers_birth_place', f3_fathers_birth_country = '$f3_fathers_birth_country', f3_mothers_name = '$f3_mothers_name', f3_mothers_nationality = '$f3_mothers_nationality', f3_mothers_birth_place = '$f3_mothers_birth_place', f3_mothers_birth_country = '$f3_mothers_birth_country', f3_martial_status = '$f3_martial_status', f3_present_occupation = '$f3_present_occupation', f3_employer_business = '$f3_employer_business', f3_work_address = '$f3_work_address', f3_fathers_prev_nationality = '$f3_fathers_prev_nationality', f3_mothers_prev_nationality = '$f3_mothers_prev_nationality', f3_spouse_name = '$f3_spouse_name', f3_spouse_nationality = '$f3_spouse_nationality', f3_spouse_prev_nationality = '$f3_spouse_prev_nationality', f3_spouse_birth_place = '$f3_spouse_birth_place', f3_spouse_birth_country = '$f3_spouse_birth_country', f3_grand_in_pak = '$f3_grand_in_pak', f3_grand_in_pak_more = '$f3_grand_in_pak_more', f3_occupation_more = '$f3_occupation_more', f3_designation = '$f3_designation', f3_work_phone = '$f3_work_phone', f3_past_occupation = '$f3_past_occupation', f3_past_occupation_more = '$f3_past_occupation_more', f3_military_past = '$f3_military_past', f3_military_past_details = '$f3_military_past_details', f3_military_organisation = '$f3_military_organisation', f3_military_designation = '$f3_military_designation', f3_military_rank = '$f3_military_rank', f3_military_posting = '$f3_military_posting' WHERE form_id = '$form_id' ";

      $query_sql4 = "UPDATE formdata_form4 SET form_type = '$form_type', f4_visa_type = '$f4_visa_type', f4_visa_subtype = '$f4_visa_subtype', f4_places_visit = '$f4_places_visit', f4_places_visit_more = '$f4_places_visit_more', f4_tour_operator = '$f4_tour_operator', f4_operator_name = '$f4_operator_name', f4_operator_address = '$f4_operator_address', f4_operator_hotel = '$f4_operator_hotel', f4_operator_place = '$f4_operator_place', f4_expected_duration = '$f4_expected_duration', f4_expected_entries = '$f4_expected_entries', f4_port_arrival = '$f4_port_arrival', f4_port_exit = '$f4_port_exit', f4_visited_india = '$f4_visited_india', f4_visited_address = '$f4_visited_address', f4_visited_cities = '$f4_visited_cities', f4_visited_visa_num = '$f4_visited_visa_num', f4_visited_visa_type = '$f4_visited_visa_type', f4_visited_visa_place = '$f4_visited_visa_place', f4_visited_visa_issue = '$f4_visited_visa_issue', f4_permission_refused = '$f4_permission_refused', f4_permission_refused_more = '$f4_permission_refused_more', f4_saarc_last = '$f4_saarc_last', f4_saarc_visited = '$f4_saarc_visited', f4_saarc_countries = '$f4_saarc_countries', f4_saarc_years = '$f4_saarc_years', f4_saarc_visits = '$f4_saarc_visits',         f4_business_details = '$f4_business_details', f4_medical_details = '$f4_medical_details', f4_conference_details = '$f4_conference_details', f4_india_ref_name = '$f4_india_ref_name', f4_india_ref_address = '$f4_india_ref_address', f4_india_ref_phone = '$f4_india_ref_phone', f4_home_ref_name = '$f4_home_ref_name', f4_home_ref_address = '$f4_home_ref_address', f4_home_ref_phone = '$f4_home_ref_phone', f4_crime_1 = '$f4_crime_1', f4_crime_2 = '$f4_crime_2', f4_crime_3 = '$f4_crime_3', f4_crime_4 = '$f4_crime_4', f4_crime_5 = '$f4_crime_5', f4_crime_6 = '$f4_crime_6', f4_crime_details = '$f4_crime_details' WHERE form_id = '$form_id' ";

      // $query_sql5 = "UPDATE formdata_form5 SET form_type = '$form_type', f5_photo_upload = '$f5_photo_upload', f5_passport_pages = '$f5_passport_pages', f5_other_doc1 = '$f5_other_doc1', f5_other_doc2 = '$f5_other_doc2', f5_other_doc3 = '$f5_other_doc3', f5_other_doc4 = '$f5_other_doc4', f5_docs_check = '$f5_docs_check' WHERE form_id = '$form_id' ";

      $query_sql0 = "UPDATE formdata_main SET payment_status = '$fmain_payment_status', final_status = '$fmain_final_status', comments = '$fmain_comments' WHERE form_id = '$form_id' ";

      //execute query
      $que1 = mysqli_prepare($conn, $query_sql1);
      $que2 = mysqli_prepare($conn, $query_sql2);
      $que3 = mysqli_prepare($conn, $query_sql3);
      $que4 = mysqli_prepare($conn, $query_sql4);
      // $que5 = mysqli_prepare($conn, $query_sql5);
      $que0 = mysqli_prepare($conn, $query_sql0);
      if( $que1 && $que2 && $que3 && $que4 && $que0 ){
        mysqli_stmt_execute($que1);
        mysqli_stmt_execute($que2);
        mysqli_stmt_execute($que3);
        mysqli_stmt_execute($que4);
        // mysqli_stmt_execute($que5);
        mysqli_stmt_execute($que0);
        echo "<strong>SUCCESS: Application Forms Updated Successfully.</strong>";

        //redirect to next form
        //echo '<script>window.location="applications-single.php?view='.$form_id.'&updated=1";</script>';
        //echo '<script>window.location="#response";</script>';

      } else {
        echo "<strong>ERROR: Application not Updated. Please try again later.</strong>";
      }

    }
    ?>
  </div>

  <!-- update form -->
  <div class="form-box p-2">
    <form id="updatemon_form" name="updatemon_form" action="" method="post" enctype="multipart/form-data">
      <style>
        .form-control{
          width: 65%;
          display: inline-block;
          vertical-align: top;
          padding: 4px 8px;
          height: auto;
          font-size: 15px;
        }
        .form-control ~ small {
          color: #666;
          padding-left: 10px;
          width: 32%;
          display: inline-block;
          font-size: 11px;
          padding-top: 2px;
        }
      </style>

        <?php
          $select = "SELECT * FROM formdata_main WHERE form_id = '$form_id'";
          $que = mysqli_query($conn, $select);
          $fetch = mysqli_fetch_array($que);
          $datef = date('d M, Y', strtotime($fetch['dated']));

          //get all the data
          $form1_check = false;
          $form2_check = false;
          $form3_check = false;
          $form4_check = false;
          $form5_check = false;

          //form 1 check & data
          $form1_data_sql = "SELECT * FROM formdata_form1 WHERE form_id = '$form_id' ";
          $form1_data_query = mysqli_query($conn, $form1_data_sql);
          if(mysqli_num_rows($form1_data_query) > 0){
            $form1_check = true;
            $form1_row = mysqli_fetch_assoc($form1_data_query); //get fields
            $form_type = $form1_row['form_type'];
            //primary visa type
            $visa_type = $form1_row['e_visa_type'];
            $visa_type = str_replace('; ', ', ', $visa_type);
            $visa_subtype = $form1_row['e_visa_subtype'];
            $visa_subtype = str_replace('; ', ', ', $visa_subtype);
          }

          //form 2 check & data
          $form2_data_sql = "SELECT * FROM formdata_form2 WHERE form_id = '$form_id' ";
          $form2_data_query = mysqli_query($conn, $form2_data_sql);
          if(mysqli_num_rows($form2_data_query) > 0){
            $form2_check = true;
            $form2_row = mysqli_fetch_assoc($form2_data_query); //get fields
            $form_type = $form2_row['form_type'];
          }

          //form 3 check & data
          $form3_data_sql = "SELECT * FROM formdata_form3 WHERE form_id = '$form_id' ";
          $form3_data_query = mysqli_query($conn, $form3_data_sql);
          if(mysqli_num_rows($form3_data_query) > 0){
            $form3_check = true;
            $form3_row = mysqli_fetch_assoc($form3_data_query); //get fields
            $form_type = $form3_row['form_type'];
          }

          //form 4 check & data
          $form4_data_sql = "SELECT * FROM formdata_form4 WHERE form_id = '$form_id' ";
          $form4_data_query = mysqli_query($conn, $form4_data_sql);
          if(mysqli_num_rows($form4_data_query) > 0){
            $form4_check = true;
            $form4_row = mysqli_fetch_assoc($form4_data_query); //get fields
            $form_type = $form4_row['form_type'];
            $f4_business_details   = explode(';', $form4_row['f4_business_details']);    //7 values
            $f4_medical_details    = explode(';', $form4_row['f4_medical_details']);     //6 values
            $f4_conference_details = explode(';', $form4_row['f4_conference_details']);  //9 values
          }

          //form 5 check & data
          $form5_data_sql = "SELECT * FROM formdata_form5 WHERE form_id = '$form_id' ";
          $form5_data_query = mysqli_query($conn, $form5_data_sql);
          if(mysqli_num_rows($form5_data_query) > 0){
            $form5_check = true;
            $form5_row = mysqli_fetch_assoc($form5_data_query); //get fields
            $form_type = $form5_row['form_type'];
          }

          //check all previous forms data exists
          if( !$form1_check || !$form2_check || !$form3_check || !$form4_check || !$form5_check ) {
            echo "<h5 class='text-danger mb-3'> This Application is not complete. </h5>";
            // exit();
          }

          // filter table rows by form type
          if ( $form_type == 'tourist' || $form_type == 'business' || $form_type == 'medical' || $form_type == 'conference' ){
            ?>
            <script>
              $(document).ready(function(){
                $('.tablerow').hide();
                //set form to type
                var form_type = '.tablerow.<?php echo $form_type; ?>';
                $(form_type).show();
                console.log('rows filtered');
              });
            </script>
            <?php
          }
        ?>

        <div class="row border-bottom mb-3">
          <div class="col-md-8">
            <div class="pt-2 pb-3">
              <h4><?php echo $form_id; ?></h4>
              <!-- <small>User Email: <?php echo $fetch['user_email']; ?></small> -->
              <small class="text-muted">Submitted on <?php echo $datef; ?></small>
              <ul class="list-inline ">
                <li class="list-inline-item"> Form1
                  <?php echo ( $fetch['form1_status']=='completed' ) ? '<i class="fas fa-check-circle text-success"></i>' : '<i class="fas fa-circle text-secondary"></i>'; ?>
                </li>
                <li class="list-inline-item"> Form2
                  <?php echo ( $fetch['form2_status']=='completed' ) ? '<i class="fas fa-check-circle text-success"></i>' : '<i class="fas fa-circle text-secondary"></i>'; ?>
                </li>
                <li class="list-inline-item"> Form3
                  <?php echo ( $fetch['form3_status']=='completed' ) ? '<i class="fas fa-check-circle text-success"></i>' : '<i class="fas fa-circle text-secondary"></i>'; ?>
                </li>
                <li class="list-inline-item"> Form4
                  <?php echo ( $fetch['form4_status']=='completed' ) ? '<i class="fas fa-check-circle text-success"></i>' : '<i class="fas fa-circle text-secondary"></i>'; ?>
                </li>
                <li class="list-inline-item"> Form5
                  <?php echo ( $fetch['form5_status']=='completed' ) ? '<i class="fas fa-check-circle text-success"></i>' : '<i class="fas fa-circle text-secondary"></i>'; ?>
                </li><br />
                <li class="list-inline-item"> Payment:
                  <?php echo ( $fetch['payment_status']=='completed' ) ? 'Completed' : 'Pending'; ?>
                </li>
              </ul>
              <a class="btn btn-primary" href="applications-single.php?view=<?php echo $fetch['form_id']; ?>">View or Print</a>
              <a class="btn btn-danger" href="applications-single.php?del=<?php echo $fetch['form_id']; ?>">Delete</a>
              <!-- <a class="btn btn-dark" href="applications-single.php?print=<?php echo $fetch['form_id']; ?>">Print</a> -->
            </div>
          </div>
          <div class="col-md-4 pb-3">
            <?php echo (!empty($form5_row['f5_photo_upload'])) ? '<img src="../uploads/'.$form5_row["f5_photo_upload"].'" height="180" alt="image" />  ' : '<img src="img/user.png" alt="">'; ?>
          </div>
        </div>

        <!-- form 1 table -->
        <h5><strong>EDIT FORM 1</strong></h5>
        <table class="table table-bordered table-striped table-sm">
          <tbody>
            <tr>
              <td style="width: 35%;"> Created on </td>
              <td style="width: 65%;">
                <?php echo $form1_row['dated']; ?>
              </td>
            </tr>
            <tr>
              <td>Form Type</td>
              <td> <input type="text" class="form-control" name="form_type" value="<?php echo $form1_row['form_type']; ?>" readonly> </td>
            </tr>
            <tr>
              <td>Passport Type</td>
              <td> <input type="text" class="form-control" name="f1_pass_type" value="<?php echo $form1_row['f1_pass_type']; ?>" readonly> </td>
            </tr>
            <tr>
              <td>Nationality</td>
              <td> <input type="text" class="form-control" name="f1_nationality" value="<?php echo $form1_row['f1_nationality']; ?>"> </td>
            </tr>
            <tr>
              <td>Port of Arrival</td>
              <td> <input type="text" class="form-control" name="f1_port_arrival" value="<?php echo $form1_row['f1_port_arrival']; ?>"> </td>
            </tr>
            <tr>
              <td>Date of Birth</td>
              <td> <input type="text" class="form-control" name="f1_dob" value="<?php echo $form1_row['f1_dob']; ?>"> <small>dd-mm-yyyy</small> </td>
            </tr>
            <tr>
              <td>Email id</td>
              <td> <input type="text" class="form-control" name="f1_email" value="<?php echo $form1_row['f1_email']; ?>"> <small>example@mail.com</small> </td>
            </tr>
            <tr>
              <td>Date of Arrival</td>
              <td> <input type="text" class="form-control" name="f1_date_arrival" value="<?php echo $form1_row['f1_date_arrival']; ?>"> <small>dd-mm-yyyy</small> </td>
            </tr>
            <tr>
              <td>e-Visa Type</td>
              <td> <input type="text" class="form-control" name="e_visa_type" value="<?php echo $form1_row['e_visa_type']; ?>"> </td>
            </tr>
            <tr>
              <td>e-Visa SubType</td>
              <td> <input type="text" class="form-control" name="e_visa_subtype" value="<?php echo $form1_row['e_visa_subtype']; ?>"> </td>
            </tr>
          </tbody>
        </table>

        <!-- form 2 table -->
        <h5><strong>EDIT FORM 2</strong></h5>
        <table class="table table-bordered table-striped table-sm">
          <tbody>
            <tr>
              <td colspan="2"><strong>Applicant Details</strong></td>
            </tr>
            <tr>
              <td style="width: 35%;"> Surname (exactly as in your Passport) </td>
              <td style="width: 65%;">
                <input type="text" class="form-control" name="f2_surname" value="<?php echo $form2_row['f2_surname']; ?>">
              </td>
            </tr>
            <tr>
              <td>Given Name (exactly as in your Passport)</td>
              <td> <input type="text" class="form-control" name="f2_given_name" value="<?php echo $form2_row['f2_given_name']; ?>"> </td>
            </tr>
            <tr>
              <td>Have you ever changed your name?</td>
              <td> <input type="text" class="form-control" name="f2_name_changed" value="<?php echo $form2_row['f2_name_changed']; ?>"> </td>
            </tr>
            <tr>
              <td>Previous Surname</td>
              <td> <input type="text" class="form-control" name="f2_previous_surname" value="<?php echo $form2_row['f2_previous_surname']; ?>"> </td>
            </tr>
            <tr>
              <td>Previous Name</td>
              <td> <input type="text" class="form-control" name="f2_previous_name" value="<?php echo $form2_row['f2_previous_name']; ?>"> </td>
            </tr>
            <tr>
              <td>Gender</td>
              <td> <input type="text" class="form-control" name="f2_gender" value="<?php echo $form2_row['f2_gender']; ?>"> <small>Male / Female / Other</small> </td>
            </tr>
            <tr>
              <td>Date of Birth</td>
              <td> <input type="text" class="form-control" name="f2_dob" value="<?php echo $form2_row['f2_dob']; ?>"> <small>dd-mm-yyyy</small> </td>
            </tr>
            <tr>
              <td>Town/City of birth</td>
              <td> <input type="text" class="form-control" name="f2_birth_city" value="<?php echo $form2_row['f2_birth_city']; ?>"> </td>
            </tr>
            <tr>
              <td>Country of birth</td>
              <td> <input type="text" class="form-control" name="f2_birth_country" value="<?php echo $form2_row['f2_birth_country']; ?>"> </td>
            </tr>
            <tr>
              <td>Citizenship/National Id No.</td>
              <td> <input type="text" class="form-control" name="f2_national_id" value="<?php echo $form2_row['f2_national_id']; ?>"> </td>
            </tr>

            <tr>
              <td>Religion</td>
              <td> <input type="text" class="form-control" name="f2_religion" value="<?php echo $form2_row['f2_religion']; ?>"> </td>
            </tr>
            <tr>
              <td>Other Religion</td>
              <td> <input type="text" class="form-control" name="f2_religion_others" value="<?php echo $form2_row['f2_religion_others']; ?>"> </td>
            </tr>
            <tr>
              <td>Visible identification marks</td>
              <td> <input type="text" class="form-control" name="f2_visible_marks" value="<?php echo $form2_row['f2_visible_marks']; ?>"> </td>
            </tr>
            <tr>
              <td>Educational Qualification</td>
              <td> <input type="text" class="form-control" name="f2_edu_qualification" value="<?php echo $form2_row['f2_edu_qualification']; ?>"> </td>
            </tr>
            <tr>
              <td>Nationality</td>
              <td> <input type="text" class="form-control" name="f2_nationality" value="<?php echo $form2_row['f2_nationality']; ?>"></td>
            </tr>
            <tr>
              <td>Did you acquire Nationality by birth or by naturalization?</td>
              <td> <input type="text" class="form-control" name="f2_acquire_nationality" value="<?php echo $form2_row['f2_acquire_nationality']; ?>"> </td>
            </tr>
            <tr>
              <td>Previous Nationality</td>
              <td> <input type="text" class="form-control" name="f2_previous_nationality" value="<?php echo $form2_row['f2_previous_nationality']; ?>"> </td>
            </tr>
            <tr>
              <td>Have you lived for at least two years in the country where you are applying visa?</td>
              <td><input type="text" class="form-control" name="f2_lived_years" value="<?php echo $form2_row['f2_lived_years']; ?> "> <small>yes / no</small> </td>
            </tr>
            <tr>
              <td colspan="2"><strong>Passport Details</strong></td>
            </tr>
            <tr>
              <td>Passport No.</td>
              <td> <input type="text" class="form-control" name="f2_passport_num" value="<?php echo $form2_row['f2_passport_num']; ?>"> </td>
            </tr>
            <tr>
              <td>Place of Issue</td>
              <td> <input type="text" class="form-control" name="f2_issue_place" value="<?php echo $form2_row['f2_issue_place']; ?>"> </td>
            </tr>
            <tr>
              <td>Date of Issue</td>
              <td> <input type="text" class="form-control" name="f2_issue_date" value="<?php echo $form2_row['f2_issue_date']; ?>"> <small>dd-mm-yyyy</small> </td>
            </tr>
            <tr>
              <td>Date of Expiry</td>
              <td> <input type="text" class="form-control" name="f2_expiry_date" value="<?php echo $form2_row['f2_expiry_date']; ?>"> <small>dd-mm-yyyy</small> </td>
            </tr>
            <tr>
              <td>Any other valid Passport/Identity Certificate(IC) held?</td>
              <td> <input type="text" class="form-control" name="f2_other_passport" value="<?php echo $form2_row['f2_other_passport']; ?>"> </td>
            </tr>
            <tr>
              <td>Country of Issue</td>
              <td> <input type="text" class="form-control" name="f2_other_issue_country" value="<?php echo $form2_row['f2_other_issue_country']; ?>"> </td>
            </tr>
            <tr>
              <td>Passport/IC No.</td>
              <td> <input type="text" class="form-control" name="f2_other_passport_num" value="<?php echo $form2_row['f2_other_passport_num']; ?> "></td>
            </tr>
            <tr>
              <td>Date of Issue</td>
              <td> <input type="text" class="form-control" name="f2_other_issue_date" value="<?php echo $form2_row['f2_other_issue_date']; ?>"> <small>dd-mm-yyyy</small> </td>
            </tr>
            <tr>
              <td>Place of Issue</td>
              <td> <input type="text" class="form-control" name="f2_other_issue_place" value="<?php echo $form2_row['f2_other_issue_place']; ?>"> </td>
            </tr>
            <tr>
              <td>Nationality mentioned therein</td>
              <td> <input type="text" class="form-control" name="f2_other_pass_nationality" value="<?php echo $form2_row['f2_other_pass_nationality']; ?>"> </td>
            </tr>
          </tbody>
        </table>

        <!-- form 2 table -->
        <h5><strong>EDIT FORM 3</strong></h5>
        <table class="table table-bordered table-striped table-sm">
          <tbody>
            <tr>
              <td colspan="2"><strong>Applicant's Address Details</strong></td>
            </tr>
            <tr>
              <td style="width: 35%;">House no. / Street </td>
              <td style="width: 65%;">
              <input type="text" class="form-control" name="f3_house_num" value="<?php echo $form3_row['f3_house_num']; ?>">
              </td>
            </tr>
            <tr>
              <td>Village/Town/City</td>
              <td> <input type="text" class="form-control" name="f3_village_town" value="<?php echo $form3_row['f3_village_town']; ?>"> </td>
            </tr>
            <tr>
              <td>State/Province/District</td>
              <td> <input type="text" class="form-control" name="f3_state_province" value="<?php echo $form3_row['f3_state_province']; ?>"> </td>
            </tr>
            <tr>
              <td>Country</td>
              <td> <input type="text" class="form-control" name="f3_country" value="<?php echo $form3_row['f3_country']; ?>"> </td>
            </tr>
            <tr>
              <td>Postal/Zip Code</td>
              <td> <input type="text" class="form-control" name="f3_zip_code" value="<?php echo $form3_row['f3_zip_code']; ?>"> </td>
            </tr>
            <tr>
              <td>Phone No.</td>
              <td> <input type="text" class="form-control" name="f3_phone_num" value="<?php echo $form3_row['f3_phone_num']; ?>"> </td>
            </tr>
            <tr>
              <td>Mobile No.</td>
              <td> <input type="text" class="form-control" name="f3_mobile_num" value="<?php echo $form3_row['f3_mobile_num']; ?>"> </td>
            </tr>
            <tr>
              <td>Email Address </td>
              <td> <input type="text" class="form-control" name="f3_email" value="<?php echo $form3_row['f3_email']; ?>"> <small>example@mail.com</small> </td>
            </tr>
            <tr>
              <td>Permanent Address</td>
              <td> <input type="text" class="form-control" name="f3_same_address" value="<?php echo $form3_row['f3_same_address']; ?>"> </td>
            </tr>
            <tr>
              <td>Permanent House No./Street</td>
              <td> <input type="text" class="form-control" name="f3_perma_house_num" value="<?php echo $form3_row['f3_perma_house_num']; ?>"> </td>
            </tr>
            <tr>
              <td>Permanent Village/Town/City</td>
              <td> <input type="text" class="form-control" name="f3_perma_village_town" value="<?php echo $form3_row['f3_perma_village_town']; ?>"> </td>
            </tr>
            <tr>
              <td>Permanent State/Province/District</td>
              <td> <input type="text" class="form-control" name="f3_perma_state_province" value="<?php echo $form3_row['f3_perma_state_province']; ?>"> </td>
            </tr>
            <tr>
              <td colspan="2"><strong>Family Details</strong></td>
            </tr>
            <tr>
              <td>Father's Name</td>
              <td> <input type="text" class="form-control" name="f3_fathers_name" value="<?php echo $form3_row['f3_fathers_name']; ?>"> </td>
            </tr>
            <tr>
              <td>Father's Nationality</td>
              <td> <input type="text" class="form-control" name="f3_fathers_nationality" value="<?php echo $form3_row['f3_fathers_nationality']; ?>"> </td>
            </tr>
            <tr>
              <td>Father's Previous Nationality If required</td>
              <td> <input type="text" class="form-control" name="f3_fathers_prev_nationality" value="<?php echo $form3_row['f3_fathers_prev_nationality']; ?>"> </td>
            </tr>
            <tr>
              <td>Father's Place of Birth</td>
              <td> <input type="text" class="form-control" name="f3_fathers_birth_place" value="<?php echo $form3_row['f3_fathers_birth_place']; ?>"> </td>
            </tr>
            <tr>
              <td>Father's Country of Birth</td>
              <td> <input type="text" class="form-control" name="f3_fathers_birth_country" value="<?php echo $form3_row['f3_fathers_birth_country']; ?>"> </td>
            </tr>
            <tr>
              <td>Mother's Name</td>
              <td> <input type="text" class="form-control" name="f3_mothers_name" value="<?php echo $form3_row['f3_mothers_name']; ?>"> </td>
            </tr>
            <tr>
              <td>Mother's Nationality</td>
              <td> <input type="text" class="form-control" name="f3_mothers_nationality" value="<?php echo $form3_row['f3_mothers_nationality']; ?>"> </td>
            </tr>
            <tr>
              <td>Mother's Previous Nationality If required</td>
              <td> <input type="text" class="form-control" name="f3_mothers_prev_nationality" value="<?php echo $form3_row['f3_mothers_prev_nationality']; ?>"> </td>
            </tr>
            <tr>
              <td>Mother's Place of Birth</td>
              <td> <input type="text" class="form-control" name="f3_mothers_birth_place" value="<?php echo $form3_row['f3_mothers_birth_place']; ?>"> </td>
            </tr>
            <tr>
              <td>Mother's Country of Birth</td>
              <td> <input type="text" class="form-control" name="f3_mothers_birth_country" value="<?php echo $form3_row['f3_mothers_birth_country']; ?>"> </td>
            </tr>

            <tr>
              <td colspan="2"><strong>Applicant's Martial Details</strong></td>
            </tr>
            <tr>
              <td>Applicant's Marital Status</td>
              <td> <input type="text" class="form-control" name="f3_martial_status" value="<?php echo $form3_row['f3_martial_status']; ?>"> </td>
            </tr>
            <tr>
              <td>Spouse Name</td>
              <td> <input type="text" class="form-control" name="f3_spouse_name" value="<?php echo $form3_row['f3_spouse_name']; ?>"> </td>
            </tr>
            <tr>
              <td>Spouse Nationality</td>
              <td> <input type="text" class="form-control" name="f3_spouse_nationality" value="<?php echo $form3_row['f3_spouse_nationality']; ?>"> </td>
            </tr>
            <tr>
              <td>Spouse Previous Nationality If required</td>
              <td> <input type="text" class="form-control" name="f3_spouse_prev_nationality" value="<?php echo $form3_row['f3_spouse_prev_nationality']; ?>"> </td>
            </tr>
            <tr>
              <td>Spouse Place of Birth</td>
              <td> <input type="text" class="form-control" name="f3_spouse_birth_place" value="<?php echo $form3_row['f3_spouse_birth_place']; ?>"> </td>
            </tr>
            <tr>
              <td>Spouse Country of Birth</td>
              <td> <input type="text" class="form-control" name="f3_spouse_birth_country" value="<?php echo $form3_row['f3_spouse_birth_country']; ?>"> </td>
            </tr>
            <tr>
              <td>Were your Grandfather/Grandmother (paternal/maternal) Pakistan National or belong to Pakistan held area?</td>
              <td> <input type="text" class="form-control" name="f3_grand_in_pak" value="<?php echo $form3_row['f3_grand_in_pak']; ?>">  <small>yes / no</small> </td>
            </tr>
            <tr>
              <td>Grandfather's Pakistan Related Details </td>
              <td> <input type="text" class="form-control" name="f3_grand_in_pak_more" value="<?php echo $form3_row['f3_grand_in_pak_more']; ?>"> </td>
            </tr>
            <tr>
              <td colspan="2"><strong>Profession / Occupation Details of Applicant</strong></td>
            </tr>
            <tr>
            <tr>
              <td>Present Occupation</td>
              <td> <input type="text" class="form-control" name="f3_present_occupation" value="<?php echo $form3_row['f3_present_occupation']; ?>"> </td>
            </tr>
            <tr>
              <td>Other Present Occupation</td>
              <td> <input type="text" class="form-control" name="f3_occupation_more" value="<?php echo $form3_row['f3_occupation_more']; ?>"> </td>
            </tr>
            <tr>
              <td>Employer Name / Business</td>
              <td> <input type="text" class="form-control" name="f3_employer_business" value="<?php echo $form3_row['f3_employer_business']; ?>"> </td>
            </tr>
            <tr>
              <td>Designation</td>
              <td> <input type="text" class="form-control" name="f3_designation" value="<?php echo $form3_row['f3_designation']; ?>"> </td>
            </tr>
            <tr>
              <td>Address</td>
              <td> <input type="text" class="form-control" name="f3_work_address" value="<?php echo $form3_row['f3_work_address']; ?>"> </td>
            </tr>
            <tr>
              <td>Phone</td>
              <td> <input type="text" class="form-control" name="f3_work_phone" value="<?php echo $form3_row['f3_work_phone']; ?>"> </td>
            </tr>
            <tr>
              <td>Past Occupation, if any</td>
              <td> <input type="text" class="form-control" name="f3_past_occupation" value="<?php echo $form3_row['f3_past_occupation']; ?>"> </td>
            </tr>
            <tr>
              <td>Other Past Occupation</td>
              <td> <input type="text" class="form-control" name="f3_past_occupation_more" value="<?php echo $form3_row['f3_past_occupation_more']; ?>"> </td>
            </tr>
            <tr>
              <td>Are/were you in a Military/Semi-Military/Police/Security. Organization?</td>
              <td> <input type="text" class="form-control" name="f3_military_past" value="<?php echo $form3_row['f3_military_past']; ?>"> <small>yes / no</small> </td>
            </tr>
            <tr>
              <td>Military/Security Details</td>
              <td> <input type="text" class="form-control" name="f3_military_past_details" value="<?php echo $form3_row['f3_military_past_details']; ?>"> </td>
            </tr>
            <tr>
              <td>Military/Security Organisation</td>
              <td> <input type="text" class="form-control" name="f3_military_organisation" value="<?php echo $form3_row['f3_military_organisation']; ?>"> </td>
            </tr>
            <tr>
              <td>Military/Security Designation</td>
              <td> <input type="text" class="form-control" name="f3_military_designation" value="<?php echo $form3_row['f3_military_designation']; ?>"> </td>
            </tr>
            <tr>
              <td>Military/Security Rank</td>
              <td> <input type="text" class="form-control" name="f3_military_rank" value="<?php echo $form3_row['f3_military_rank']; ?>"> </td>
            </tr>
            <tr>
              <td>Military/Security Place of Posting</td>
              <td> <input type="text" class="form-control" name="f3_military_posting" value="<?php echo $form3_row['f3_military_posting']; ?>"> </td>
            </tr>
          </tbody>
        </table>

        <!-- form 4 table -->
        <h5><strong>EDIT FORM 4</strong></h5>
        <table class="table table-bordered table-striped table-sm">
          <tbody>
            <tr>
              <td colspan="2"><strong>Details of Visa Sought</strong></td>
            </tr>
            <tr>
              <td style="width: 35%;"> Type of Visa </td>
              <td style="width: 65%;">
                <input type="text" class="form-control" name="f4_visa_type" value="<?php echo $form4_row['f4_visa_type']; ?>">
              </td>
            </tr>
            <tr>
              <td>Visa Service</td>
              <td> <input type="text" class="form-control" name="f4_visa_subtype" value="<?php echo $form4_row['f4_visa_subtype']; ?>"> </td>
            </tr>
            <tr>
              <td>Places likely to be visited</td>
              <td> <input type="text" class="form-control" name="f4_places_visit" value="<?php echo $form4_row['f4_places_visit']; ?>"> </td>
            </tr>
            <tr>
              <td>Other Places likely to be visited</td>
              <td> <input type="text" class="form-control" name="f4_places_visit_more" value="<?php echo $form4_row['f4_places_visit_more']; ?>"> </td>
            </tr>
            <tr>
              <td>Have you booked any room in Hotel/Resort etc. through any Tour Operator?</td>
              <td> <input type="text" class="form-control" name="f4_tour_operator" value="<?php echo $form4_row['f4_tour_operator']; ?>"> <small>yes / no</small> </td>
            </tr>
            <tr>
              <td>Name of the tour operator</td>
              <td> <input type="text" class="form-control" name="f4_operator_name" value="<?php echo $form4_row['f4_operator_name']; ?>"> </td>
            </tr>
            <tr>
              <td>Address of the tour operator</td>
              <td> <input type="text" class="form-control" name="f4_operator_address" value="<?php echo $form4_row['f4_operator_address']; ?>"> </td>
            </tr>
            <tr>
              <td>Name of Hotel/Resort etc</td>
              <td> <input type="text" class="form-control" name="f4_operator_hotel" value="<?php echo $form4_row['f4_operator_hotel']; ?>"> </td>
            </tr>
            <tr>
              <td>Place/City of Hotel/Resort etc</td>
              <td> <input type="text" class="form-control" name="f4_operator_place" value="<?php echo $form4_row['f4_operator_place']; ?>"> </td>
            </tr>
            <tr class="tablerow business">
              <td colspan="2"><strong>Details of Purpose (Business)</strong></td>
            </tr>
            <tr class="tablerow business">
              <td>Applicant's Company Name</td>
              <td> <input type="text" class="form-control" name="f4_company_name" value="<?php echo $f4_business_details[0]; ?>"> </td>
            </tr>
            <tr class="tablerow business">
              <td>Applicant's Company Address/Phone</td>
              <td> <input type="text" class="form-control" name="f4_company_address" value="<?php echo $f4_business_details[1]; ?>"> </td>
            </tr>
            <tr class="tablerow business">
              <td>Applicant's Company Website</td>
              <td> <input type="text" class="form-control" name="f4_company_website" value="<?php echo $f4_business_details[2]; ?>"> </td>
            </tr>
            <tr class="tablerow business">
              <td>Indian firm's Name</td>
              <td> <input type="text" class="form-control" name="f4_ind_company_name" value="<?php echo $f4_business_details[3]; ?>"> </td>
            </tr>
            <tr class="tablerow business">
              <td>Indian firm's Address/Phone</td>
              <td> <input type="text" class="form-control" name="f4_ind_company_address" value="<?php echo $f4_business_details[4]; ?>"> </td>
            </tr>
            <tr class="tablerow business">
              <td>Indian firm's Website</td>
              <td> <input type="text" class="form-control" name="f4_ind_company_website" value="<?php echo $f4_business_details[5]; ?>"> </td>
            </tr>
            <tr class="tablerow business">
              <td>Nature of Business/Product</td>
              <td> <input type="text" class="form-control" name="f4_company_business" value="<?php echo $f4_business_details[6]; ?>"> </td>
            </tr>
            <tr class="tablerow medical">
              <td colspan="2"><strong>Details of Purpose (Medical)</strong></td>
            </tr>
            <tr class="tablerow medical">
              <td>Name of the Hospital</td>
              <td> <input type="text" class="form-control" name="f4_hospital_name" value="<?php echo $f4_medical_details[0]; ?>"> </td>
            </tr>
            <tr class="tablerow medical">
              <td>Hospital Address</td>
              <td> <input type="text" class="form-control" name="f4_hospital_address" value="<?php echo $f4_medical_details[1]; ?>"> </td>
            </tr>
            <tr class="tablerow medical">
              <td>Hospital State</td>
              <td> <input type="text" class="form-control" name="f4_hospital_state" value="<?php echo $f4_medical_details[2]; ?>"> </td>
            </tr>
            <tr class="tablerow medical">
              <td>Hospital District</td>
              <td> <input type="text" class="form-control" name="f4_hospital_district" value="<?php echo $f4_medical_details[3]; ?>"> </td>
            </tr>
            <tr class="tablerow medical">
              <td>Hospital Phone No.</td>
              <td> <input type="text" class="form-control" name="f4_hospital_phone" value="<?php echo $f4_medical_details[4]; ?>"> </td>
            </tr>
            <tr class="tablerow medical">
              <td>Type of Medical Treatment Required</td>
              <td> <input type="text" class="form-control" name="f4_hospital_treatment" value="<?php echo $f4_medical_details[5]; ?>"> </td>
            </tr>
            <tr class="tablerow conference">
              <td colspan="2"><strong>Details of Purpose (Conference)</strong></td>
            </tr>
            <tr class="tablerow conference">
              <td>Name/Subject of Conference</td>
              <td> <input type="text" class="form-control" name="f4_conf_name" value="<?php echo $f4_conference_details[0]; ?>"> </td>
            </tr>
            <tr class="tablerow conference">
              <td>Duration of Conference (Start-End Date)</td>
              <td> <input type="text" class="form-control" name="f4_conf_duration" value="<?php echo $f4_conference_details[1]; ?>"> </td>
            </tr>
            <tr class="tablerow conference">
              <td>Conference Address</td>
              <td> <input type="text" class="form-control" name="f4_conf_address" value="<?php echo $f4_conference_details[2]; ?>"> </td>
            </tr>
            <tr class="tablerow conference">
              <td>Conference Venue State</td>
              <td> <input type="text" class="form-control" name="f4_conf_state" value="<?php echo $f4_conference_details[3]; ?>"> </td>
            </tr>
            <tr class="tablerow conference">
              <td>Conference Venue District</td>
              <td> <input type="text" class="form-control" name="f4_conf_district" value="<?php echo $f4_conference_details[4]; ?>"> </td>
            </tr>
            <tr class="tablerow conference">
              <td>Conference Venue PinCode</td>
              <td> <input type="text" class="form-control" name="f4_conf_pincode" value="<?php echo $f4_conference_details[5]; ?>"> </td>
            </tr>
            <tr class="tablerow conference">
              <td>Conference Organizer Name</td>
              <td> <input type="text" class="form-control" name="f4_conf_org_name" value="<?php echo $f4_conference_details[6]; ?>"> </td>
            </tr>
            <tr class="tablerow conference">
              <td>Conference Organizer Address/Phone</td>
              <td> <input type="text" class="form-control" name="f4_conf_org_address" value="<?php echo $f4_conference_details[7]; ?>"> </td>
            </tr>
            <tr class="tablerow conference">
              <td>Conference Organizer Email</td>
              <td> <input type="text" class="form-control" name="f4_conf_org_email" value="<?php echo $f4_conference_details[8]; ?>"> </td>
            </tr>

            <tr>
              <td colspan="2"><strong>Details of Duration</strong></td>
            </tr>
            <tr>
              <td>Expected Duration of Visa (in Days)</td>
              <td> <input type="text" class="form-control" name="f4_expected_duration" value="<?php echo $form4_row['f4_expected_duration']; ?>"> </td>
            </tr>
            <tr>
              <td>Expected No. of Entries</td>
              <td> <input type="text" class="form-control" name="f4_expected_entries" value="<?php echo $form4_row['f4_expected_entries']; ?>"> </td>
            </tr>
            <tr>
              <td>Port of Arrival in India</td>
              <td> <input type="text" class="form-control" name="f4_port_arrival" value="<?php echo $form4_row['f4_port_arrival']; ?>"> </td>
            </tr>
            <tr>
              <td>Expected Port of Exit from India</td>
              <td> <input type="text" class="form-control" name="f4_port_exit" value="<?php echo $form4_row['f4_port_exit']; ?>"> </td>
            </tr>
            <tr>
              <td colspan="2"><strong>Previous Visa/Currently valid Visa Details</strong></td>
            </tr>
            <tr>
              <td>Have you ever visited India before?</td>
              <td> <input type="text" class="form-control" name="f4_visited_india" value="<?php echo $form4_row['f4_visited_india']; ?>"> <small>yes / no</small> </td>
            </tr>
            <tr>
              <td>Address</td>
              <td> <input type="text" class="form-control" name="f4_visited_address" value="<?php echo $form4_row['f4_visited_address']; ?>"> </td>
            </tr>
            <tr>
              <td>Cities previously visited in India</td>
              <td> <input type="text" class="form-control" name="f4_visited_cities" value="<?php echo $form4_row['f4_visited_cities']; ?>"> </td>
            </tr>
            <tr>
              <td>Last Indian Visa No/Currently valid Indian Visa No.</td>
              <td> <input type="text" class="form-control" name="f4_visited_visa_num" value="<?php echo $form4_row['f4_visited_visa_num']; ?>"> </td>
            </tr>
            <tr>
              <td>Type of Visa</td>
              <td> <input type="text" class="form-control" name="f4_visited_visa_type" value="<?php echo $form4_row['f4_visited_visa_type']; ?>"> </td>
            </tr>
            <tr>
              <td>Place of Issue</td>
              <td> <input type="text" class="form-control" name="f4_visited_visa_place" value="<?php echo $form4_row['f4_visited_visa_place']; ?>"> </td>
            </tr>
            <tr>
              <td>Date of Issue</td>
              <td> <input type="text" class="form-control" name="f4_visited_visa_issue" value="<?php echo $form4_row['f4_visited_visa_issue']; ?>"> <small>dd-mm-yyyy</small> </td>
            </tr>
            <tr>
              <td>Has permission to visit or to extend stay in India previously been refused?</td>
              <td> <input type="text" class="form-control" name="f4_permission_refused" value="<?php echo $form4_row['f4_permission_refused']; ?>"> <small>yes / no</small> </td>
            </tr>
            <tr>
              <td>When and By Whom?</td>
              <td> <input type="text" class="form-control" name="f4_permission_refused_more" value="<?php echo $form4_row['f4_permission_refused_more']; ?>"> </td>
            </tr>
            <tr>
              <td colspan="2"><strong>Other Information</strong></td>
            </tr>
            <tr>
              <td>Countries Visited in Last 10 years</td>
              <td> <input type="text" class="form-control" name="f4_saarc_last" value="<?php echo $form4_row['f4_saarc_last']; ?>"> </td>
            </tr>
            <tr>
              <td>SAARC Country Visit Details</td>
              <td> <input type="text" class="form-control" name="f4_saarc_visited" value="<?php echo $form4_row['f4_saarc_visited']; ?>"> <small>yes / no</small> </td>
            </tr>
            <tr>
              <td>Name of SAARC country</td>
              <td> <input type="text" class="form-control" name="f4_saarc_countries" value="<?php echo $form4_row['f4_saarc_countries']; ?>"> <small>semicolon (;) seprated values</small> </td>
            </tr>
            <tr>
              <td>Name of SAARC years</td>
              <td> <input type="text" class="form-control" name="f4_saarc_years" value="<?php echo $form4_row['f4_saarc_years']; ?>"> <small>semicolon (;) seprated values</small> </td>
            </tr>
            <tr>
              <td>Name of SAARC visits</td>
              <td> <input type="text" class="form-control" name="f4_saarc_visits" value="<?php echo $form4_row['f4_saarc_visits']; ?>"> <small>semicolon (;) seprated values</small> </td>
            </tr>

            <tr>
              <td colspan="2"><strong>Reference</strong></td>
            </tr>
            <tr>
              <td>Reference Name in India</td>
              <td> <input type="text" class="form-control" name="f4_india_ref_name" value="<?php echo $form4_row['f4_india_ref_name']; ?>"> </td>
            </tr>
            <tr>
              <td>Address</td>
              <td> <input type="text" class="form-control" name="f4_india_ref_address" value="<?php echo $form4_row['f4_india_ref_address']; ?>"> </td>
            </tr>
            <tr>
              <td>Phone</td>
              <td> <input type="text" class="form-control" name="f4_india_ref_phone" value="<?php echo $form4_row['f4_india_ref_phone']; ?>"> </td>
            </tr>
            <tr>
              <td>Reference Name in your Home Country</td>
              <td> <input type="text" class="form-control" name="f4_home_ref_name" value="<?php echo $form4_row['f4_home_ref_name']; ?>"> </td>
            </tr>
            <tr>
              <td>Address</td>
              <td> <input type="text" class="form-control" name="f4_home_ref_address" value="<?php echo $form4_row['f4_home_ref_address']; ?>"> </td>
            </tr>
            <tr>
              <td>Phone</td>
              <td> <input type="text" class="form-control" name="f4_home_ref_phone" value="<?php echo $form4_row['f4_home_ref_phone']; ?>"> </td>
            </tr>

            <tr>
              <td colspan="2"><strong>Activity Details</strong></td>
            </tr>
            <tr>
              <td>Have you ever been arrested / prosecuted / convicted by court of law of any country?</td>
              <td> <input type="text" class="form-control" name="f4_crime_1" value="<?php echo $form4_row['f4_crime_1']; ?>"> <small>yes / no</small> </td>
            </tr>
            <tr>
              <td>Have you ever been refused entry / deported by any country including India?</td>
              <td> <input type="text" class="form-control" name="f4_crime_2" value="<?php echo $form4_row['f4_crime_2']; ?>"> <small>yes / no</small> </td>
            </tr>
            <tr>
              <td>Have you ever been engaged in human traffecking/ drug traffecking/ child abuse/ crime against women/ Economic offense / Financial fraud?</td>
              <td> <input type="text" class="form-control" name="f4_crime_3" value="<?php echo $form4_row['f4_crime_3']; ?>"> <small>yes / no</small> </td>
            </tr>
            <tr>
              <td>Have you ever been engaged in cyber crime/ terrorist activities/ sabotage/ espionage/ genocide/ political killing/ other act of voilence?</td>
              <td> <input type="text" class="form-control" name="f4_crime_4" value="<?php echo $form4_row['f4_crime_4']; ?>"> <small>yes / no</small> </td>
            </tr>
            <tr>
              <td>Have you ever by any means or medium, expressed views that justify or glorify terrorist violence or that may encourage others to terrorist acts or other serious criminal acts?</td>
              <td> <input type="text" class="form-control" name="f4_crime_5" value="<?php echo $form4_row['f4_crime_5']; ?>"> <small>yes / no</small> </td>
            </tr>
            <tr>
              <td>Have you sought asylum (political or otherwise)in any country?</td>
              <td> <input type="text" class="form-control" name="f4_crime_6" value="<?php echo $form4_row['f4_crime_6']; ?>"> <small>yes / no</small> </td>
            </tr>
            <tr>
              <td>Details for Activity</td>
              <td> <input type="text" class="form-control" name="f4_crime_details" value="<?php echo $form4_row['f4_crime_details']; ?>"> </td>
            </tr>
          </tbody>
        </table>

        <!-- form 5 table -->
        <h5><strong>EDIT FORM 5</strong></h5>
        <table class="table table-bordered table-striped table-sm">
          <tbody>
            <tr>
              <td colspan="2"><strong>Uploaded Images/Documents</strong></td>
            </tr>
            <tr>
              <td style="width: 35%;"> PHOTO UPLOAD </td>
              <td style="width: 65%;">
                <input type="file" class="form-control-file" name="f5_photo_upload" accept="application/pdf, image/*">
                <?php echo (!empty($form5_row['f5_photo_upload'])) ? '<a class="btn btn-secondary btn-sm" href="../uploads/'.$form5_row["f5_photo_upload"].'" download>Download</a> <img src="../uploads/'.$form5_row["f5_photo_upload"].'" height="100" alt="image" />  ' : ''; ?>
              </td>
            </tr>
            <tr>
              <td>Passport pages</td>
              <td>
                <input type="file" class="form-control-file" name="f5_passport_pages" accept="application/pdf, image/*">
                <?php echo (!empty($form5_row['f5_passport_pages'])) ? '<a class="btn btn-secondary btn-sm" href="../uploads/'.$form5_row["f5_passport_pages"].'" download>Download</a> <img src="../uploads/'.$form5_row["f5_passport_pages"].'" height="100" alt="image" />  ' : ''; ?>
              </td>
            </tr>
            <tr>
              <td>Other Documents 1</td>
              <td>
                <input type="file" class="form-control-file" name="f5_other_doc1" accept="application/pdf, image/*">
                <?php echo (!empty($form5_row['f5_other_doc1'])) ? '<a class="btn btn-secondary btn-sm" href="../uploads/'.$form5_row["f5_other_doc1"].'" download>Download Document</a> ' : ''; ?>
              </td>
            </tr>
            <tr>
              <td>Other Documents 2</td>
              <td>
                <input type="file" class="form-control-file" name="f5_other_doc2" accept="application/pdf, image/*">
                <?php echo (!empty($form5_row['f5_other_doc2'])) ? '<a class="btn btn-secondary btn-sm" href="../uploads/'.$form5_row["f5_other_doc2"].'" download>Download Document</a> ' : ''; ?>
              </td>
            </tr>
            <tr>
              <td>Other Documents 3</td>
              <td>
                <input type="file" class="form-control-file" name="f5_other_doc3" accept="application/pdf, image/*">
                <?php echo (!empty($form5_row['f5_other_doc3'])) ? '<a class="btn btn-secondary btn-sm" href="../uploads/'.$form5_row["f5_other_doc3"].'" download>Download Document</a> ' : ''; ?>
              </td>
            </tr>
            <tr>
              <td>Other Documents 4</td>
              <td>
                <input type="file" class="form-control-file" name="f5_other_doc4" accept="application/pdf, image/*">
                <?php echo (!empty($form5_row['f5_other_doc4'])) ? '<a class="btn btn-secondary btn-sm" href="../uploads/'.$form5_row["f5_other_doc4"].'" download>Download Document</a> ' : ''; ?>
              </td>
            </tr>
          </tbody>
        </table>

        <!-- Admin Notes -->
        <h5 class="border-top pt-4 mt-4"><strong>NOTES</strong> <small>(For Admins use)</small> </h5>
        <table class="table table-bordered table-striped table-sm">
          <tbody>
            <tr class="table-warning">
              <td style="width: 35%;">Payment Status</td>
              <td> <input type="text" class="form-control" name="fmain_payment_status" value="<?php echo $fetch['payment_status']; ?>"> <small>pending / completed</small> </td>
            </tr>
            <tr class="table-warning">
              <td>Application Status</td>
              <td> <input type="text" class="form-control" name="fmain_final_status" value="<?php echo $fetch['final_status']; ?>"> <small>pending / processing / processed / waiting</small> </td>
            </tr>
            <tr>
              <td> Remarks </td>
              <td> <textarea class="form-control" name="fmain_comments"><?php echo $fetch['comments']; ?></textarea> <small>Extra notes or information</small> </td>
            </tr>
          </tbody>
        </table>

      <div class="my-4">
        <input type="submit" class="btn btn-primary" name="updatemon" value="UPDATE">
        <a href="applications.php" class="btn btn-dark">Cancel</a> <br><br>
      </div>

    </form>
  </div>
  <?php

/* ELSE SHOW MEMBER */
} else if(isset($_REQUEST['view'])) {
  $form_id = $_REQUEST['view'];
  ?>
      <!-- SHOW ALL ITEMS HERE -->
      <div class="p-2 border-bottom">
        <h3> <strong>View Application</strong> </h3>
        <p>Viewing individual Application details. Click <strong>Edit this</strong> button to modify details.</p>
      </div>

      <!-- response for updatemon -->
      <div class="pt-2 pl-2 h4">
        <?php
        if( isset($_REQUEST['updated']) ) {
          echo "<strong>SUCCESS: Application Details Updated Successfully.</strong>";
        }
        ?>
      </div>

      <div class="p-2">
        <?php
        $select = "SELECT * FROM formdata_main WHERE form_id = '$form_id'";
        $quer = mysqli_query($conn, $select);
        while($fetch = mysqli_fetch_array($quer)){
          $datef = date('d M, Y', strtotime($fetch['dated']));

          //get all the data
          $form1_check = false;
          $form2_check = false;
          $form3_check = false;
          $form4_check = false;
          $form5_check = false;

          //form 1 check & data
          $form1_data_sql = "SELECT * FROM formdata_form1 WHERE form_id = '$form_id' ";
          $form1_data_query = mysqli_query($conn, $form1_data_sql);
          if(mysqli_num_rows($form1_data_query) > 0){
            $form1_check = true;
            $form1_row = mysqli_fetch_assoc($form1_data_query); //get fields
            $form_type = $form1_row['form_type'];
            //primary visa type
            $visa_type = $form1_row['e_visa_type'];
            $visa_type = str_replace('; ', ', ', $visa_type);
            $visa_subtype = $form1_row['e_visa_subtype'];
            $visa_subtype = str_replace('; ', ', ', $visa_subtype);
          }

          //form 2 check & data
          $form2_data_sql = "SELECT * FROM formdata_form2 WHERE form_id = '$form_id' ";
          $form2_data_query = mysqli_query($conn, $form2_data_sql);
          if(mysqli_num_rows($form2_data_query) > 0){
            $form2_check = true;
            $form2_row = mysqli_fetch_assoc($form2_data_query); //get fields
            $form_type = $form2_row['form_type'];
          }

          //form 3 check & data
          $form3_data_sql = "SELECT * FROM formdata_form3 WHERE form_id = '$form_id' ";
          $form3_data_query = mysqli_query($conn, $form3_data_sql);
          if(mysqli_num_rows($form3_data_query) > 0){
            $form3_check = true;
            $form3_row = mysqli_fetch_assoc($form3_data_query); //get fields
            $form_type = $form3_row['form_type'];
          }

          //form 4 check & data
          $form4_data_sql = "SELECT * FROM formdata_form4 WHERE form_id = '$form_id' ";
          $form4_data_query = mysqli_query($conn, $form4_data_sql);
          if(mysqli_num_rows($form4_data_query) > 0){
            $form4_check = true;
            $form4_row = mysqli_fetch_assoc($form4_data_query); //get fields
            $form_type = $form4_row['form_type'];
            $f4_business_details   = explode(';', $form4_row['f4_business_details']);    //7 values
            $f4_medical_details    = explode(';', $form4_row['f4_medical_details']);     //5 values
            $f4_conference_details = explode(';', $form4_row['f4_conference_details']);  //9 values
          }

          //form 5 check & data
          $form5_data_sql = "SELECT * FROM formdata_form5 WHERE form_id = '$form_id' ";
          $form5_data_query = mysqli_query($conn, $form5_data_sql);
          if(mysqli_num_rows($form5_data_query) > 0){
            $form5_check = true;
            $form5_row = mysqli_fetch_assoc($form5_data_query); //get fields
            $form_type = $form5_row['form_type'];
          }

          //check all previous forms data exists
          if( !$form1_check || !$form2_check || !$form3_check || !$form4_check || !$form5_check ) {
            echo "<h5 class='text-danger mb-3'> This Application is not complete. </h5>";
            // exit();
          }

          // filter table rows by form type
          if ( $form_type == 'tourist' || $form_type == 'business' || $form_type == 'medical' || $form_type == 'conference' ){
            ?>
            <script>
              $(document).ready(function(){
                $('.tablerow').hide();
                //set form to type
                var form_type = '.tablerow.<?php echo $form_type; ?>';
                $(form_type).show();
                console.log('rows filtered');
              });
            </script>
            <?php
          }
          ?>

          <div id="printme">

            <div class="row border-bottom mb-3">
              <div class="col-md-8">
                <div class="pt-2 pb-3">
                  <h4><?php echo $form_id; ?></h4>
                  <!-- <small>User Email: <?php echo $fetch['user_email']; ?></small> -->
                  <small class="text-muted">Submitted on <?php echo $datef; ?></small>
                  <ul class="list-inline ">
                    <li class="list-inline-item"> Form1
                      <?php echo ( $fetch['form1_status']=='completed' ) ? '<i class="fas fa-check-circle text-success"></i>' : '<i class="fas fa-circle text-secondary"></i>'; ?>
                    </li>
                    <li class="list-inline-item"> Form2
                      <?php echo ( $fetch['form2_status']=='completed' ) ? '<i class="fas fa-check-circle text-success"></i>' : '<i class="fas fa-circle text-secondary"></i>'; ?>
                    </li>
                    <li class="list-inline-item"> Form3
                      <?php echo ( $fetch['form3_status']=='completed' ) ? '<i class="fas fa-check-circle text-success"></i>' : '<i class="fas fa-circle text-secondary"></i>'; ?>
                    </li>
                    <li class="list-inline-item"> Form4
                      <?php echo ( $fetch['form4_status']=='completed' ) ? '<i class="fas fa-check-circle text-success"></i>' : '<i class="fas fa-circle text-secondary"></i>'; ?>
                    </li>
                    <li class="list-inline-item"> Form5
                      <?php echo ( $fetch['form5_status']=='completed' ) ? '<i class="fas fa-check-circle text-success"></i>' : '<i class="fas fa-circle text-secondary"></i>'; ?>
                    </li><br />
                    <li class="list-inline-item"> Payment:
                      <?php echo ( $fetch['payment_status']=='completed' ) ? 'Completed' : 'Pending'; ?>
                    </li>
                  </ul>
                  <a class="btn btn-primary" href="applications-single.php?edit=<?php echo $fetch['form_id']; ?>">Edit this</a>
                  <a class="btn btn-danger" href="applications-single.php?del=<?php echo $fetch['form_id']; ?>">Delete</a>
                  <button type="button" class="btn btn-dark ml-5" onclick="PrintElem('printme')"> <i class="fa fa-print"></i> Print</button>
                  <script>
                    function PrintElem(elem){
                      var gethtml = document.getElementById('printme').innerHTML;
                      PrintFinal(gethtml);
                    }
                    function PrintFinal(data) {
                      var mywindow = window.open('', 'Print', 'height=600,width=800');
                      mywindow.document.open();
                      mywindow.document.onreadystatechange=function(){
                        if(this.readyState==='complete'){
                          this.onreadystatechange=function(){};
                          mywindow.focus();
                          mywindow.print();
                          mywindow.close();
                        }
                      }
                      mywindow.document.write('<html><head><title>Print Application</title>');
                      mywindow.document.write( '<link rel=\'stylesheet\' href=\'css/bootstrap.min.css\' type=\'text/css\' media=\'all\'/>' ); // attach stylesheet with print
                      mywindow.document.write( '<link rel=\'stylesheet\' href=\'css/sb-admin.css\' type=\'text/css\' media=\'all\'/>' ); // attach stylesheet with print
                      mywindow.document.write('</head><body >');
                      mywindow.document.write(data);
                      mywindow.document.write('data');
                      mywindow.document.write('</body></html>');
                      mywindow.document.close(); // necessary for IE >= 10
                      return true;
                    }
                  </script>
                </div>
              </div>
              <div class="col-md-4 pb-3">
                <?php echo (!empty($form5_row['f5_photo_upload'])) ? '<img src="../uploads/'.$form5_row["f5_photo_upload"].'" height="180" alt="image" />  ' : '<img src="img/user.png" alt="">'; ?>
              </div>
            </div>

            <!-- form 1 table -->
            <h5><strong>FORM 1</strong></h5>
            <table class="table table-bordered table-striped table-sm">
              <tbody>
                <tr>
                  <td style="width: 35%;"> Created on </td>
                  <td style="width: 65%;">
                    <?php echo $form1_row['dated']; ?>
                  </td>
                </tr>
                <tr>
                  <td>Form Type</td>
                  <td> <?php echo $form1_row['form_type']; ?> </td>
                </tr>
                <tr>
                  <td>Passport Type</td>
                  <td> <?php echo $form1_row['f1_pass_type']; ?> </td>
                </tr>
                <tr>
                  <td>Nationality</td>
                  <td> <?php echo $form1_row['f1_nationality']; ?> </td>
                </tr>
                <tr>
                  <td>Port of Arrival</td>
                  <td> <?php echo $form1_row['f1_port_arrival']; ?> </td>
                </tr>
                <tr>
                  <td>Date of Birth</td>
                  <td> <?php echo $form1_row['f1_dob']; ?> </td>
                </tr>
                <tr>
                  <td>Email id</td>
                  <td> <?php echo $form1_row['f1_email']; ?> </td>
                </tr>
                <tr>
                  <td>Date of Arrival</td>
                  <td> <?php echo $form1_row['f1_date_arrival']; ?> </td>
                </tr>
                <tr>
                  <td>e-Visa Type</td>
                  <td> <?php echo $form1_row['e_visa_type']; ?> </td>
                </tr>
                <tr>
                  <td>e-Visa SubType</td>
                  <td> <?php echo $form1_row['e_visa_subtype']; ?> </td>
                </tr>
              </tbody>
            </table>

            <!-- form 2 table -->
            <h5><strong>FORM 2</strong></h5>
            <table class="table table-bordered table-striped table-sm">
              <tbody>
                <tr>
                  <td colspan="2"><strong>Applicant Details</strong></td>
                </tr>
                <tr>
                  <td style="width: 35%;"> Surname (exactly as in your Passport) </td>
                  <td style="width: 65%;">
                    <?php echo $form2_row['f2_surname']; ?>
                  </td>
                </tr>
                <tr>
                  <td>Given Name (exactly as in your Passport)</td>
                  <td> <?php echo $form2_row['f2_given_name']; ?> </td>
                </tr>
                <tr>
                  <td>Have you ever changed your name?</td>
                  <td> <?php echo $form2_row['f2_name_changed']; ?> </td>
                </tr>
                <tr>
                  <td>Previous Surname</td>
                  <td> <?php echo $form2_row['f2_previous_surname']; ?> </td>
                </tr>
                <tr>
                  <td>Previous Name</td>
                  <td> <?php echo $form2_row['f2_previous_name']; ?> </td>
                </tr>
                <tr>
                  <td>Gender</td>
                  <td> <?php echo $form2_row['f2_gender']; ?> </td>
                </tr>
                <tr>
                  <td>Date of Birth</td>
                  <td> <?php echo $form2_row['f2_dob']; ?> </td>
                </tr>
                <tr>
                  <td>Town/City of birth</td>
                  <td> <?php echo $form2_row['f2_birth_city']; ?> </td>
                </tr>
                <tr>
                  <td>Country of birth</td>
                  <td> <?php echo $form2_row['f2_birth_country']; ?> </td>
                </tr>
                <tr>
                  <td>Citizenship/National Id No.</td>
                  <td> <?php echo $form2_row['f2_national_id']; ?> </td>
                </tr>

                <tr>
                  <td>Religion</td>
                  <td> <?php echo $form2_row['f2_religion']; ?> </td>
                </tr>
                <tr>
                  <td>Other Religion</td>
                  <td> <?php echo $form2_row['f2_religion_others']; ?> </td>
                </tr>
                <tr>
                  <td>Visible identification marks</td>
                  <td> <?php echo $form2_row['f2_visible_marks']; ?> </td>
                </tr>
                <tr>
                  <td>Educational Qualification</td>
                  <td> <?php echo $form2_row['f2_edu_qualification']; ?> </td>
                </tr>
                <tr>
                  <td>Nationality</td>
                  <td> <?php echo $form2_row['f2_nationality']; ?> </td>
                </tr>
                <tr>
                  <td>Did you acquire Nationality by birth or by naturalization?</td>
                  <td> <?php echo $form2_row['f2_acquire_nationality']; ?> </td>
                </tr>
                <tr>
                  <td>Previous Nationality</td>
                  <td> <?php echo $form2_row['f2_previous_nationality']; ?> </td>
                </tr>
                <tr>
                  <td>Have you lived for at least two years in the country where you are applying visa?</td>
                  <td> <?php echo $form2_row['f2_lived_years']; ?> </td>
                </tr>
                <tr>
                  <td colspan="2"><strong>Passport Details</strong></td>
                </tr>
                <tr>
                  <td>Passport No.</td>
                  <td> <?php echo $form2_row['f2_passport_num']; ?> </td>
                </tr>
                <tr>
                  <td>Place of Issue</td>
                  <td> <?php echo $form2_row['f2_issue_place']; ?> </td>
                </tr>
                <tr>
                  <td>Date of Issue</td>
                  <td> <?php echo $form2_row['f2_issue_date']; ?> </td>
                </tr>
                <tr>
                  <td>Date of Expiry</td>
                  <td> <?php echo $form2_row['f2_expiry_date']; ?> </td>
                </tr>
                <tr>
                  <td>Any other valid Passport/Identity Certificate(IC) held?</td>
                  <td> <?php echo $form2_row['f2_other_passport']; ?> </td>
                </tr>
                <tr>
                  <td>Country of Issue</td>
                  <td> <?php echo $form2_row['f2_other_issue_country']; ?> </td>
                </tr>
                <tr>
                  <td>Passport/IC No.</td>
                  <td> <?php echo $form2_row['f2_other_passport_num']; ?> </td>
                </tr>
                <tr>
                  <td>Date of Issue</td>
                  <td> <?php echo $form2_row['f2_other_issue_date']; ?> </td>
                </tr>
                <tr>
                  <td>Place of Issue</td>
                  <td> <?php echo $form2_row['f2_other_issue_place']; ?> </td>
                </tr>
                <tr>
                  <td>Nationality mentioned therein</td>
                  <td> <?php echo $form2_row['f2_other_pass_nationality']; ?> </td>
                </tr>
              </tbody>
            </table>

            <!-- form 2 table -->
            <h5><strong>FORM 3</strong></h5>
            <table class="table table-bordered table-striped table-sm">
              <tbody>
                <tr>
                  <td colspan="2"><strong>Applicant's Address Details</strong></td>
                </tr>
                <tr>
                  <td style="width: 35%;">House no. / Street </td>
                  <td style="width: 65%;">
                    <?php echo $form3_row['f3_house_num']; ?>
                  </td>
                </tr>
                <tr>
                  <td>Village/Town/City</td>
                  <td> <?php echo $form3_row['f3_village_town']; ?> </td>
                </tr>
                <tr>
                  <td>State/Province/District</td>
                  <td> <?php echo $form3_row['f3_state_province']; ?> </td>
                </tr>
                <tr>
                  <td>Country</td>
                  <td> <?php echo $form3_row['f3_country']; ?> </td>
                </tr>
                <tr>
                  <td>Postal/Zip Code</td>
                  <td> <?php echo $form3_row['f3_zip_code']; ?> </td>
                </tr>
                <tr>
                  <td>Phone No.</td>
                  <td> <?php echo $form3_row['f3_phone_num']; ?> </td>
                </tr>
                <tr>
                  <td>Mobile No.</td>
                  <td> <?php echo $form3_row['f3_mobile_num']; ?> </td>
                </tr>
                <tr>
                  <td>Email Address </td>
                  <td> <?php echo $form3_row['f3_email']; ?> </td>
                </tr>
                <tr>
                  <td>Permanent Address</td>
                  <td> <?php echo $form3_row['f3_same_address']; ?> </td>
                </tr>
                <tr>
                  <td>Permanent House No./Street</td>
                  <td> <?php echo $form3_row['f3_perma_house_num']; ?> </td>
                </tr>
                <tr>
                  <td>Permanent Village/Town/City</td>
                  <td> <?php echo $form3_row['f3_perma_village_town']; ?> </td>
                </tr>
                <tr>
                  <td>Permanent State/Province/District</td>
                  <td> <?php echo $form3_row['f3_perma_state_province']; ?> </td>
                </tr>
                <tr>
                  <td colspan="2"><strong>Family Details</strong></td>
                </tr>
                <tr>
                  <td>Father's Name</td>
                  <td> <?php echo $form3_row['f3_fathers_name']; ?> </td>
                </tr>
                <tr>
                  <td>Father's Nationality</td>
                  <td> <?php echo $form3_row['f3_fathers_nationality']; ?> </td>
                </tr>
                <tr>
                  <td>Father's Previous Nationality If required</td>
                  <td> <?php echo $form3_row['f3_fathers_prev_nationality']; ?> </td>
                </tr>
                <tr>
                  <td>Father's Place of Birth</td>
                  <td> <?php echo $form3_row['f3_fathers_birth_place']; ?> </td>
                </tr>
                <tr>
                  <td>Father's Country of Birth</td>
                  <td> <?php echo $form3_row['f3_fathers_birth_country']; ?> </td>
                </tr>
                <tr>
                  <td>Mother's Name</td>
                  <td> <?php echo $form3_row['f3_mothers_name']; ?> </td>
                </tr>
                <tr>
                  <td>Mother's Nationality</td>
                  <td> <?php echo $form3_row['f3_mothers_nationality']; ?> </td>
                </tr>
                <tr>
                  <td>Mother's Previous Nationality If required</td>
                  <td> <?php echo $form3_row['f3_mothers_prev_nationality']; ?> </td>
                </tr>
                <tr>
                  <td>Mother's Place of Birth</td>
                  <td> <?php echo $form3_row['f3_mothers_birth_place']; ?> </td>
                </tr>
                <tr>
                  <td>Mother's Country of Birth</td>
                  <td> <?php echo $form3_row['f3_mothers_birth_country']; ?> </td>
                </tr>

                <tr>
                  <td colspan="2"><strong>Applicant's Martial Details</strong></td>
                </tr>
                <tr>
                  <td>Applicant's Marital Status</td>
                  <td> <?php echo $form3_row['f3_martial_status']; ?> </td>
                </tr>
                <tr>
                  <td>Spouse Name</td>
                  <td> <?php echo $form3_row['f3_spouse_name']; ?> </td>
                </tr>
                <tr>
                  <td>Spouse Nationality</td>
                  <td> <?php echo $form3_row['f3_spouse_nationality']; ?> </td>
                </tr>
                <tr>
                  <td>Spouse Previous Nationality If required</td>
                  <td> <?php echo $form3_row['f3_spouse_prev_nationality']; ?> </td>
                </tr>
                <tr>
                  <td>Spouse Place of Birth</td>
                  <td> <?php echo $form3_row['f3_spouse_birth_place']; ?> </td>
                </tr>
                <tr>
                  <td>Spouse Country of Birth</td>
                  <td> <?php echo $form3_row['f3_spouse_birth_country']; ?> </td>
                </tr>
                <tr>
                  <td>Were your Grandfather/Grandmother (paternal/maternal) Pakistan National or belong to Pakistan held area?</td>
                  <td> <?php echo $form3_row['f3_grand_in_pak']; ?> </td>
                </tr>
                <tr>
                  <td>Grandfather's Pakistan Related Details </td>
                  <td> <?php echo $form3_row['f3_grand_in_pak_more']; ?> </td>
                </tr>
                <tr>
                  <td colspan="2"><strong>Profession / Occupation Details of Applicant</strong></td>
                </tr>
                <tr>
                <tr>
                  <td>Present Occupation</td>
                  <td> <?php echo $form3_row['f3_present_occupation']; ?> </td>
                </tr>
                <tr>
                  <td>Other Present Occupation</td>
                  <td> <?php echo $form3_row['f3_occupation_more']; ?> </td>
                </tr>
                <tr>
                  <td>Employer Name / Business</td>
                  <td> <?php echo $form3_row['f3_employer_business']; ?> </td>
                </tr>
                <tr>
                  <td>Designation</td>
                  <td> <?php echo $form3_row['f3_designation']; ?> </td>
                </tr>
                <tr>
                  <td>Address</td>
                  <td> <?php echo $form3_row['f3_work_address']; ?> </td>
                </tr>
                <tr>
                  <td>Phone</td>
                  <td> <?php echo $form3_row['f3_work_phone']; ?> </td>
                </tr>
                <tr>
                  <td>Past Occupation, if any</td>
                  <td> <?php echo $form3_row['f3_past_occupation']; ?> </td>
                </tr>
                <tr>
                  <td>Other Past Occupation</td>
                  <td> <?php echo $form3_row['f3_past_occupation_more']; ?> </td>
                </tr>
                <tr>
                  <td>Are/were you in a Military/Semi-Military/Police/Security. Organization?</td>
                  <td> <?php echo $form3_row['f3_military_past']; ?> </td>
                </tr>
                <tr>
                  <td>Military/Security Details</td>
                  <td> <?php echo $form3_row['f3_military_past_details']; ?> </td>
                </tr>
                <tr>
                  <td>Military/Security Organisation</td>
                  <td> <?php echo $form3_row['f3_military_organisation']; ?> </td>
                </tr>
                <tr>
                  <td>Military/Security Designation</td>
                  <td> <?php echo $form3_row['f3_military_designation']; ?> </td>
                </tr>
                <tr>
                  <td>Military/Security Rank</td>
                  <td> <?php echo $form3_row['f3_military_rank']; ?> </td>
                </tr>
                <tr>
                  <td>Military/Security Place of Posting</td>
                  <td> <?php echo $form3_row['f3_military_posting']; ?> </td>
                </tr>
              </tbody>
            </table>

            <!-- form 4 table -->
            <h5><strong>FORM 4</strong></h5>
            <table class="table table-bordered table-striped table-sm">
              <tbody>
                <tr>
                  <td colspan="2"><strong>Details of Visa Sought</strong></td>
                </tr>
                <tr>
                  <td style="width: 35%;"> Type of Visa </td>
                  <td style="width: 65%;">
                    <?php echo $form4_row['f4_visa_type']; ?>
                  </td>
                </tr>
                <tr>
                  <td>Visa Service</td>
                  <td> <?php echo $form4_row['f4_visa_subtype']; ?> </td>
                </tr>
                <tr>
                  <td>Places likely to be visited</td>
                  <td> <?php echo $form4_row['f4_places_visit']; ?> </td>
                </tr>
                <tr>
                  <td>Other Places likely to be visited</td>
                  <td> <?php echo $form4_row['f4_places_visit_more']; ?> </td>
                </tr>
                <tr>
                  <td>Have you booked any room in Hotel/Resort etc. through any Tour Operator?</td>
                  <td> <?php echo $form4_row['f4_tour_operator']; ?> </td>
                </tr>
                <tr>
                  <td>Name of the tour operator</td>
                  <td> <?php echo $form4_row['f4_operator_name']; ?> </td>
                </tr>
                <tr>
                  <td>Address of the tour operator</td>
                  <td> <?php echo $form4_row['f4_operator_address']; ?> </td>
                </tr>
                <tr>
                  <td>Name of Hotel/Resort etc</td>
                  <td> <?php echo $form4_row['f4_operator_hotel']; ?> </td>
                </tr>
                <tr>
                  <td>Place/City of Hotel/Resort etc</td>
                  <td> <?php echo $form4_row['f4_operator_place']; ?> </td>
                </tr>
                <tr class="tablerow business">
                  <td colspan="2"><strong>Details of Purpose (Business)</strong></td>
                </tr>
                <tr class="tablerow business">
                  <td>Applicant's Company Name</td>
                  <td> <?php echo $f4_business_details[0]; ?> </td>
                </tr>
                <tr class="tablerow business">
                  <td>Applicant's Company Address/Phone</td>
                  <td> <?php echo $f4_business_details[1]; ?> </td>
                </tr>
                <tr class="tablerow business">
                  <td>Applicant's Company Website</td>
                  <td> <?php echo $f4_business_details[2]; ?> </td>
                </tr>
                <tr class="tablerow business">
                  <td>Indian firm Name</td>
                  <td> <?php echo $f4_business_details[3]; ?> </td>
                </tr>
                <tr class="tablerow business">
                  <td>Indian firm's Address/Phone</td>
                  <td> <?php echo $f4_business_details[4]; ?> </td>
                </tr>
                <tr class="tablerow business">
                  <td>Indian firm's Website</td>
                  <td> <?php echo $f4_business_details[5]; ?> </td>
                </tr>
                <tr class="tablerow business">
                  <td>Nature of Business/Product</td>
                  <td> <?php echo $f4_business_details[6]; ?> </td>
                </tr>
                <tr class="tablerow medical">
                  <td colspan="2"><strong>Details of Purpose (Medical)</strong></td>
                </tr>
                <tr class="tablerow medical">
                  <td>Name of the Hospital</td>
                  <td> <?php echo $f4_medical_details[0]; ?> </td>
                </tr>
                <tr class="tablerow medical">
                  <td>Hospital Address</td>
                  <td> <?php echo $f4_medical_details[1]; ?> </td>
                </tr>
                <tr class="tablerow medical">
                  <td>Hospital State</td>
                  <td> <?php echo $f4_medical_details[2]; ?> </td>
                </tr>
                <tr class="tablerow medical">
                  <td>Hospital District</td>
                  <td> <?php echo $f4_medical_details[3]; ?> </td>
                </tr>
                <tr class="tablerow medical">
                  <td>Hospital Phone No.</td>
                  <td> <?php echo $f4_medical_details[4]; ?> </td>
                </tr>
                <tr class="tablerow medical">
                  <td>Type of Medical Treatment Required</td>
                  <td> <?php echo $f4_medical_details[5]; ?> </td>
                </tr>
                <tr class="tablerow conference">
                  <td colspan="2"><strong>Details of Purpose (Conference)</strong></td>
                </tr>
                <tr class="tablerow conference">
                  <td>Name/Subject of Conference</td>
                  <td> <?php echo $f4_conference_details[0]; ?> </td>
                </tr>
                <tr class="tablerow conference">
                  <td>Duration of Conference (Start-End Date)</td>
                  <td> <?php echo $f4_conference_details[1]; ?> </td>
                </tr>
                <tr class="tablerow conference">
                  <td>Conference Address</td>
                  <td> <?php echo $f4_conference_details[2]; ?> </td>
                </tr>
                <tr class="tablerow conference">
                  <td>Conference Venue State</td>
                  <td> <?php echo $f4_conference_details[3]; ?> </td>
                </tr>
                <tr class="tablerow conference">
                  <td>Conference Venue District</td>
                  <td> <?php echo $f4_conference_details[4]; ?> </td>
                </tr>
                <tr class="tablerow conference">
                  <td>Conference Venue PinCode</td>
                  <td> <?php echo $f4_conference_details[5]; ?> </td>
                </tr>
                <tr class="tablerow conference">
                  <td>Conference Organizer Name</td>
                  <td> <?php echo $f4_conference_details[6]; ?> </td>
                </tr>
                <tr class="tablerow conference">
                  <td>Conference Organizer Address/Phone</td>
                  <td> <?php echo $f4_conference_details[7]; ?> </td>
                </tr>
                <tr class="tablerow conference">
                  <td>Conference Organizer Email</td>
                  <td> <?php echo $f4_conference_details[8]; ?> </td>
                </tr>

                <tr>
                  <td colspan="2"><strong>Details of Duration</strong></td>
                </tr>
                <tr>
                  <td>Expected Duration of Visa (in Days)</td>
                  <td> <?php echo $form4_row['f4_expected_duration']; ?> </td>
                </tr>
                <tr>
                  <td>Expected No. of Entries</td>
                  <td> <?php echo $form4_row['f4_expected_entries']; ?> </td>
                </tr>
                <tr>
                  <td>Port of Arrival in India</td>
                  <td> <?php echo $form4_row['f4_port_arrival']; ?> </td>
                </tr>
                <tr>
                  <td>Expected Port of Exit from India</td>
                  <td> <?php echo $form4_row['f4_port_exit']; ?> </td>
                </tr>
                <tr>
                  <td colspan="2"><strong>Previous Visa/Currently valid Visa Details</strong></td>
                </tr>
                <tr>
                  <td>Have you ever visited India before?</td>
                  <td> <?php echo $form4_row['f4_visited_india']; ?> </td>
                </tr>
                <tr>
                  <td>Address</td>
                  <td> <?php echo $form4_row['f4_visited_address']; ?> </td>
                </tr>
                <tr>
                  <td>Cities previously visited in India</td>
                  <td> <?php echo $form4_row['f4_visited_cities']; ?> </td>
                </tr>
                <tr>
                  <td>Last Indian Visa No/Currently valid Indian Visa No.</td>
                  <td> <?php echo $form4_row['f4_visited_visa_num']; ?> </td>
                </tr>
                <tr>
                  <td>Type of Visa</td>
                  <td> <?php echo $form4_row['f4_visited_visa_type']; ?> </td>
                </tr>
                <tr>
                  <td>Place of Issue</td>
                  <td> <?php echo $form4_row['f4_visited_visa_place']; ?> </td>
                </tr>
                <tr>
                  <td>Date of Issue</td>
                  <td> <?php echo $form4_row['f4_visited_visa_issue']; ?> </td>
                </tr>
                <tr>
                  <td>Has permission to visit or to extend stay in India previously been refused?</td>
                  <td> <?php echo $form4_row['f4_permission_refused']; ?> </td>
                </tr>
                <tr>
                  <td>When and By Whom?</td>
                  <td> <?php echo $form4_row['f4_permission_refused_more']; ?> </td>
                </tr>
                <tr>
                  <td colspan="2"><strong>Other Information</strong></td>
                </tr>
                <tr>
                  <td>Countries Visited in Last 10 years</td>
                  <td> <?php echo $form4_row['f4_saarc_last']; ?> </td>
                </tr>
                <tr>
                  <td>SAARC Country Visit Details</td>
                  <td> <?php echo $form4_row['f4_saarc_visited']; ?> </td>
                </tr>
                <tr>
                  <td>Name of SAARC country</td>
                  <td> <?php echo $form4_row['f4_saarc_countries']; ?> </td>
                </tr>
                <tr>
                  <td>Name of SAARC years</td>
                  <td> <?php echo $form4_row['f4_saarc_years']; ?> </td>
                </tr>
                <tr>
                  <td>Name of SAARC visits</td>
                  <td> <?php echo $form4_row['f4_saarc_visits']; ?> </td>
                </tr>

                <tr>
                  <td colspan="2"><strong>Reference</strong></td>
                </tr>
                <tr>
                  <td>Reference Name in India</td>
                  <td> <?php echo $form4_row['f4_india_ref_name']; ?> </td>
                </tr>
                <tr>
                  <td>Address</td>
                  <td> <?php echo $form4_row['f4_india_ref_address']; ?> </td>
                </tr>
                <tr>
                  <td>Phone</td>
                  <td> <?php echo $form4_row['f4_india_ref_phone']; ?> </td>
                </tr>
                <tr>
                  <td>Reference Name in your Home Country</td>
                  <td> <?php echo $form4_row['f4_home_ref_name']; ?> </td>
                </tr>
                <tr>
                  <td>Address</td>
                  <td> <?php echo $form4_row['f4_home_ref_address']; ?> </td>
                </tr>
                <tr>
                  <td>Phone</td>
                  <td> <?php echo $form4_row['f4_home_ref_phone']; ?> </td>
                </tr>

                <tr>
                  <td colspan="2"><strong>Activity Details</strong></td>
                </tr>
                <tr>
                  <td>Have you ever been arrested / prosecuted / convicted by court of law of any country?</td>
                  <td> <?php echo $form4_row['f4_crime_1']; ?> </td>
                </tr>
                <tr>
                  <td>Have you ever been refused entry / deported by any country including India?</td>
                  <td> <?php echo $form4_row['f4_crime_2']; ?> </td>
                </tr>
                <tr>
                  <td>Have you ever been engaged in human traffecking/ drug traffecking/ child abuse/ crime against women/ Economic offense / Financial fraud?</td>
                  <td> <?php echo $form4_row['f4_crime_3']; ?> </td>
                </tr>
                <tr>
                  <td>Have you ever been engaged in cyber crime/ terrorist activities/ sabotage/ espionage/ genocide/ political killing/ other act of voilence?</td>
                  <td> <?php echo $form4_row['f4_crime_4']; ?> </td>
                </tr>
                <tr>
                  <td>Have you ever by any means or medium, expressed views that justify or glorify terrorist violence or that may encourage others to terrorist acts or other serious criminal acts?</td>
                  <td> <?php echo $form4_row['f4_crime_5']; ?> </td>
                </tr>
                <tr>
                  <td>Have you sought asylum (political or otherwise)in any country?</td>
                  <td> <?php echo $form4_row['f4_crime_6']; ?> </td>
                </tr>
                <tr>
                  <td>Details for Activity</td>
                  <td> <?php echo $form4_row['f4_crime_details']; ?> </td>
                </tr>
              </tbody>
            </table>

            <!-- form 5 table -->
            <h5><strong>FORM 5</strong></h5>
            <table class="table table-bordered table-striped table-sm">
              <tbody>
                <tr>
                  <td colspan="2"><strong>Uploaded Images/Documents</strong></td>
                </tr>
                <tr>
                  <td style="width: 35%;"> PHOTO UPLOAD </td>
                  <td style="width: 65%;">
                    <?php echo (!empty($form5_row['f5_photo_upload'])) ? '<a class="btn btn-secondary btn-sm" href="../uploads/'.$form5_row["f5_photo_upload"].'" download>Download</a> <img src="../uploads/'.$form5_row["f5_photo_upload"].'" height="100" alt="image" />  ' : ''; ?>
                  </td>
                </tr>
                <tr>
                  <td>Passport pages</td>
                  <td>
                    <?php echo (!empty($form5_row['f5_passport_pages'])) ? '<a class="btn btn-secondary btn-sm" href="../uploads/'.$form5_row["f5_passport_pages"].'" download>Download</a> <img src="../uploads/'.$form5_row["f5_passport_pages"].'" height="100" alt="image" />  ' : ''; ?>
                  </td>
                </tr>
                <tr>
                  <td>Other Documents 1</td>
                  <td>
                    <?php echo (!empty($form5_row['f5_other_doc1'])) ? '<a class="btn btn-secondary btn-sm" href="../uploads/'.$form5_row["f5_other_doc1"].'" download>Download</a> Document' : ''; ?>
                  </td>
                </tr>
                <tr>
                  <td>Other Documents 2</td>
                  <td>
                    <?php echo (!empty($form5_row['f5_other_doc2'])) ? '<a class="btn btn-secondary btn-sm" href="../uploads/'.$form5_row["f5_other_doc2"].'" download>Download</a> Document' : ''; ?>
                  </td>
                </tr>
                <tr>
                  <td>Other Documents 3</td>
                  <td>
                    <?php echo (!empty($form5_row['f5_other_doc3'])) ? '<a class="btn btn-secondary btn-sm" href="../uploads/'.$form5_row["f5_other_doc3"].'" download>Download</a> Document' : ''; ?>
                  </td>
                </tr>
                <tr>
                  <td>Other Documents 4</td>
                  <td>
                    <?php echo (!empty($form5_row['f5_other_doc4'])) ? '<a class="btn btn-secondary btn-sm" href="../uploads/'.$form5_row["f5_other_doc4"].'" download>Download</a> Document' : ''; ?>
                  </td>
                </tr>
              </tbody>
            </table>

            <!-- Admin Notes -->
            <h5 class="border-top pt-4 mt-4"><strong>NOTES</strong> <small>(For Admins use)</small> </h5>
            <table class="table table-bordered table-striped table-sm">
              <tbody>
                <tr class="table-warning">
                  <td style="width: 35%;">Payment Status</td>
                  <td style="width: 65%;"> <?php echo $fetch['payment_status']; ?> </td>
                </tr>
                <tr class="table-warning">
                  <td>Application Status</td>
                  <td> <?php echo $fetch['final_status']; ?> </td>
                </tr>
                <tr>
                  <td> Remarks </td>
                  <td> <p> <?php echo $fetch['comments']; ?> </p> </td>
                </tr>
              </tbody>
            </table>

          </div>

        <?php } ?>
      </div>
  <?php

/* ELSE SHOW ERROR */
} else {
  ?>
  <div class="p-3 border-bottom">
    <h3> <strong>Product not found</strong> </h3>
    <p>No Product found via given id. Please go back and try again.</p>
  </div>
  <?php

} //if else end
?>

<!-- include header -->
<?php include('inc/footer.php'); ?>