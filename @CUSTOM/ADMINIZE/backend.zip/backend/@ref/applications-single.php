<!-- include header -->
<?php include('inc/header.php'); ?>

<?php
// error_reporting(0);
/* IF DELETE MEMBER */
if(isset($_REQUEST['del'])) {
  $form_id = $_REQUEST['del'];
  ?>
    <div class="p-2 border-bottom">
      <h3> <strong>Delete Item</strong> </h3>
      <p>Confirm deletion of Specific Item.</p>
    </div>
    <div class="form-box p-2">
      <form id="id_card_form" name="id_card_form" action="" method="post">
        <?php
          $select = "SELECT * FROM formdata_main WHERE form_id = '$form_id'";
          $que = mysqli_query($conn, $select);
          $fet = mysqli_fetch_array($que);
        ?>
        <h5>Do you really want to delete application <strong><?php echo $fet['form_id']; ?> (Email: <?php echo $fet['user_email']; ?>) </strong>from database? </h5>
        <h6 class="text-danger"> Note: This action cannot be undone. </h6>
        <div class="text-left my-4">
          <input type="submit" class="btn btn-danger" name="deletemon" value="Delete">
          <a class="btn btn-dark" href="applications.php">Cancel</a>
        </div>
      </form>
    </div>

    <div id="response" class="h4">
      <?php
      if(isset($_POST['deletemon'])){
        $delete = "DELETE FROM products WHERE pid = '$form_id' ";
        $quer = mysqli_query($conn, $delete);
        if($quer){
          echo "<strong>SUCCESS: Member Deleted. Redirecting back...";
          echo '<script>window.location="products.php";</script>';
        } else{
          echo "<strong>ERROR: Member not deleted. Please try again later.</strong>";
        }
      }
      ?>
    </div>
    <?php

/* IF UPDATE MEMBER */
} else if(isset($_REQUEST['edit'])) {
  $form_id = $_REQUEST['edit'];
  ?>
  <div class="p-2 border-bottom">
    <h3> <strong>Edit Application</strong> </h3>
    <p>Edit Fields and Hit <strong>UPDATE</strong> on bottom. Some fields can't be changed. <br> <strong>Please Note Once values are updated, they cannot be reversed or undo.</strong> </p>
  </div>

  <!-- Operation updatemon -->
  <div id="response" class="h5">
    <?php
    if(isset($_POST['updatemon'])) {

      //required
      $proName         = mysqli_real_escape_string($conn, $_POST['proName']);
      $proCode         = mysqli_real_escape_string($conn, $_POST['proCode']);
      $proCatalogue    = mysqli_real_escape_string($conn, $_POST['proCatalogue']);
      $proChemical     = mysqli_real_escape_string($conn, $_POST['proChemical']);

      //optional
      $proSynonyms     = mysqli_real_escape_string($conn, $_POST['proSynonyms']);
      $proImpurity     = mysqli_real_escape_string($conn, $_POST['proImpurity']);
      $proCasnum       = mysqli_real_escape_string($conn, $_POST['proCasnum']);
      $proCasnumAlt    = mysqli_real_escape_string($conn, $_POST['proCasnumAlt']);
      $proMolecular    = mysqli_real_escape_string($conn, $_POST['proMolecular']);
      $proAppearance   = mysqli_real_escape_string($conn, $_POST['proAppearance']);
      $proMelting      = mysqli_real_escape_string($conn, $_POST['proMelting']);
      $proMolweight    = mysqli_real_escape_string($conn, $_POST['proMolweight']);
      $proStorage      = mysqli_real_escape_string($conn, $_POST['proStorage']);
      $proSolubility   = mysqli_real_escape_string($conn, $_POST['proSolubility']);
      $proStability    = mysqli_real_escape_string($conn, $_POST['proStability']);
      $proCategory     = mysqli_real_escape_string($conn, $_POST['proCategory']);
      $proBoiling      = mysqli_real_escape_string($conn, $_POST['proBoiling']);
      $proApplications = mysqli_real_escape_string($conn, $_POST['proApplications']);
      $proDangerous    = mysqli_real_escape_string($conn, $_POST['proDangerous']);
      $proReferences   = mysqli_real_escape_string($conn, $_POST['proReferences']);
      $proKeywords     = mysqli_real_escape_string($conn, $_POST['proKeywords']);
      $proExtraNotes   = mysqli_real_escape_string($conn, $_POST['proExtraNotes']);

      //packs
      $proProductPacks = '';
      for ($i=1; $i<11; $i++) {
        if( isset($_POST['proPack'.$i]) && !empty($_POST['proPack'.$i]) ){
          $proProductPacks .= mysqli_real_escape_string($conn, $_POST['proPack'.$i]) .";";
        }
      }

      if( empty($proName) || empty($proCode) || empty($proCatalogue) || empty($proChemical) ){
        echo "<strong>ERROR: Required fields Empty or Invalid. Please try again.</strong>";
        // exit;
      } else {

        //files
        $ex_sql   = "SELECT * FROM products WHERE pid = '$form_id' ";
        $ex_query = mysqli_query($conn, $ex_sql);
        $ex_row   = mysqli_fetch_array($ex_query);

        $proImage = $ex_row['proImage'];
        $proDocument = $ex_row['proDocument'];
        $fileserr1 = $fileserr2 = 0;
        // $uniqd = round(microtime(true));
        $uniqd = $proCode;

        //file1
        if( empty($_FILES['proImage']['name']) ){
          $proImage = $ex_row['proImage'];
          $fileserr1 = 0;
        } else if( ($_FILES['proImage']['size']==0) || ($_FILES['proImage']['size']>(2*1024*1024)) ) {
          $fileserr1 = 1;
        } else {
          $temp1        = explode(".", $_FILES["proImage"]["name"]);
          $newfilename1 = $uniqd . '_proImage' . '.' . end($temp1);
          $imagetmp1    = trim($_FILES['proImage']['tmp_name']);
          $path1        = "uploads/".$newfilename1;
          if( move_uploaded_file($imagetmp1, $path1) ){
            $proImage = $newfilename1;
          } else {
            $proImage = $ex_row['proImage'];
          }
          $fileserr1 = 0;
        }
        //file2
        if( empty($_FILES['proDocument']['name']) ){
          $proDocument = $ex_row['proDocument'];
          $fileserr2 = 0;
        } else if( ($_FILES['proDocument']['size']==0) || ($_FILES['proDocument']['size']>(2*1024*1024)) ) {
          $fileserr2 = 1;
        } else {
          $temp2        = explode(".", $_FILES["proDocument"]["name"]);
          $newfilename2 = $uniqd . '_proDocument' . '.' . end($temp2);
          $imagetmp2    = trim($_FILES['proDocument']['tmp_name']);
          $path2        = "uploads/".$newfilename2;
          if( move_uploaded_file($imagetmp2, $path2) ){
            $proDocument = $newfilename2;
          } else {
            $proDocument = $ex_row['proDocument'];
          }
          $fileserr2 = 0;
        }

        //no files error
        if( $fileserr1 == 1 || $fileserr2 == 1 ){
          echo "<strong>FAILED: Error in uploading Files. Max Size Allowed: 2 MB each.</strong>";
        } else {
          // update products to db
          $update = "UPDATE products SET proName='$proName', proCode='$proCode', proCatalogue='$proCatalogue', proChemical='$proChemical', proSynonyms='$proSynonyms', proImpurity='$proImpurity', proCasnum='$proCasnum', proCasnumAlt='$proCasnumAlt', proMolecular='$proMolecular', proAppearance='$proAppearance', proMelting='$proMelting', proMolweight='$proMolweight', proStorage='$proStorage', proSolubility='$proSolubility', proStability='$proStability', proCategory='$proCategory', proBoiling='$proBoiling', proApplications='$proApplications', proDangerous='$proDangerous', proReferences='$proReferences', proKeywords='$proKeywords', proExtraNotes='$proExtraNotes', proImage='$proImage', proDocument='$proDocument', proProductPacks='$proProductPacks' WHERE pid = '$form_id' ";
          $quer = mysqli_query($conn, $update);
          if($quer){
            echo "<strong>SUCCESS: Member Details Updated Successfully.</strong>";
            echo '<script>window.location="applications-single.php?view='.$form_id.'&updated=1";</script>';
            // echo '<script>window.location="#response";</script>';
          } else {
            echo "<strong>ERROR: Member Details not Updated. Please try again later.</strong>";
          }
        }
      }
    }
    ?>
  </div>

  <!-- update form -->
  <div class="form-box p-2">
    <form id="updatemon_form" name="updatemon_form" action="" method="post" enctype="multipart/form-data">
      <?php
          $select = "SELECT * FROM formdata_main WHERE form_id = '$form_id'";
          $que = mysqli_query($conn, $select);
          $fetch = mysqli_fetch_array($que);
          $datef = date('d M, Y', strtotime($fetch['dated']));

          //get all the data
          $form1_check = false;
          $form2_check = false;
          $form3_check = false;
          $form4_check = false;
          $form5_check = false;

          //form 1 check & data
          $form1_data_sql = "SELECT * FROM formdata_form1 WHERE form_id = '$form_id' ";
          $form1_data_query = mysqli_query($conn, $form1_data_sql);
          if(mysqli_num_rows($form1_data_query) > 0){
            $form1_check = true;
            $form1_row = mysqli_fetch_assoc($form1_data_query); //get fields
            $form_type = $form1_row['form_type'];
            //primary visa type
            $visa_type = $form1_row['e_visa_type'];
            $visa_type = str_replace('; ', ', ', $visa_type);
            $visa_subtype = $form1_row['e_visa_subtype'];
            $visa_subtype = str_replace('; ', ', ', $visa_subtype);
          }

          //form 2 check & data
          $form2_data_sql = "SELECT * FROM formdata_form2 WHERE form_id = '$form_id' ";
          $form2_data_query = mysqli_query($conn, $form2_data_sql);
          if(mysqli_num_rows($form2_data_query) > 0){
            $form2_check = true;
            $form2_row = mysqli_fetch_assoc($form2_data_query); //get fields
            $form_type = $form2_row['form_type'];
          }

          //form 3 check & data
          $form3_data_sql = "SELECT * FROM formdata_form3 WHERE form_id = '$form_id' ";
          $form3_data_query = mysqli_query($conn, $form3_data_sql);
          if(mysqli_num_rows($form3_data_query) > 0){
            $form3_check = true;
            $form3_row = mysqli_fetch_assoc($form3_data_query); //get fields
            $form_type = $form3_row['form_type'];
          }

          //form 4 check & data
          $form4_data_sql = "SELECT * FROM formdata_form4 WHERE form_id = '$form_id' ";
          $form4_data_query = mysqli_query($conn, $form4_data_sql);
          if(mysqli_num_rows($form4_data_query) > 0){
            $form4_check = true;
            $form4_row = mysqli_fetch_assoc($form4_data_query); //get fields
            $form_type = $form4_row['form_type'];
          }

          //form 5 check & data
          $form5_data_sql = "SELECT * FROM formdata_form5 WHERE form_id = '$form_id' ";
          $form5_data_query = mysqli_query($conn, $form5_data_sql);
          if(mysqli_num_rows($form5_data_query) > 0){
            $form5_check = true;
            $form5_row = mysqli_fetch_assoc($form5_data_query); //get fields
            $form_type = $form5_row['form_type'];
          }

          //check all previous forms data exists
          if( !$form1_check || !$form2_check || !$form3_check || !$form4_check || !$form5_check ) {
            echo "<h5 class='text-danger mb-3'> This Application is not complete. </h5>";
            // exit();
          }
          ?>

          <div class="row border-bottom mb-3">
            <div class="col-md-8">
              <div class="pt-2 pb-3">
                <h4><?php echo $form_id; ?></h4>
                <!-- <small>User Email: <?php echo $fetch['user_email']; ?></small> -->
                <small class="text-muted">Submitted on <?php echo $datef; ?></small>
                <ul class="list-inline ">
                  <li class="list-inline-item"> Form1
                    <?php echo ( $fetch['form1_status']=='completed' ) ? '<i class="fas fa-check-circle text-success"></i>' : '<i class="fas fa-circle text-secondary"></i>'; ?>
                  </li>
                  <li class="list-inline-item"> Form2
                    <?php echo ( $fetch['form2_status']=='completed' ) ? '<i class="fas fa-check-circle text-success"></i>' : '<i class="fas fa-circle text-secondary"></i>'; ?>
                  </li>
                  <li class="list-inline-item"> Form3
                    <?php echo ( $fetch['form3_status']=='completed' ) ? '<i class="fas fa-check-circle text-success"></i>' : '<i class="fas fa-circle text-secondary"></i>'; ?>
                  </li>
                  <li class="list-inline-item"> Form4
                    <?php echo ( $fetch['form4_status']=='completed' ) ? '<i class="fas fa-check-circle text-success"></i>' : '<i class="fas fa-circle text-secondary"></i>'; ?>
                  </li>
                  <li class="list-inline-item"> Form5
                    <?php echo ( $fetch['form5_status']=='completed' ) ? '<i class="fas fa-check-circle text-success"></i>' : '<i class="fas fa-circle text-secondary"></i>'; ?>
                  </li><br />
                  <li class="list-inline-item"> Payment:
                    <?php echo ( $fetch['payment_status']=='completed' ) ? 'Completed' : 'Pending'; ?>
                  </li>
                </ul>
                <a class="btn btn-primary" href="applications-single.php?view=<?php echo $fetch['form_id']; ?>">View or Print</a>
                <a class="btn btn-danger" href="applications-single.php?del=<?php echo $fetch['form_id']; ?>">Delete</a>
                <!-- <a class="btn btn-dark" href="applications-single.php?print=<?php echo $fetch['form_id']; ?>">Print</a> -->
                <small>  </small>
              </div>
            </div>
            <div class="col-md-4 pb-3">
              <?php echo (!empty($form5_row['f5_photo_upload'])) ? '<img src="../uploads/'.$form5_row["f5_photo_upload"].'" height="180" alt="image" />  ' : '<img src="img/user.png" alt="">'; ?>
            </div>
          </div>

          <!-- form 1 table -->
          <h5><strong>EDIT FORM 1</strong></h5>
          <table class="table table-bordered table-striped table-sm">
            <tbody>
              <tr>
                <td style="width: 35%;"> Created on </td>
                <td style="width: 65%;">
                  <?php echo $form1_row['dated']; ?>
                </td>
              </tr>
              <tr>
                <td>Form Type</td>
                <td> <?php echo $form1_row['form_type']; ?> </td>
              </tr>
              <tr>
                <td>Passport Type</td>
                <td> <?php echo $form1_row['f1_pass_type']; ?> </td>
              </tr>
              <tr>
                <td>Nationality</td>
                <td> <input type="text" class="form-control" name="f1_nationality" value="<?php echo $form1_row['f1_nationality']; ?>"> </td>
              </tr>
              <tr>
                <td>Port of Arrival</td>
                <td> <input type="text" class="form-control" name="f1_port_arrival" value="<?php echo $form1_row['f1_port_arrival']; ?>"> </td>
              </tr>
              <tr>
                <td>Date of Birth</td>
                <td> <input type="text" class="form-control" name="f1_dob" value="<?php echo $form1_row['f1_dob']; ?>"> </td>
              </tr>
              <tr>
                <td>Email id</td>
                <td> <input type="text" class="form-control" name="f1_email" value="<?php echo $form1_row['f1_email']; ?>"> </td>
              </tr>
              <tr>
                <td>Date of Arrival</td>
                <td> <input type="text" class="form-control" name="f1_date_arrival" value="<?php echo $form1_row['f1_date_arrival']; ?>"> </td>
              </tr>
              <tr>
                <td>e-Visa Type</td>
                <td> <input type="text" class="form-control" name="e_visa_type" value="<?php echo $form1_row['e_visa_type']; ?>"> </td>
              </tr>
              <tr>
                <td>e-Visa SubType</td>
                <td> <input type="text" class="form-control" name="e_visa_subtype" value="<?php echo $form1_row['e_visa_subtype']; ?>"> </td>
              </tr>
            </tbody>
          </table>

          <!-- form 2 table -->
          <h5><strong>EDIT FORM 2</strong></h5>
          <table class="table table-bordered table-striped table-sm">
            <tbody>
              <tr>
                <td colspan="2"><strong>Applicant Details</strong></td>
              </tr>
              <tr>
                <td style="width: 35%;"> Surname (exactly as in your Passport) </td>
                <td style="width: 65%;">
                  <input type="text" class="form-control" name="f2_surname" value="<?php echo $form2_row['f2_surname']; ?>">
                </td>
              </tr>
              <tr>
                <td>Given Name (exactly as in your Passport)</td>
                <td> <input type="text" class="form-control" name="f2_given_name" value="<?php echo $form2_row['f2_given_name']; ?>"> </td>
              </tr>
              <tr>
                <td>Have you ever changed your name?</td>
                <td> <input type="text" class="form-control" name="f2_name_changed" value="<?php echo $form2_row['f2_name_changed']; ?>"> </td>
              </tr>
              <tr>
                <td>Previous Surname</td>
                <td> <input type="text" class="form-control" name="f2_previous_surname" value="<?php echo $form2_row['f2_previous_surname']; ?>"> </td>
              </tr>
              <tr>
                <td>Previous Name</td>
                <td> <input type="text" class="form-control" name="f2_previous_name" value="<?php echo $form2_row['f2_previous_name']; ?>"> </td>
              </tr>
              <tr>
                <td>Gender</td>
                <td> <input type="text" class="form-control" name="f2_gender" value="<?php echo $form2_row['f2_gender']; ?>"> </td>
              </tr>
              <tr>
                <td>Date of Birth</td>
                <td> <input type="text" class="form-control" name="f2_dob" value="<?php echo $form2_row['f2_dob']; ?>"> </td>
              </tr>
              <tr>
                <td>Town/City of birth</td>
                <td> <input type="text" class="form-control" name="f2_birth_city" value="<?php echo $form2_row['f2_birth_city']; ?>"> </td>
              </tr>
              <tr>
                <td>Country of birth</td>
                <td> <input type="text" class="form-control" name="f2_birth_country" value="<?php echo $form2_row['f2_birth_country']; ?>"> </td>
              </tr>
              <tr>
                <td>Citizenship/National Id No.</td>
                <td> <input type="text" class="form-control" name="f2_national_id" value="<?php echo $form2_row['f2_national_id']; ?>"> </td>
              </tr>

              <tr>
                <td>Religion</td>
                <td> <input type="text" class="form-control" name="f2_religion" value="<?php echo $form2_row['f2_religion']; ?>"> </td>
              </tr>
              <tr>
                <td>Other Religion</td>
                <td> <input type="text" class="form-control" name="f2_religion_others" value="<?php echo $form2_row['f2_religion_others']; ?>"> </td>
              </tr>
              <tr>
                <td>Visible identification marks</td>
                <td> <input type="text" class="form-control" name="f2_visible_marks" value="<?php echo $form2_row['f2_visible_marks']; ?>"> </td>
              </tr>
              <tr>
                <td>Educational Qualification</td>
                <td> <input type="text" class="form-control" name="f2_edu_qualification" value="<?php echo $form2_row['f2_edu_qualification']; ?>"> </td>
              </tr>
              <tr>
                <td>Nationality</td>
                <td> <input type="text" class="form-control" name="f2_nationality" value="<?php echo $form2_row['f2_nationality']; ?>"></td>
              </tr>
              <tr>
                <td>Did you acquire Nationality by birth or by naturalization?</td>
                <td> <input type="text" class="form-control" name="f2_acquire_nationality" value="<?php echo $form2_row['f2_acquire_nationality']; ?>"> </td>
              </tr>
              <tr>
                <td>Previous Nationality</td>
                <td> <input type="text" class="form-control" name="f2_previous_nationality" value="<?php echo $form2_row['f2_previous_nationality']; ?>"> </td>
              </tr>
              <tr>
                <td>Have you lived for at least two years in the country where you are applying visa?</td>
                <td><input type="text" class="form-control" name="f2_lived_years" value="<?php echo $form2_row['f2_lived_years']; ?> "> </td>
              </tr>
              <tr>
                <td colspan="2"><strong>Passport Details</strong></td>
              </tr>
              <tr>
                <td>Passport No.</td>
                <td> <input type="text" class="form-control" name="f2_passport_num" value="<?php echo $form2_row['f2_passport_num']; ?>"> </td>
              </tr>
              <tr>
                <td>Place of Issue</td>
                <td> <input type="text" class="form-control" name="f2_issue_place" value="<?php echo $form2_row['f2_issue_place']; ?>"> </td>
              </tr>
              <tr>
                <td>Date of Issue</td>
                <td> <input type="text" class="form-control" name="f2_issue_date" value="<?php echo $form2_row['f2_issue_date']; ?>"> </td>
              </tr>
              <tr>
                <td>Date of Expiry</td>
                <td> <input type="text" class="form-control" name="f2_expiry_date" value="<?php echo $form2_row['f2_expiry_date']; ?>"> </td>
              </tr>
              <tr>
                <td>Any other valid Passport/Identity Certificate(IC) held?</td>
                <td> <input type="text" class="form-control" name="f2_other_passport" value="<?php echo $form2_row['f2_other_passport']; ?>"> </td>
              </tr>
              <tr>
                <td>Country of Issue</td>
                <td> <input type="text" class="form-control" name="f2_other_issue_country" value="<?php echo $form2_row['f2_other_issue_country']; ?>"> </td>
              </tr>
              <tr>
                <td>Passport/IC No.</td>
                <td> <input type="text" class="form-control" name="f2_other_passport_num" value="<?php echo $form2_row['f2_other_passport_num']; ?> "></td>
              </tr>
              <tr>
                <td>Date of Issue</td>
                <td> <input type="text" class="form-control" name="f2_other_issue_date" value="<?php echo $form2_row['f2_other_issue_date']; ?>"> </td>
              </tr>
              <tr>
                <td>Place of Issue</td>
                <td> <input type="text" class="form-control" name="f2_other_issue_place" value="<?php echo $form2_row['f2_other_issue_place']; ?>"> </td>
              </tr>
              <tr>
                <td>Nationality mentioned therein</td>
                <td> <input type="text" class="form-control" name="f2_other_pass_nationality" value="<?php echo $form2_row['f2_other_pass_nationality']; ?>"> </td>
              </tr>
            </tbody>
          </table>

          <!-- form 2 table -->
          <h5><strong>EDIT FORM 3</strong></h5>
          <table class="table table-bordered table-striped table-sm">
            <tbody>
              <tr>
                <td colspan="2"><strong>Applicant's Address Details</strong></td>
              </tr>
              <tr>
                <td style="width: 35%;">House no. / Street </td>
                <td style="width: 65%;">
                <input type="text" class="form-control" name="f3_house_num" value="<?php echo $form3_row['f3_house_num']; ?>">
                </td>
              </tr>
              <tr>
                <td>Village/Town/City</td>
                <td> <input type="text" class="form-control" name="f3_village_town" value="<?php echo $form3_row['f3_village_town']; ?>"> </td>
              </tr>
              <tr>
                <td>State/Province/District</td>
                <td> <input type="text" class="form-control" name="f3_state_province" value="<?php echo $form3_row['f3_state_province']; ?>"> </td>
              </tr>
              <tr>
                <td>Country</td>
                <td> <input type="text" class="form-control" name="f3_country" value="<?php echo $form3_row['f3_country']; ?>"> </td>
              </tr>
              <tr>
                <td>Postal/Zip Code</td>
                <td> <input type="text" class="form-control" name="f3_zip_code" value="<?php echo $form3_row['f3_zip_code']; ?>"> </td>
              </tr>
              <tr>
                <td>Phone No.</td>
                <td> <input type="text" class="form-control" name="f3_phone_num" value="<?php echo $form3_row['f3_phone_num']; ?>"> </td>
              </tr>
              <tr>
                <td>Mobile No.</td>
                <td> <input type="text" class="form-control" name="f3_mobile_num" value="<?php echo $form3_row['f3_mobile_num']; ?>"> </td>
              </tr>
              <tr>
                <td>Email Address </td>
                <td> <input type="text" class="form-control" name="f3_email" value="<?php echo $form3_row['f3_email']; ?>"> </td>
              </tr>
              <tr>
                <td>Permanent Address</td>
                <td> <input type="text" class="form-control" name="f3_same_address" value="<?php echo $form3_row['f3_same_address']; ?>"> </td>
              </tr>
              <tr>
                <td>Permanent House No./Street</td>
                <td> <input type="text" class="form-control" name="f3_perma_house_num" value="<?php echo $form3_row['f3_perma_house_num']; ?>"> </td>
              </tr>
              <tr>
                <td>Permanent Village/Town/City</td>
                <td> <input type="text" class="form-control" name="f3_perma_village_town" value="<?php echo $form3_row['f3_perma_village_town']; ?>"> </td>
              </tr>
              <tr>
                <td>Permanent State/Province/District</td>
                <td> <input type="text" class="form-control" name="f3_perma_state_province" value="<?php echo $form3_row['f3_perma_state_province']; ?>"> </td>
              </tr>
              <tr>
                <td colspan="2"><strong>Family Details</strong></td>
              </tr>
              <tr>
                <td>Father's Name</td>
                <td> <input type="text" class="form-control" name="f3_fathers_name" value="<?php echo $form3_row['f3_fathers_name']; ?>"> </td>
              </tr>
              <tr>
                <td>Father's Nationality</td>
                <td> <input type="text" class="form-control" name="f3_fathers_nationality" value="<?php echo $form3_row['f3_fathers_nationality']; ?>"> </td>
              </tr>
              <tr>
                <td>Father's Previous Nationality If required</td>
                <td> <input type="text" class="form-control" name="f3_fathers_prev_nationality" value="<?php echo $form3_row['f3_fathers_prev_nationality']; ?>"> </td>
              </tr>
              <tr>
                <td>Father's Place of Birth</td>
                <td> <input type="text" class="form-control" name="f3_fathers_birth_place" value="<?php echo $form3_row['f3_fathers_birth_place']; ?>"> </td>
              </tr>
              <tr>
                <td>Father's Country of Birth</td>
                <td> <input type="text" class="form-control" name="f3_fathers_birth_country" value="<?php echo $form3_row['f3_fathers_birth_country']; ?>"> </td>
              </tr>
              <tr>
                <td>Mother's Name</td>
                <td> <input type="text" class="form-control" name="f3_mothers_name" value="<?php echo $form3_row['f3_mothers_name']; ?>"> </td>
              </tr>
              <tr>
                <td>Mother's Nationality</td>
                <td> <input type="text" class="form-control" name="f3_mothers_nationality" value="<?php echo $form3_row['f3_mothers_nationality']; ?>"> </td>
              </tr>
              <tr>
                <td>Mother's Previous Nationality If required</td>
                <td> <input type="text" class="form-control" name="f3_mothers_prev_nationality" value="<?php echo $form3_row['f3_mothers_prev_nationality']; ?>"> </td>
              </tr>
              <tr>
                <td>Mother's Place of Birth</td>
                <td> <input type="text" class="form-control" name="f3_mothers_birth_place" value="<?php echo $form3_row['f3_mothers_birth_place']; ?>"> </td>
              </tr>
              <tr>
                <td>Mother's Country of Birth</td>
                <td> <input type="text" class="form-control" name="f3_mothers_birth_country" value="<?php echo $form3_row['f3_mothers_birth_country']; ?>"> </td>
              </tr>

              <tr>
                <td colspan="2"><strong>Applicant's Martial Details</strong></td>
              </tr>
              <tr>
                <td>Applicant's Marital Status</td>
                <td> <input type="text" class="form-control" name="f3_martial_status" value="<?php echo $form3_row['f3_martial_status']; ?>"> </td>
              </tr>
              <tr>
                <td>Spouse Name</td>
                <td> <input type="text" class="form-control" name="f3_spouse_name" value="<?php echo $form3_row['f3_spouse_name']; ?>"> </td>
              </tr>
              <tr>
                <td>Spouse Nationality</td>
                <td> <input type="text" class="form-control" name="f3_spouse_nationality" value="<?php echo $form3_row['f3_spouse_nationality']; ?>"> </td>
              </tr>
              <tr>
                <td>Spouse Previous Nationality If required</td>
                <td> <input type="text" class="form-control" name="f3_spouse_prev_nationality" value="<?php echo $form3_row['f3_spouse_prev_nationality']; ?>"> </td>
              </tr>
              <tr>
                <td>Spouse Place of Birth</td>
                <td> <input type="text" class="form-control" name="f3_spouse_birth_place" value="<?php echo $form3_row['f3_spouse_birth_place']; ?>"> </td>
              </tr>
              <tr>
                <td>Spouse Country of Birth</td>
                <td> <input type="text" class="form-control" name="f3_spouse_birth_country" value="<?php echo $form3_row['f3_spouse_birth_country']; ?>"> </td>
              </tr>
              <tr>
                <td>Were your Grandfather/Grandmother (paternal/maternal) Pakistan National or belong to Pakistan held area?</td>
                <td> <input type="text" class="form-control" name="f3_grand_in_pak" value="<?php echo $form3_row['f3_grand_in_pak']; ?>"> </td>
              </tr>
              <tr>
                <td>Grandfather's Pakistan Related Details </td>
                <td> <input type="text" class="form-control" name="f3_grand_in_pak_more" value="<?php echo $form3_row['f3_grand_in_pak_more']; ?>"> </td>
              </tr>
              <tr>
                <td colspan="2"><strong>Profession / Occupation Details of Applicant</strong></td>
              </tr>
              <tr>
              <tr>
                <td>Present Occupation</td>
                <td> <input type="text" class="form-control" name="f3_present_occupation" value="<?php echo $form3_row['f3_present_occupation']; ?>"> </td>
              </tr>
              <tr>
                <td>Other Present Occupation</td>
                <td> <input type="text" class="form-control" name="f3_occupation_more" value="<?php echo $form3_row['f3_occupation_more']; ?>"> </td>
              </tr>
              <tr>
                <td>Employer Name / Business</td>
                <td> <input type="text" class="form-control" name="f3_employer_business" value="<?php echo $form3_row['f3_employer_business']; ?>"> </td>
              </tr>
              <tr>
                <td>Designation</td>
                <td> <input type="text" class="form-control" name="f3_designation" value="<?php echo $form3_row['f3_designation']; ?>"> </td>
              </tr>
              <tr>
                <td>Address</td>
                <td> <input type="text" class="form-control" name="f3_work_address" value="<?php echo $form3_row['f3_work_address']; ?>"> </td>
              </tr>
              <tr>
                <td>Phone</td>
                <td> <input type="text" class="form-control" name="f3_work_phone" value="<?php echo $form3_row['f3_work_phone']; ?>"> </td>
              </tr>
              <tr>
                <td>Past Occupation, if any</td>
                <td> <input type="text" class="form-control" name="f3_past_occupation" value="<?php echo $form3_row['f3_past_occupation']; ?>"> </td>
              </tr>
              <tr>
                <td>Other Past Occupation</td>
                <td> <input type="text" class="form-control" name="f3_past_occupation_more" value="<?php echo $form3_row['f3_past_occupation_more']; ?>"> </td>
              </tr>
              <tr>
                <td>Are/were you in a Military/Semi-Military/Police/Security. Organization?</td>
                <td> <input type="text" class="form-control" name="f3_military_past" value="<?php echo $form3_row['f3_military_past']; ?>"> </td>
              </tr>
              <tr>
                <td>Military/Security Details</td>
                <td> <input type="text" class="form-control" name="f3_military_past_details" value="<?php echo $form3_row['f3_military_past_details']; ?>"> </td>
              </tr>
              <tr>
                <td>Military/Security Organisation</td>
                <td> <input type="text" class="form-control" name="f3_military_organisation" value="<?php echo $form3_row['f3_military_organisation']; ?>"> </td>
              </tr>
              <tr>
                <td>Military/Security Designation</td>
                <td> <input type="text" class="form-control" name="f3_military_designation" value="<?php echo $form3_row['f3_military_designation']; ?>"> </td>
              </tr>
              <tr>
                <td>Military/Security Rank</td>
                <td> <input type="text" class="form-control" name="f3_military_rank" value="<?php echo $form3_row['f3_military_rank']; ?>"> </td>
              </tr>
              <tr>
                <td>Military/Security Place of Posting</td>
                <td> <input type="text" class="form-control" name="f3_military_posting" value="<?php echo $form3_row['f3_military_posting']; ?>"> </td>
              </tr>
            </tbody>
          </table>

          <!-- form 4 table -->
          <h5><strong>EDIT FORM 4</strong></h5>
          <table class="table table-bordered table-striped table-sm">
            <tbody>
              <tr>
                <td colspan="2"><strong>Details of Visa Sought</strong></td>
              </tr>
              <tr>
                <td style="width: 35%;"> Type of Visa </td>
                <td style="width: 65%;">
                  <input type="text" class="form-control" name="f4_visa_type" value="<?php echo $form4_row['f4_visa_type']; ?>">
                </td>
              </tr>
              <tr>
                <td>Visa Service</td>
                <td> <input type="text" class="form-control" name="f4_visa_subtype" value="<?php echo $form4_row['f4_visa_subtype']; ?>"> </td>
              </tr>
              <tr>
                <td>Places likely to be visited</td>
                <td> <input type="text" class="form-control" name="f4_places_visit" value="<?php echo $form4_row['f4_places_visit']; ?>"> </td>
              </tr>
              <tr>
                <td>Other Places likely to be visited</td>
                <td> <input type="text" class="form-control" name="f4_places_visit_more" value="<?php echo $form4_row['f4_places_visit_more']; ?>"> </td>
              </tr>
              <tr>
                <td>Have you booked any room in Hotel/Resort etc. through any Tour Operator?</td>
                <td> <input type="text" class="form-control" name="f4_tour_operator" value="<?php echo $form4_row['f4_tour_operator']; ?>"> </td>
              </tr>
              <tr>
                <td>Name of the tour operator</td>
                <td> <input type="text" class="form-control" name="f4_operator_name" value="<?php echo $form4_row['f4_operator_name']; ?>"> </td>
              </tr>
              <tr>
                <td>Address of the tour operator</td>
                <td> <input type="text" class="form-control" name="f4_operator_address" value="<?php echo $form4_row['f4_operator_address']; ?>"> </td>
              </tr>
              <tr>
                <td>Name of Hotel/Resort etc</td>
                <td> <input type="text" class="form-control" name="f4_operator_hotel" value="<?php echo $form4_row['f4_operator_hotel']; ?>"> </td>
              </tr>
              <tr>
                <td>Place/City of Hotel/Resort etc</td>
                <td> <input type="text" class="form-control" name="f4_operator_place" value="<?php echo $form4_row['f4_operator_place']; ?>"> </td>
              </tr>
              <tr class="tablerow business">
                <td colspan="2"><strong>Details of Purpose (Business)</strong></td>
              </tr>
              <tr class="tablerow business">
                <td>Applicants Company Name</td>
                <td> <input type="text" class="form-control" name="f4_company_name" value="<?php echo $form4_row['f4_company_name']; ?>"> </td>
              </tr>
              <tr class="tablerow business">
                <td>Company Address/Phone</td>
                <td> <input type="text" class="form-control" name="f4_company_address" value="<?php echo $form4_row['f4_company_address']; ?>"> </td>
              </tr>
              <tr class="tablerow business">
                <td>Company Website</td>
                <td> <input type="text" class="form-control" name="f4_company_website" value="<?php echo $form4_row['f4_company_website']; ?>"> </td>
              </tr>
              <tr class="tablerow business">
                <td>Nature of Business/Product</td>
                <td> <input type="text" class="form-control" name="f4_company_business" value="<?php echo $form4_row['f4_company_business']; ?>"> </td>
              </tr>
              <tr class="tablerow medical">
                <td colspan="2"><strong>Details of Purpose (Medical)</strong></td>
              </tr>
              <tr class="tablerow medical">
                <td>Name of the Hospital</td>
                <td> <input type="text" class="form-control" name="f4_hospital_name" value="<?php echo $form4_row['f4_hospital_name']; ?>"> </td>
              </tr>
              <tr class="tablerow medical">
                <td>Hospital Address</td>
                <td> <input type="text" class="form-control" name="f4_hospital_address" value="<?php echo $form4_row['f4_hospital_address']; ?>"> </td>
              </tr>
              <tr class="tablerow medical">
                <td>Hospital State</td>
                <td> <input type="text" class="form-control" name="f4_hospital_state" value="<?php echo $form4_row['f4_hospital_state']; ?>"> </td>
              </tr>
              <tr class="tablerow medical">
                <td>Hospital District</td>
                <td> <input type="text" class="form-control" name="f4_hospital_district" value="<?php echo $form4_row['f4_hospital_district']; ?>"> </td>
              </tr>
              <tr class="tablerow medical">
                <td>Hospital Phone No.</td>
                <td> <input type="text" class="form-control" name="f4_hospital_phone" value="<?php echo $form4_row['f4_hospital_phone']; ?>"> </td>
              </tr>
              <tr class="tablerow medical">
                <td>Type of Medical Treatment Required</td>
                <td> <input type="text" class="form-control" name="f4_hospital_treatment" value="<?php echo $form4_row['f4_hospital_treatment']; ?>"> </td>
              </tr>
              <tr class="tablerow medical">
                <td colspan="2"><strong>Details of Purpose (Conference)</strong></td>
              </tr>
              <tr class="tablerow conference">
                <td>Name/Subject of Conference</td>
                <td> <input type="text" class="form-control" name="f4_conf_name" value="<?php echo $form4_row['f4_conf_name']; ?>"> </td>
              </tr>
              <tr class="tablerow conference">
                <td>Duration of Conference (Start-End Date)</td>
                <td> <input type="text" class="form-control" name="f4_conf_duration" value="<?php echo $form4_row['f4_conf_duration']; ?>"> </td>
              </tr>
              <tr class="tablerow conference">
                <td>Conference Address</td>
                <td> <input type="text" class="form-control" name="f4_conf_address" value="<?php echo $form4_row['f4_conf_address']; ?>"> </td>
              </tr>
              <tr class="tablerow conference">
                <td>Conference Venue State</td>
                <td> <input type="text" class="form-control" name="f4_conf_state" value="<?php echo $form4_row['f4_conf_state']; ?>"> </td>
              </tr>
              <tr class="tablerow conference">
                <td>Conference Venue District</td>
                <td> <input type="text" class="form-control" name="f4_conf_district" value="<?php echo $form4_row['f4_conf_district']; ?>"> </td>
              </tr>
              <tr class="tablerow conference">
                <td>Conference Venue PinCode</td>
                <td> <input type="text" class="form-control" name="xxx" value="<?php echo $form4_row['f4_conf_pincode']; ?>"> </td>
              </tr>
              <tr class="tablerow conference">
                <td>Conference Organizer Name</td>
                <td> <input type="text" class="form-control" name="f4_conf_org_name" value="<?php echo $form4_row['f4_conf_org_name']; ?>"> </td>
              </tr>
              <tr class="tablerow conference">
                <td>Conference Organizer Address/Phone</td>
                <td> <input type="text" class="form-control" name="f4_conf_org_address" value="<?php echo $form4_row['f4_conf_org_address']; ?>"> </td>
              </tr>
              <tr class="tablerow conference">
                <td>Conference Organizer Email</td>
                <td> <input type="text" class="form-control" name="f4_conf_org_email" value="<?php echo $form4_row['f4_conf_org_email']; ?>"> </td>
              </tr>

              <tr>
                <td colspan="2"><strong>Details of Duration</strong></td>
              </tr>
              <tr>
                <td>Expected Duration of Visa (in Days)</td>
                <td> <input type="text" class="form-control" name="f4_expected_duration" value="<?php echo $form4_row['f4_expected_duration']; ?>"> </td>
              </tr>
              <tr>
                <td>Expected No. of Entries</td>
                <td> <input type="text" class="form-control" name="f4_expected_entries" value="<?php echo $form4_row['f4_expected_entries']; ?>"> </td>
              </tr>
              <tr>
                <td>Port of Arrival in India</td>
                <td> <input type="text" class="form-control" name="f4_port_arrival" value="<?php echo $form4_row['f4_port_arrival']; ?>"> </td>
              </tr>
              <tr>
                <td>Expected Port of Exit from India</td>
                <td> <input type="text" class="form-control" name="f4_port_exit" value="<?php echo $form4_row['f4_port_exit']; ?>"> </td>
              </tr>
              <tr>
                <td colspan="2"><strong>Previous Visa/Currently valid Visa Details</strong></td>
              </tr>
              <tr>
                <td>Have you ever visited India before?</td>
                <td> <input type="text" class="form-control" name="f4_visited_india" value="<?php echo $form4_row['f4_visited_india']; ?>"> </td>
              </tr>
              <tr>
                <td>Address</td>
                <td> <input type="text" class="form-control" name="f4_visited_address" value="<?php echo $form4_row['f4_visited_address']; ?>"> </td>
              </tr>
              <tr>
                <td>Cities previously visited in India</td>
                <td> <input type="text" class="form-control" name="f4_visited_cities" value="<?php echo $form4_row['f4_visited_cities']; ?>"> </td>
              </tr>
              <tr>
                <td>Last Indian Visa No/Currently valid Indian Visa No.</td>
                <td> <input type="text" class="form-control" name="f4_visited_visa_num" value="<?php echo $form4_row['f4_visited_visa_num']; ?>"> </td>
              </tr>
              <tr>
                <td>Type of Visa</td>
                <td> <input type="text" class="form-control" name="f4_visited_visa_type" value="<?php echo $form4_row['f4_visited_visa_type']; ?>"> </td>
              </tr>
              <tr>
                <td>Place of Issue</td>
                <td> <input type="text" class="form-control" name="f4_visited_visa_place" value="<?php echo $form4_row['f4_visited_visa_place']; ?>"> </td>
              </tr>
              <tr>
                <td>Date of Issue</td>
                <td> <input type="text" class="form-control" name="f4_visited_visa_issue" value="<?php echo $form4_row['f4_visited_visa_issue']; ?>"> </td>
              </tr>
              <tr>
                <td>Has permission to visit or to extend stay in India previously been refused?</td>
                <td> <input type="text" class="form-control" name="f4_permission_refused" value="<?php echo $form4_row['f4_permission_refused']; ?>"> </td>
              </tr>
              <tr>
                <td>When and By Whom?</td>
                <td> <input type="text" class="form-control" name="f4_permission_refused_more" value="<?php echo $form4_row['f4_permission_refused_more']; ?>"> </td>
              </tr>
              <tr>
                <td colspan="2"><strong>Other Information</strong></td>
              </tr>
              <tr>
                <td>Countries Visited in Last 10 years</td>
                <td> <input type="text" class="form-control" name="f4_saarc_last" value="<?php echo $form4_row['f4_saarc_last']; ?>"> </td>
              </tr>
              <tr>
                <td>SAARC Country Visit Details</td>
                <td> <input type="text" class="form-control" name="f4_saarc_visited" value="<?php echo $form4_row['f4_saarc_visited']; ?>"> </td>
              </tr>
              <tr>
                <td>Name of SAARC country</td>
                <td> <input type="text" class="form-control" name="f4_saarc_countries" value="<?php echo $form4_row['f4_saarc_countries']; ?>"> </td>
              </tr>
              <tr>
                <td>Name of SAARC years</td>
                <td> <input type="text" class="form-control" name="f4_saarc_years" value="<?php echo $form4_row['f4_saarc_years']; ?>"> </td>
              </tr>
              <tr>
                <td>Name of SAARC visits</td>
                <td> <input type="text" class="form-control" name="f4_saarc_visits" value="<?php echo $form4_row['f4_saarc_visits']; ?>"> </td>
              </tr>

              <tr>
                <td colspan="2"><strong>Reference</strong></td>
              </tr>
              <tr>
                <td>Reference Name in India</td>
                <td> <input type="text" class="form-control" name="f4_india_ref_name" value="<?php echo $form4_row['f4_india_ref_name']; ?>"> </td>
              </tr>
              <tr>
                <td>Address</td>
                <td> <input type="text" class="form-control" name="f4_india_ref_address" value="<?php echo $form4_row['f4_india_ref_address']; ?>"> </td>
              </tr>
              <tr>
                <td>Phone</td>
                <td> <input type="text" class="form-control" name="f4_india_ref_phone" value="<?php echo $form4_row['f4_india_ref_phone']; ?>"> </td>
              </tr>
              <tr>
                <td>Reference Name in your Home Country</td>
                <td> <input type="text" class="form-control" name="f4_home_ref_name" value="<?php echo $form4_row['f4_home_ref_name']; ?>"> </td>
              </tr>
              <tr>
                <td>Address</td>
                <td> <input type="text" class="form-control" name="f4_home_ref_address" value="<?php echo $form4_row['f4_home_ref_address']; ?>"> </td>
              </tr>
              <tr>
                <td>Phone</td>
                <td> <input type="text" class="form-control" name="f4_home_ref_phone" value="<?php echo $form4_row['f4_home_ref_phone']; ?>"> </td>
              </tr>

              <tr>
                <td colspan="2"><strong>Activity Details</strong></td>
              </tr>
              <tr>
                <td>Have you ever been arrested / prosecuted / convicted by court of law of any country?</td>
                <td> <input type="text" class="form-control" name="f4_crime_1" value="<?php echo $form4_row['f4_crime_1']; ?>"> </td>
              </tr>
              <tr>
                <td>Have you ever been refused entry / deported by any country including India?</td>
                <td> <input type="text" class="form-control" name="f4_crime_2" value="<?php echo $form4_row['f4_crime_2']; ?>"> </td>
              </tr>
              <tr>
                <td>Have you ever been engaged in human traffecking/ drug traffecking/ child abuse/ crime against women/ Economic offense / Financial fraud?</td>
                <td> <input type="text" class="form-control" name="f4_crime_3" value="<?php echo $form4_row['f4_crime_3']; ?>"> </td>
              </tr>
              <tr>
                <td>Have you ever been engaged in cyber crime/ terrorist activities/ sabotage/ espionage/ genocide/ political killing/ other act of voilence?</td>
                <td> <input type="text" class="form-control" name="f4_crime_4" value="<?php echo $form4_row['f4_crime_4']; ?>"> </td>
              </tr>
              <tr>
                <td>Have you ever by any means or medium, expressed views that justify or glorify terrorist violence or that may encourage others to terrorist acts or other serious criminal acts?</td>
                <td> <input type="text" class="form-control" name="f4_crime_5" value="<?php echo $form4_row['f4_crime_5']; ?>"> </td>
              </tr>
              <tr>
                <td>Have you sought asylum (political or otherwise)in any country?</td>
                <td> <input type="text" class="form-control" name="f4_crime_6" value="<?php echo $form4_row['f4_crime_6']; ?>"> </td>
              </tr>
              <tr>
                <td>Details for Activity</td>
                <td> <input type="text" class="form-control" name="f4_crime_details" value="<?php echo $form4_row['f4_crime_details']; ?>"> </td>
              </tr>
            </tbody>
          </table>

          <!-- form 5 table -->
          <h5><strong>EDIT FORM 5</strong></h5>
          <table class="table table-bordered table-striped table-sm">
            <tbody>
              <tr>
                <td colspan="2"><strong>Uploaded Images/Documents</strong></td>
              </tr>
              <tr>
                <td style="width: 35%;"> PHOTO UPLOAD </td>
                <td style="width: 65%;">
                  <input type="file" class="form-control-file" name="f5_photo_upload" accept="application/pdf, image/*">
                  <?php echo (!empty($form5_row['f5_photo_upload'])) ? '<a class="btn btn-secondary btn-sm" href="../uploads/'.$form5_row["f5_photo_upload"].'" download>Download</a> <img src="../uploads/'.$form5_row["f5_photo_upload"].'" height="100" alt="image" />  ' : ''; ?>
                </td>
              </tr>
              <tr>
                <td>Passport pages</td>
                <td>
                  <input type="file" class="form-control-file" name="f5_passport_pages" accept="application/pdf, image/*">
                  <?php echo (!empty($form5_row['f5_passport_pages'])) ? '<a class="btn btn-secondary btn-sm" href="../uploads/'.$form5_row["f5_passport_pages"].'" download>Download</a> <img src="../uploads/'.$form5_row["f5_passport_pages"].'" height="100" alt="image" />  ' : ''; ?>
                </td>
              </tr>
              <tr>
                <td>Other Documents 1</td>
                <td>
                  <input type="file" class="form-control-file" name="f5_other_doc1" accept="application/pdf, image/*">
                  <?php echo (!empty($form5_row['f5_other_doc1'])) ? '<a class="btn btn-secondary btn-sm" href="../uploads/'.$form5_row["f5_other_doc1"].'" download>Download Document</a> ' : ''; ?>
                </td>
              </tr>
              <tr>
                <td>Other Documents 2</td>
                <td>
                  <input type="file" class="form-control-file" name="f5_other_doc2" accept="application/pdf, image/*">
                  <?php echo (!empty($form5_row['f5_other_doc2'])) ? '<a class="btn btn-secondary btn-sm" href="../uploads/'.$form5_row["f5_other_doc2"].'" download>Download Document</a> ' : ''; ?>
                </td>
              </tr>
              <tr>
                <td>Other Documents 3</td>
                <td>
                  <input type="file" class="form-control-file" name="f5_other_doc3" accept="application/pdf, image/*">
                  <?php echo (!empty($form5_row['f5_other_doc3'])) ? '<a class="btn btn-secondary btn-sm" href="../uploads/'.$form5_row["f5_other_doc3"].'" download>Download Document</a> ' : ''; ?>
                </td>
              </tr>
              <tr>
                <td>Other Documents 4</td>
                <td>
                  <input type="file" class="form-control-file" name="f5_other_doc4" accept="application/pdf, image/*">
                  <?php echo (!empty($form5_row['f5_other_doc4'])) ? '<a class="btn btn-secondary btn-sm" href="../uploads/'.$form5_row["f5_other_doc4"].'" download>Download Document</a> ' : ''; ?>
                </td>
              </tr>
            </tbody>
          </table>

          <!-- Admin Notes -->
          <h5><strong>SET NOTES</strong></h5>
          <table class="table table-bordered table-striped table-sm">
            <tbody>
              <tr>
                <td style="width: 35%;"> Remarks </td>
                <td style="width: 65%;">
                  <textarea class="form-control" name="fmain_comments"><?php echo $fetch['comments']; ?></textarea>
                </td>
              </tr>
              <tr>
                <td>Status</td>
                <td> <?php echo $fetch['final_status']; ?> </td>
              </tr>
            </tbody>
          </table>


      <div class="my-4">
        <input type="submit" class="btn btn-primary" name="updatemon" value="UPDATE">
        <a href="products.php" class="btn btn-dark">Cancel</a> <br><br>
      </div>

    </form>
  </div>
  <?php

/* ELSE SHOW MEMBER */
} else if(isset($_REQUEST['view'])) {
  $form_id = $_REQUEST['view'];
  ?>
      <!-- SHOW ALL ITEMS HERE -->
      <div class="p-2 border-bottom">
        <h3> <strong>View Application</strong> </h3>
        <p>Viewing individual Application details. Click <strong>Edit this</strong> button to modify details.</p>
      </div>

      <!-- response for updatemon -->
      <div class="pt-2 pl-2 h4">
        <?php
        if( isset($_REQUEST['updated']) ) {
          echo "<strong>SUCCESS: Application Details Updated Successfully.</strong>";
        }
        ?>
      </div>

      <div class="p-2">
        <?php
        $select = "SELECT * FROM formdata_main WHERE form_id = '$form_id'";
        $quer = mysqli_query($conn, $select);
        while($fetch = mysqli_fetch_array($quer)){
          $datef = date('d M, Y', strtotime($fetch['dated']));

          //get all the data
          $form1_check = false;
          $form2_check = false;
          $form3_check = false;
          $form4_check = false;
          $form5_check = false;

          //form 1 check & data
          $form1_data_sql = "SELECT * FROM formdata_form1 WHERE form_id = '$form_id' ";
          $form1_data_query = mysqli_query($conn, $form1_data_sql);
          if(mysqli_num_rows($form1_data_query) > 0){
            $form1_check = true;
            $form1_row = mysqli_fetch_assoc($form1_data_query); //get fields
            $form_type = $form1_row['form_type'];
            //primary visa type
            $visa_type = $form1_row['e_visa_type'];
            $visa_type = str_replace('; ', ', ', $visa_type);
            $visa_subtype = $form1_row['e_visa_subtype'];
            $visa_subtype = str_replace('; ', ', ', $visa_subtype);
          }

          //form 2 check & data
          $form2_data_sql = "SELECT * FROM formdata_form2 WHERE form_id = '$form_id' ";
          $form2_data_query = mysqli_query($conn, $form2_data_sql);
          if(mysqli_num_rows($form2_data_query) > 0){
            $form2_check = true;
            $form2_row = mysqli_fetch_assoc($form2_data_query); //get fields
            $form_type = $form2_row['form_type'];
          }

          //form 3 check & data
          $form3_data_sql = "SELECT * FROM formdata_form3 WHERE form_id = '$form_id' ";
          $form3_data_query = mysqli_query($conn, $form3_data_sql);
          if(mysqli_num_rows($form3_data_query) > 0){
            $form3_check = true;
            $form3_row = mysqli_fetch_assoc($form3_data_query); //get fields
            $form_type = $form3_row['form_type'];
          }

          //form 4 check & data
          $form4_data_sql = "SELECT * FROM formdata_form4 WHERE form_id = '$form_id' ";
          $form4_data_query = mysqli_query($conn, $form4_data_sql);
          if(mysqli_num_rows($form4_data_query) > 0){
            $form4_check = true;
            $form4_row = mysqli_fetch_assoc($form4_data_query); //get fields
            $form_type = $form4_row['form_type'];
          }

          //form 5 check & data
          $form5_data_sql = "SELECT * FROM formdata_form5 WHERE form_id = '$form_id' ";
          $form5_data_query = mysqli_query($conn, $form5_data_sql);
          if(mysqli_num_rows($form5_data_query) > 0){
            $form5_check = true;
            $form5_row = mysqli_fetch_assoc($form5_data_query); //get fields
            $form_type = $form5_row['form_type'];
          }

          //check all previous forms data exists
          if( !$form1_check || !$form2_check || !$form3_check || !$form4_check || !$form5_check ) {
            echo "<h5 class='text-danger mb-3'> This Application is not complete. </h5>";
            // exit();
          }
          ?>

          <div id="printme">

            <div class="row border-bottom mb-3">
              <div class="col-md-8">
                <div class="pt-2 pb-3">
                  <h4><?php echo $form_id; ?></h4>
                  <!-- <small>User Email: <?php echo $fetch['user_email']; ?></small> -->
                  <small class="text-muted">Submitted on <?php echo $datef; ?></small>
                  <ul class="list-inline ">
                    <li class="list-inline-item"> Form1
                      <?php echo ( $fetch['form1_status']=='completed' ) ? '<i class="fas fa-check-circle text-success"></i>' : '<i class="fas fa-circle text-secondary"></i>'; ?>
                    </li>
                    <li class="list-inline-item"> Form2
                      <?php echo ( $fetch['form2_status']=='completed' ) ? '<i class="fas fa-check-circle text-success"></i>' : '<i class="fas fa-circle text-secondary"></i>'; ?>
                    </li>
                    <li class="list-inline-item"> Form3
                      <?php echo ( $fetch['form3_status']=='completed' ) ? '<i class="fas fa-check-circle text-success"></i>' : '<i class="fas fa-circle text-secondary"></i>'; ?>
                    </li>
                    <li class="list-inline-item"> Form4
                      <?php echo ( $fetch['form4_status']=='completed' ) ? '<i class="fas fa-check-circle text-success"></i>' : '<i class="fas fa-circle text-secondary"></i>'; ?>
                    </li>
                    <li class="list-inline-item"> Form5
                      <?php echo ( $fetch['form5_status']=='completed' ) ? '<i class="fas fa-check-circle text-success"></i>' : '<i class="fas fa-circle text-secondary"></i>'; ?>
                    </li><br />
                    <li class="list-inline-item"> Payment:
                      <?php echo ( $fetch['payment_status']=='completed' ) ? 'Completed' : 'Pending'; ?>
                    </li>
                  </ul>
                  <a class="btn btn-primary" href="applications-single.php?edit=<?php echo $fetch['form_id']; ?>">Edit this</a>
                  <a class="btn btn-danger" href="applications-single.php?del=<?php echo $fetch['form_id']; ?>">Delete</a>
                  <button type="button" class="btn btn-dark ml-5" onclick="PrintElem('printme')"> <i class="fa fa-print"></i> Print</button>
                  <script>
                    function PrintElem(elem)	{
                      var mywindow = window.open('', 'PRINT', 'height=600,width=1100');
                      mywindow.document.write('<html><head><title>' + document.title  + '</title>');
                      mywindow.document.write( '<link rel=\'stylesheet\' href=\'css/bootstrap.min.css\' type=\'text/css\' media=\'all\'/>' ); // attach stylesheet with print
                      mywindow.document.write( '<link rel=\'stylesheet\' href=\'css/sb-admin.css\' type=\'text/css\' media=\'all\'/>' ); // attach stylesheet with print
                      mywindow.document.write('</head><body >');
                      mywindow.document.write(document.getElementById(elem).innerHTML);
                      mywindow.document.write('</body></html>');
                      mywindow.document.close(); // necessary for IE >= 10
                      mywindow.focus(); // necessary for IE >= 10*/
                      mywindow.print();
                      mywindow.close();
                      return true;
                    }
                  </script>
                </div>
              </div>
              <div class="col-md-4 pb-3">
                <?php echo (!empty($form5_row['f5_photo_upload'])) ? '<img src="../uploads/'.$form5_row["f5_photo_upload"].'" height="180" alt="image" />  ' : '<img src="img/user.png" alt="">'; ?>
              </div>
            </div>

            <!-- form 1 table -->
            <h5><strong>FORM 1</strong></h5>
            <table class="table table-bordered table-striped table-sm">
              <tbody>
                <tr>
                  <td style="width: 35%;"> Created on </td>
                  <td style="width: 65%;">
                    <?php echo $form1_row['dated']; ?>
                  </td>
                </tr>
                <tr>
                  <td>Form Type</td>
                  <td> <?php echo $form1_row['form_type']; ?> </td>
                </tr>
                <tr>
                  <td>Passport Type</td>
                  <td> <?php echo $form1_row['f1_pass_type']; ?> </td>
                </tr>
                <tr>
                  <td>Nationality</td>
                  <td> <?php echo $form1_row['f1_nationality']; ?> </td>
                </tr>
                <tr>
                  <td>Port of Arrival</td>
                  <td> <?php echo $form1_row['f1_port_arrival']; ?> </td>
                </tr>
                <tr>
                  <td>Date of Birth</td>
                  <td> <?php echo $form1_row['f1_dob']; ?> </td>
                </tr>
                <tr>
                  <td>Email id</td>
                  <td> <?php echo $form1_row['f1_email']; ?> </td>
                </tr>
                <tr>
                  <td>Date of Arrival</td>
                  <td> <?php echo $form1_row['f1_date_arrival']; ?> </td>
                </tr>
                <tr>
                  <td>e-Visa Type</td>
                  <td> <?php echo $form1_row['e_visa_type']; ?> </td>
                </tr>
                <tr>
                  <td>e-Visa SubType</td>
                  <td> <?php echo $form1_row['e_visa_subtype']; ?> </td>
                </tr>
              </tbody>
            </table>

            <!-- form 2 table -->
            <h5><strong>FORM 2</strong></h5>
            <table class="table table-bordered table-striped table-sm">
              <tbody>
                <tr>
                  <td colspan="2"><strong>Applicant Details</strong></td>
                </tr>
                <tr>
                  <td style="width: 35%;"> Surname (exactly as in your Passport) </td>
                  <td style="width: 65%;">
                    <?php echo $form2_row['f2_surname']; ?>
                  </td>
                </tr>
                <tr>
                  <td>Given Name (exactly as in your Passport)</td>
                  <td> <?php echo $form2_row['f2_given_name']; ?> </td>
                </tr>
                <tr>
                  <td>Have you ever changed your name?</td>
                  <td> <?php echo $form2_row['f2_name_changed']; ?> </td>
                </tr>
                <tr>
                  <td>Previous Surname</td>
                  <td> <?php echo $form2_row['f2_previous_surname']; ?> </td>
                </tr>
                <tr>
                  <td>Previous Name</td>
                  <td> <?php echo $form2_row['f2_previous_name']; ?> </td>
                </tr>
                <tr>
                  <td>Gender</td>
                  <td> <?php echo $form2_row['f2_gender']; ?> </td>
                </tr>
                <tr>
                  <td>Date of Birth</td>
                  <td> <?php echo $form2_row['f2_dob']; ?> </td>
                </tr>
                <tr>
                  <td>Town/City of birth</td>
                  <td> <?php echo $form2_row['f2_birth_city']; ?> </td>
                </tr>
                <tr>
                  <td>Country of birth</td>
                  <td> <?php echo $form2_row['f2_birth_country']; ?> </td>
                </tr>
                <tr>
                  <td>Citizenship/National Id No.</td>
                  <td> <?php echo $form2_row['f2_national_id']; ?> </td>
                </tr>

                <tr>
                  <td>Religion</td>
                  <td> <?php echo $form2_row['f2_religion']; ?> </td>
                </tr>
                <tr>
                  <td>Other Religion</td>
                  <td> <?php echo $form2_row['f2_religion_others']; ?> </td>
                </tr>
                <tr>
                  <td>Visible identification marks</td>
                  <td> <?php echo $form2_row['f2_visible_marks']; ?> </td>
                </tr>
                <tr>
                  <td>Educational Qualification</td>
                  <td> <?php echo $form2_row['f2_edu_qualification']; ?> </td>
                </tr>
                <tr>
                  <td>Nationality</td>
                  <td> <?php echo $form2_row['f2_nationality']; ?> </td>
                </tr>
                <tr>
                  <td>Did you acquire Nationality by birth or by naturalization?</td>
                  <td> <?php echo $form2_row['f2_acquire_nationality']; ?> </td>
                </tr>
                <tr>
                  <td>Previous Nationality</td>
                  <td> <?php echo $form2_row['f2_previous_nationality']; ?> </td>
                </tr>
                <tr>
                  <td>Have you lived for at least two years in the country where you are applying visa?</td>
                  <td> <?php echo $form2_row['f2_lived_years']; ?> </td>
                </tr>
                <tr>
                  <td colspan="2"><strong>Passport Details</strong></td>
                </tr>
                <tr>
                  <td>Passport No.</td>
                  <td> <?php echo $form2_row['f2_passport_num']; ?> </td>
                </tr>
                <tr>
                  <td>Place of Issue</td>
                  <td> <?php echo $form2_row['f2_issue_place']; ?> </td>
                </tr>
                <tr>
                  <td>Date of Issue</td>
                  <td> <?php echo $form2_row['f2_issue_date']; ?> </td>
                </tr>
                <tr>
                  <td>Date of Expiry</td>
                  <td> <?php echo $form2_row['f2_expiry_date']; ?> </td>
                </tr>
                <tr>
                  <td>Any other valid Passport/Identity Certificate(IC) held?</td>
                  <td> <?php echo $form2_row['f2_other_passport']; ?> </td>
                </tr>
                <tr>
                  <td>Country of Issue</td>
                  <td> <?php echo $form2_row['f2_other_issue_country']; ?> </td>
                </tr>
                <tr>
                  <td>Passport/IC No.</td>
                  <td> <?php echo $form2_row['f2_other_passport_num']; ?> </td>
                </tr>
                <tr>
                  <td>Date of Issue</td>
                  <td> <?php echo $form2_row['f2_other_issue_date']; ?> </td>
                </tr>
                <tr>
                  <td>Place of Issue</td>
                  <td> <?php echo $form2_row['f2_other_issue_place']; ?> </td>
                </tr>
                <tr>
                  <td>Nationality mentioned therein</td>
                  <td> <?php echo $form2_row['f2_other_pass_nationality']; ?> </td>
                </tr>
              </tbody>
            </table>

            <!-- form 2 table -->
            <h5><strong>FORM 3</strong></h5>
            <table class="table table-bordered table-striped table-sm">
              <tbody>
                <tr>
                  <td colspan="2"><strong>Applicant's Address Details</strong></td>
                </tr>
                <tr>
                  <td style="width: 35%;">House no. / Street </td>
                  <td style="width: 65%;">
                    <?php echo $form3_row['f3_house_num']; ?>
                  </td>
                </tr>
                <tr>
                  <td>Village/Town/City</td>
                  <td> <?php echo $form3_row['f3_village_town']; ?> </td>
                </tr>
                <tr>
                  <td>State/Province/District</td>
                  <td> <?php echo $form3_row['f3_state_province']; ?> </td>
                </tr>
                <tr>
                  <td>Country</td>
                  <td> <?php echo $form3_row['f3_country']; ?> </td>
                </tr>
                <tr>
                  <td>Postal/Zip Code</td>
                  <td> <?php echo $form3_row['f3_zip_code']; ?> </td>
                </tr>
                <tr>
                  <td>Phone No.</td>
                  <td> <?php echo $form3_row['f3_phone_num']; ?> </td>
                </tr>
                <tr>
                  <td>Mobile No.</td>
                  <td> <?php echo $form3_row['f3_mobile_num']; ?> </td>
                </tr>
                <tr>
                  <td>Email Address </td>
                  <td> <?php echo $form3_row['f3_email']; ?> </td>
                </tr>
                <tr>
                  <td>Permanent Address</td>
                  <td> <?php echo $form3_row['f3_same_address']; ?> </td>
                </tr>
                <tr>
                  <td>Permanent House No./Street</td>
                  <td> <?php echo $form3_row['f3_perma_house_num']; ?> </td>
                </tr>
                <tr>
                  <td>Permanent Village/Town/City</td>
                  <td> <?php echo $form3_row['f3_perma_village_town']; ?> </td>
                </tr>
                <tr>
                  <td>Permanent State/Province/District</td>
                  <td> <?php echo $form3_row['f3_perma_state_province']; ?> </td>
                </tr>
                <tr>
                  <td colspan="2"><strong>Family Details</strong></td>
                </tr>
                <tr>
                  <td>Father's Name</td>
                  <td> <?php echo $form3_row['f3_fathers_name']; ?> </td>
                </tr>
                <tr>
                  <td>Father's Nationality</td>
                  <td> <?php echo $form3_row['f3_fathers_nationality']; ?> </td>
                </tr>
                <tr>
                  <td>Father's Previous Nationality If required</td>
                  <td> <?php echo $form3_row['f3_fathers_prev_nationality']; ?> </td>
                </tr>
                <tr>
                  <td>Father's Place of Birth</td>
                  <td> <?php echo $form3_row['f3_fathers_birth_place']; ?> </td>
                </tr>
                <tr>
                  <td>Father's Country of Birth</td>
                  <td> <?php echo $form3_row['f3_fathers_birth_country']; ?> </td>
                </tr>
                <tr>
                  <td>Mother's Name</td>
                  <td> <?php echo $form3_row['f3_mothers_name']; ?> </td>
                </tr>
                <tr>
                  <td>Mother's Nationality</td>
                  <td> <?php echo $form3_row['f3_mothers_nationality']; ?> </td>
                </tr>
                <tr>
                  <td>Mother's Previous Nationality If required</td>
                  <td> <?php echo $form3_row['f3_mothers_prev_nationality']; ?> </td>
                </tr>
                <tr>
                  <td>Mother's Place of Birth</td>
                  <td> <?php echo $form3_row['f3_mothers_birth_place']; ?> </td>
                </tr>
                <tr>
                  <td>Mother's Country of Birth</td>
                  <td> <?php echo $form3_row['f3_mothers_birth_country']; ?> </td>
                </tr>

                <tr>
                  <td colspan="2"><strong>Applicant's Martial Details</strong></td>
                </tr>
                <tr>
                  <td>Applicant's Marital Status</td>
                  <td> <?php echo $form3_row['f3_martial_status']; ?> </td>
                </tr>
                <tr>
                  <td>Spouse Name</td>
                  <td> <?php echo $form3_row['f3_spouse_name']; ?> </td>
                </tr>
                <tr>
                  <td>Spouse Nationality</td>
                  <td> <?php echo $form3_row['f3_spouse_nationality']; ?> </td>
                </tr>
                <tr>
                  <td>Spouse Previous Nationality If required</td>
                  <td> <?php echo $form3_row['f3_spouse_prev_nationality']; ?> </td>
                </tr>
                <tr>
                  <td>Spouse Place of Birth</td>
                  <td> <?php echo $form3_row['f3_spouse_birth_place']; ?> </td>
                </tr>
                <tr>
                  <td>Spouse Country of Birth</td>
                  <td> <?php echo $form3_row['f3_spouse_birth_country']; ?> </td>
                </tr>
                <tr>
                  <td>Were your Grandfather/Grandmother (paternal/maternal) Pakistan National or belong to Pakistan held area?</td>
                  <td> <?php echo $form3_row['f3_grand_in_pak']; ?> </td>
                </tr>
                <tr>
                  <td>Grandfather's Pakistan Related Details </td>
                  <td> <?php echo $form3_row['f3_grand_in_pak_more']; ?> </td>
                </tr>
                <tr>
                  <td colspan="2"><strong>Profession / Occupation Details of Applicant</strong></td>
                </tr>
                <tr>
                <tr>
                  <td>Present Occupation</td>
                  <td> <?php echo $form3_row['f3_present_occupation']; ?> </td>
                </tr>
                <tr>
                  <td>Other Present Occupation</td>
                  <td> <?php echo $form3_row['f3_occupation_more']; ?> </td>
                </tr>
                <tr>
                  <td>Employer Name / Business</td>
                  <td> <?php echo $form3_row['f3_employer_business']; ?> </td>
                </tr>
                <tr>
                  <td>Designation</td>
                  <td> <?php echo $form3_row['f3_designation']; ?> </td>
                </tr>
                <tr>
                  <td>Address</td>
                  <td> <?php echo $form3_row['f3_work_address']; ?> </td>
                </tr>
                <tr>
                  <td>Phone</td>
                  <td> <?php echo $form3_row['f3_work_phone']; ?> </td>
                </tr>
                <tr>
                  <td>Past Occupation, if any</td>
                  <td> <?php echo $form3_row['f3_past_occupation']; ?> </td>
                </tr>
                <tr>
                  <td>Other Past Occupation</td>
                  <td> <?php echo $form3_row['f3_past_occupation_more']; ?> </td>
                </tr>
                <tr>
                  <td>Are/were you in a Military/Semi-Military/Police/Security. Organization?</td>
                  <td> <?php echo $form3_row['f3_military_past']; ?> </td>
                </tr>
                <tr>
                  <td>Military/Security Details</td>
                  <td> <?php echo $form3_row['f3_military_past_details']; ?> </td>
                </tr>
                <tr>
                  <td>Military/Security Organisation</td>
                  <td> <?php echo $form3_row['f3_military_organisation']; ?> </td>
                </tr>
                <tr>
                  <td>Military/Security Designation</td>
                  <td> <?php echo $form3_row['f3_military_designation']; ?> </td>
                </tr>
                <tr>
                  <td>Military/Security Rank</td>
                  <td> <?php echo $form3_row['f3_military_rank']; ?> </td>
                </tr>
                <tr>
                  <td>Military/Security Place of Posting</td>
                  <td> <?php echo $form3_row['f3_military_posting']; ?> </td>
                </tr>
              </tbody>
            </table>

            <!-- form 4 table -->
            <h5><strong>FORM 4</strong></h5>
            <table class="table table-bordered table-striped table-sm">
              <tbody>
                <tr>
                  <td colspan="2"><strong>Details of Visa Sought</strong></td>
                </tr>
                <tr>
                  <td style="width: 35%;"> Type of Visa </td>
                  <td style="width: 65%;">
                    <?php echo $form4_row['f4_visa_type']; ?>
                  </td>
                </tr>
                <tr>
                  <td>Visa Service</td>
                  <td> <?php echo $form4_row['f4_visa_subtype']; ?> </td>
                </tr>
                <tr>
                  <td>Places likely to be visited</td>
                  <td> <?php echo $form4_row['f4_places_visit']; ?> </td>
                </tr>
                <tr>
                  <td>Other Places likely to be visited</td>
                  <td> <?php echo $form4_row['f4_places_visit_more']; ?> </td>
                </tr>
                <tr>
                  <td>Have you booked any room in Hotel/Resort etc. through any Tour Operator?</td>
                  <td> <?php echo $form4_row['f4_tour_operator']; ?> </td>
                </tr>
                <tr>
                  <td>Name of the tour operator</td>
                  <td> <?php echo $form4_row['f4_operator_name']; ?> </td>
                </tr>
                <tr>
                  <td>Address of the tour operator</td>
                  <td> <?php echo $form4_row['f4_operator_address']; ?> </td>
                </tr>
                <tr>
                  <td>Name of Hotel/Resort etc</td>
                  <td> <?php echo $form4_row['f4_operator_hotel']; ?> </td>
                </tr>
                <tr>
                  <td>Place/City of Hotel/Resort etc</td>
                  <td> <?php echo $form4_row['f4_operator_place']; ?> </td>
                </tr>
                <tr class="tablerow business">
                  <td colspan="2"><strong>Details of Purpose (Business)</strong></td>
                </tr>
                <tr class="tablerow business">
                  <td>Applicants Company Name</td>
                  <td> <?php echo $form4_row['f4_company_name']; ?> </td>
                </tr>
                <tr class="tablerow business">
                  <td>Company Address/Phone</td>
                  <td> <?php echo $form4_row['f4_company_address']; ?> </td>
                </tr>
                <tr class="tablerow business">
                  <td>Company Website</td>
                  <td> <?php echo $form4_row['f4_company_website']; ?> </td>
                </tr>
                <tr class="tablerow business">
                  <td>Nature of Business/Product</td>
                  <td> <?php echo $form4_row['f4_company_business']; ?> </td>
                </tr>
                <tr class="tablerow medical">
                  <td colspan="2"><strong>Details of Purpose (Medical)</strong></td>
                </tr>
                <tr class="tablerow medical">
                  <td>Name of the Hospital</td>
                  <td> <?php echo $form4_row['f4_hospital_name']; ?> </td>
                </tr>
                <tr class="tablerow medical">
                  <td>Hospital Address</td>
                  <td> <?php echo $form4_row['f4_hospital_address']; ?> </td>
                </tr>
                <tr class="tablerow medical">
                  <td>Hospital State</td>
                  <td> <?php echo $form4_row['f4_hospital_state']; ?> </td>
                </tr>
                <tr class="tablerow medical">
                  <td>Hospital District</td>
                  <td> <?php echo $form4_row['f4_hospital_district']; ?> </td>
                </tr>
                <tr class="tablerow medical">
                  <td>Hospital Phone No.</td>
                  <td> <?php echo $form4_row['f4_hospital_phone']; ?> </td>
                </tr>
                <tr class="tablerow medical">
                  <td>Type of Medical Treatment Required</td>
                  <td> <?php echo $form4_row['f4_hospital_treatment']; ?> </td>
                </tr>
                <tr class="tablerow medical">
                  <td colspan="2"><strong>Details of Purpose (Conference)</strong></td>
                </tr>
                <tr class="tablerow conference">
                  <td>Name/Subject of Conference</td>
                  <td> <?php echo $form4_row['f4_conf_name']; ?> </td>
                </tr>
                <tr class="tablerow conference">
                  <td>Duration of Conference (Start-End Date)</td>
                  <td> <?php echo $form4_row['f4_conf_duration']; ?> </td>
                </tr>
                <tr class="tablerow conference">
                  <td>Conference Address</td>
                  <td> <?php echo $form4_row['f4_conf_address']; ?> </td>
                </tr>
                <tr class="tablerow conference">
                  <td>Conference Venue State</td>
                  <td> <?php echo $form4_row['f4_conf_state']; ?> </td>
                </tr>
                <tr class="tablerow conference">
                  <td>Conference Venue District</td>
                  <td> <?php echo $form4_row['f4_conf_district']; ?> </td>
                </tr>
                <tr class="tablerow conference">
                  <td>Conference Venue PinCode</td>
                  <td> <?php echo $form4_row['f4_conf_pincode']; ?> </td>
                </tr>
                <tr class="tablerow conference">
                  <td>Conference Organizer Name</td>
                  <td> <?php echo $form4_row['f4_conf_org_name']; ?> </td>
                </tr>
                <tr class="tablerow conference">
                  <td>Conference Organizer Address/Phone</td>
                  <td> <?php echo $form4_row['f4_conf_org_address']; ?> </td>
                </tr>
                <tr class="tablerow conference">
                  <td>Conference Organizer Email</td>
                  <td> <?php echo $form4_row['f4_conf_org_email']; ?> </td>
                </tr>

                <tr>
                  <td colspan="2"><strong>Details of Duration</strong></td>
                </tr>
                <tr>
                  <td>Expected Duration of Visa (in Days)</td>
                  <td> <?php echo $form4_row['f4_expected_duration']; ?> </td>
                </tr>
                <tr>
                  <td>Expected No. of Entries</td>
                  <td> <?php echo $form4_row['f4_expected_entries']; ?> </td>
                </tr>
                <tr>
                  <td>Port of Arrival in India</td>
                  <td> <?php echo $form4_row['f4_port_arrival']; ?> </td>
                </tr>
                <tr>
                  <td>Expected Port of Exit from India</td>
                  <td> <?php echo $form4_row['f4_port_exit']; ?> </td>
                </tr>
                <tr>
                  <td colspan="2"><strong>Previous Visa/Currently valid Visa Details</strong></td>
                </tr>
                <tr>
                  <td>Have you ever visited India before?</td>
                  <td> <?php echo $form4_row['f4_visited_india']; ?> </td>
                </tr>
                <tr>
                  <td>Address</td>
                  <td> <?php echo $form4_row['f4_visited_address']; ?> </td>
                </tr>
                <tr>
                  <td>Cities previously visited in India</td>
                  <td> <?php echo $form4_row['f4_visited_cities']; ?> </td>
                </tr>
                <tr>
                  <td>Last Indian Visa No/Currently valid Indian Visa No.</td>
                  <td> <?php echo $form4_row['f4_visited_visa_num']; ?> </td>
                </tr>
                <tr>
                  <td>Type of Visa</td>
                  <td> <?php echo $form4_row['f4_visited_visa_type']; ?> </td>
                </tr>
                <tr>
                  <td>Place of Issue</td>
                  <td> <?php echo $form4_row['f4_visited_visa_place']; ?> </td>
                </tr>
                <tr>
                  <td>Date of Issue</td>
                  <td> <?php echo $form4_row['f4_visited_visa_issue']; ?> </td>
                </tr>
                <tr>
                  <td>Has permission to visit or to extend stay in India previously been refused?</td>
                  <td> <?php echo $form4_row['f4_permission_refused']; ?> </td>
                </tr>
                <tr>
                  <td>When and By Whom?</td>
                  <td> <?php echo $form4_row['f4_permission_refused_more']; ?> </td>
                </tr>
                <tr>
                  <td colspan="2"><strong>Other Information</strong></td>
                </tr>
                <tr>
                  <td>Countries Visited in Last 10 years</td>
                  <td> <?php echo $form4_row['f4_saarc_last']; ?> </td>
                </tr>
                <tr>
                  <td>SAARC Country Visit Details</td>
                  <td> <?php echo $form4_row['f4_saarc_visited']; ?> </td>
                </tr>
                <tr>
                  <td>Name of SAARC country</td>
                  <td> <?php echo $form4_row['f4_saarc_countries']; ?> </td>
                </tr>
                <tr>
                  <td>Name of SAARC years</td>
                  <td> <?php echo $form4_row['f4_saarc_years']; ?> </td>
                </tr>
                <tr>
                  <td>Name of SAARC visits</td>
                  <td> <?php echo $form4_row['f4_saarc_visits']; ?> </td>
                </tr>

                <tr>
                  <td colspan="2"><strong>Reference</strong></td>
                </tr>
                <tr>
                  <td>Reference Name in India</td>
                  <td> <?php echo $form4_row['f4_india_ref_name']; ?> </td>
                </tr>
                <tr>
                  <td>Address</td>
                  <td> <?php echo $form4_row['f4_india_ref_address']; ?> </td>
                </tr>
                <tr>
                  <td>Phone</td>
                  <td> <?php echo $form4_row['f4_india_ref_phone']; ?> </td>
                </tr>
                <tr>
                  <td>Reference Name in your Home Country</td>
                  <td> <?php echo $form4_row['f4_home_ref_name']; ?> </td>
                </tr>
                <tr>
                  <td>Address</td>
                  <td> <?php echo $form4_row['f4_home_ref_address']; ?> </td>
                </tr>
                <tr>
                  <td>Phone</td>
                  <td> <?php echo $form4_row['f4_home_ref_phone']; ?> </td>
                </tr>

                <tr>
                  <td colspan="2"><strong>Activity Details</strong></td>
                </tr>
                <tr>
                  <td>Have you ever been arrested / prosecuted / convicted by court of law of any country?</td>
                  <td> <?php echo $form4_row['f4_crime_1']; ?> </td>
                </tr>
                <tr>
                  <td>Have you ever been refused entry / deported by any country including India?</td>
                  <td> <?php echo $form4_row['f4_crime_2']; ?> </td>
                </tr>
                <tr>
                  <td>Have you ever been engaged in human traffecking/ drug traffecking/ child abuse/ crime against women/ Economic offense / Financial fraud?</td>
                  <td> <?php echo $form4_row['f4_crime_3']; ?> </td>
                </tr>
                <tr>
                  <td>Have you ever been engaged in cyber crime/ terrorist activities/ sabotage/ espionage/ genocide/ political killing/ other act of voilence?</td>
                  <td> <?php echo $form4_row['f4_crime_4']; ?> </td>
                </tr>
                <tr>
                  <td>Have you ever by any means or medium, expressed views that justify or glorify terrorist violence or that may encourage others to terrorist acts or other serious criminal acts?</td>
                  <td> <?php echo $form4_row['f4_crime_5']; ?> </td>
                </tr>
                <tr>
                  <td>Have you sought asylum (political or otherwise)in any country?</td>
                  <td> <?php echo $form4_row['f4_crime_6']; ?> </td>
                </tr>
                <tr>
                  <td>Details for Activity</td>
                  <td> <?php echo $form4_row['f4_crime_details']; ?> </td>
                </tr>
              </tbody>
            </table>

            <!-- form 5 table -->
            <h5><strong>FORM 5</strong></h5>
            <table class="table table-bordered table-striped table-sm">
              <tbody>
                <tr>
                  <td colspan="2"><strong>Uploaded Images/Documents</strong></td>
                </tr>
                <tr>
                  <td style="width: 35%;"> PHOTO UPLOAD </td>
                  <td style="width: 65%;">
                    <?php echo (!empty($form5_row['f5_photo_upload'])) ? '<a class="btn btn-secondary btn-sm" href="../uploads/'.$form5_row["f5_photo_upload"].'" download>Download</a> <img src="../uploads/'.$form5_row["f5_photo_upload"].'" height="100" alt="image" />  ' : ''; ?>
                  </td>
                </tr>
                <tr>
                  <td>Passport pages</td>
                  <td>
                    <?php echo (!empty($form5_row['f5_passport_pages'])) ? '<a class="btn btn-secondary btn-sm" href="../uploads/'.$form5_row["f5_passport_pages"].'" download>Download</a> <img src="../uploads/'.$form5_row["f5_passport_pages"].'" height="100" alt="image" />  ' : ''; ?>
                  </td>
                </tr>
                <tr>
                  <td>Other Documents 1</td>
                  <td>
                    <?php echo (!empty($form5_row['f5_other_doc1'])) ? '<a class="btn btn-secondary btn-sm" href="../uploads/'.$form5_row["f5_other_doc1"].'" download>Download</a> Document' : ''; ?>
                  </td>
                </tr>
                <tr>
                  <td>Other Documents 2</td>
                  <td>
                    <?php echo (!empty($form5_row['f5_other_doc2'])) ? '<a class="btn btn-secondary btn-sm" href="../uploads/'.$form5_row["f5_other_doc2"].'" download>Download</a> Document' : ''; ?>
                  </td>
                </tr>
                <tr>
                  <td>Other Documents 3</td>
                  <td>
                    <?php echo (!empty($form5_row['f5_other_doc3'])) ? '<a class="btn btn-secondary btn-sm" href="../uploads/'.$form5_row["f5_other_doc3"].'" download>Download</a> Document' : ''; ?>
                  </td>
                </tr>
                <tr>
                  <td>Other Documents 4</td>
                  <td>
                    <?php echo (!empty($form5_row['f5_other_doc4'])) ? '<a class="btn btn-secondary btn-sm" href="../uploads/'.$form5_row["f5_other_doc4"].'" download>Download</a> Document' : ''; ?>
                  </td>
                </tr>
              </tbody>
            </table>

            <!-- Admin Notes -->
            <h5><strong>Notes</strong></h5>
            <table class="table table-bordered table-striped table-sm">
              <tbody>
                <tr>
                  <td style="width: 35%;"> Remarks </td>
                  <td style="width: 65%;">
                    <textarea class="form-control"><?php //echo $form1_row['dated']; ?></textarea>
                  </td>
                </tr>
                <tr>
                  <td>Status</td>
                  <td> <?php //echo $form1_row['form_type']; ?> </td>
                </tr>
              </tbody>
            </table>

          </div>

        <?php } ?>
      </div>
  <?php

/* ELSE SHOW ERROR */
} else {
  ?>
  <div class="p-3 border-bottom">
    <h3> <strong>Product not found</strong> </h3>
    <p>No Product found via given id. Please go back and try again.</p>
  </div>
  <?php

} //if else end
?>

<!-- include header -->
<?php include('inc/footer.php'); ?>