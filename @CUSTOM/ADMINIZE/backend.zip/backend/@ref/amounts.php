<!-- include header -->
<?php include('inc/header.php'); ?>

<!-- page title -->
<div class="p-3 border-bottom">
  <h3> <strong>Payments Table</strong> </h3>
  <p>All the payment values on website are listed below. Click <strong>Update</strong> to edit.</p>
</div>

<!-- content & forms -->
<div class="p-2">

  <!-- data -->
  <table class="table table-striped table-bordered">
    <thead>
      <tr>
        <th>#</th>
        <th>Payment Title</th>
        <th>Amount (USD)</th>
        <th>Updated</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $select = "SELECT * FROM amounts ORDER BY pid ASC";
      $quer = mysqli_query($conn, $select);
      while($fetch = mysqli_fetch_array($quer)){ ?>
        <tr>
          <td><?php echo $fetch['pid']; ?></td>
          <td><?php echo $fetch['payment_title']; ?></td>
          <td> <strong>$ <?php echo $fetch['payment_amount']; ?> </strong> </td>
          <td><?php echo date('d M, Y', strtotime($fetch['pdated'])); ?></td>
          <td>
            <a href="amounts-single.php?edit=<?php echo $fetch['pid']; ?>">Update</a>
          </td>
        </tr>
      <?php } ?>
    </tbody>
  </table>

</div>

<!-- include header -->
<?php include('inc/footer.php'); ?>