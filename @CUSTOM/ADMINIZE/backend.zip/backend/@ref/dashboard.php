<!-- include header -->
<?php include('inc/header.php'); ?>

<!-- page title -->
<div class="p-3 border-bottom">
  <h3> <strong>Welcome Admin</strong> </h3>
  <p>Click on <strong>Links</strong> in left sidebar to perform actions.</p>
</div>

<a class="btn btn-secondary m-3" href="applications.php">View Recent Applications</a>

<!-- include header -->
<?php include('inc/footer.php'); ?>