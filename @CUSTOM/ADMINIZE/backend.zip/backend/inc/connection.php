<?php
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'cl59-globalnew');
define('DB_PASSWORD', 'grTCY/gfm');
define('DB_DATABASE', 'cl59-globalnew');
$conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_DATABASE)
or die("Connection error: " . mysqli_connect_error());
?>