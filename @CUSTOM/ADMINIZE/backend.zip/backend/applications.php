<!-- include header -->
<?php include('inc/header.php'); ?>

<!-- page title -->
<div class="p-3 border-bottom">
  <h3> <strong>Applications</strong> </h3>
  <p>Listings all user submitted applications. Click <strong>View</strong> to view whole info. Showing latest 30 entries per page.</p>
</div>

<!-- content & forms -->
<div class="p-2">

  <!-- filter query -->
  <form class="mb-3" action="" method="get">
    <div class="row">
      <div class="col-6">
        <strong> Search Applications: </strong>
        <div class="input-group mb-3">
          <input type="text" class="form-control" name="search" id="search" placeholder="form-id or email">
          <div class="input-group-append">
            <button class="btn btn-secondary" type="submit" id="button-addon2">Search</button>
          </div>
        </div>
      </div>
      <div class="col-3 ml-auto">
        <strong> Filter Applications: </strong>
        <div class="input-group mb-3">
          <select class="form-control" name="filter_slt" id="">
            <option value="">Select</option>
            <option value="completed">Complete</option>
            <option value="partial">Partial</option>
          </select>
          <div class="input-group-append">
            <button class="btn btn-secondary" type="submit" id="button-addon2">Filter</button>
          </div>
        </div>
      </div>
    </div>
  </form>
  <?php
  //search query filter
  $query_filter = '';
  if ( isset($_GET["filter_slt"]) || isset($_GET["search"])  ) {
    if( !empty($_GET["filter_slt"]) && !empty($_GET["search"]) ){
      $filter_slt = $_GET["filter_slt"];
      $search = $_GET["search"];
      $query_filter .= " WHERE form5_status = '".$filter_slt."' ";
      $query_filter .= " AND ( form_id LIKE '%".$search."%' OR user_email LIKE '%".$search."%' )";
      echo "<h5>Searching Entries including <strong>'$search'</strong> with <strong>'$filter_slt'</strong> status.</h5>";
    } elseif( !empty($_GET["search"]) ){
      $search = $_GET["search"];
      $query_filter .= " WHERE form5_status = 'completed' ";
      $query_filter .= " AND ( form_id LIKE '%".$search."%' OR user_email LIKE '%".$search."%' )";
      echo "<h5>Searching Entries including <strong>'$search'</strong>.</h5>";
    } elseif( !empty($_GET["filter_slt"]) ){
      $filter_slt = $_GET["filter_slt"];
      $query_filter .= " WHERE form5_status = '".$filter_slt."' ";
      echo "<h5>Showing Entries with <strong>'$filter_slt'</strong> status.</h5>";
    } else {
      echo "<h5>Showing all complete applications.</h5>";
    }
  } else {
    $query_filter .= " WHERE form5_status = 'completed' ";
    echo "<h5>Showing all Applications.</h5>";
  }
  ?>

  <!-- data -->
  <table class="table table-striped table-bordered mt-4">
    <thead>
      <tr>
        <th>Application</th>
        <th>Email</th>
        <th>Forms</th>
        <th>Payment</th>
        <th>Comments</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php
      //pagination part 1
      $items_per_page = 30;
      if (isset($_GET["pagex"])) {
        $pagex = $_GET["pagex"];
      } else {
        $pagex = 1;
      }
      $start_from = ($pagex - 1) * $items_per_page;

      // query
      $select = "SELECT * FROM formdata_main ".$query_filter." ORDER BY form_id DESC LIMIT $items_per_page OFFSET $start_from";
      $quer = mysqli_query($conn, $select);
      while($fetch = mysqli_fetch_array($quer)){
        $form_id = $fetch['form_id'];
        $pass_sql = "SELECT f2_passport_num FROM formdata_form2 WHERE form_id = '$form_id' ";
        $pass_query = mysqli_query($conn, $pass_sql);
        $pass_result = mysqli_fetch_assoc($pass_query);
        $pass_num = $pass_result['f2_passport_num'];
        $forms_status = 'pending';
        if( ($fetch['form1_status']=='completed') && ($fetch['form2_status']=='completed') && ($fetch['form3_status']=='completed') && ($fetch['form4_status']=='completed') && ($fetch['form5_status']=='completed') ){
          $forms_status = 'completed';
        }
        ?>
        <tr>
          <td>
            <?php echo $form_id; ?><br />
            <small class="text-muted">Passport: <?php echo $pass_num; ?></small>
          </td>
          <td><?php echo $fetch['user_email']; ?></td>
          <td>
            <?php echo $forms_status; ?>
          </td>
          <td><?php echo $fetch['payment_status']; ?></td>
          <td><?php echo $fetch['comments']; ?></td>
          <td class="quad-btns">
            <a class="btn btn-primary btn-sm" href="applications-single.php?view=<?php echo $fetch['form_id']; ?>">View</a>
            <a class="btn btn-primary btn-sm" href="applications-single.php?edit=<?php echo $fetch['form_id']; ?>">Edit</a>
            <a class="btn btn-secondary btn-sm" href="applications-single.php?view=<?php echo $fetch['form_id']; ?>">Print</a>
            <a class="btn btn-danger btn-sm" href="applications-single.php?del=<?php echo $fetch['form_id']; ?>">Delete</a>
          </td>
        </tr>
      <?php } ?>
    </tbody>
  </table>

  <!-- pagination 2 -->
  <?php echo "<p><strong> Page: ".$pagex. "</strong> </p>"; ?>
  <nav aria-label="Page navigation example">
    <ul class="pagination">
      <?php
        //pagination part 2
        $sql = "SELECT COUNT(form_id) AS countx FROM formdata_main ".$query_filter." ";
        $stmt          = mysqli_query($conn, $sql);
        $lastid_data   = mysqli_fetch_array($stmt);
        $total_records = $lastid_data['countx'] ;
        $total_pages   = ceil($total_records / $items_per_page);

        //for first page
        $new_data = array("pagex" => "1");
        $full_data = array_merge($_GET, $new_data);
        $url = http_build_query($full_data);
        echo '<li class="page-item"><a class="page-link" href="?'.$url.'">First</a></li>';

        //for each page
        if( $total_pages > 10 ){
          $i = $pagex;
          $min_pages = $i + 10 ;
          if( $min_pages >= $total_pages ){
            $i = $total_pages - 10;
            $min_pages = $i + 10 ;
          }
          for ( $i; $i <= $min_pages; $i++) {
            $new_data = array( "pagex" => $i );
            $full_data = array_merge($_GET, $new_data);
            $url = http_build_query($full_data);
            if( $pagex == $i ){
              echo '<li class="page-item active"><a class="page-link" href="?'.$url.'">'.$i.'</a></li>';
            } else {
              echo '<li class="page-item"><a class="page-link" href="?'.$url.'">'.$i.'</a></li>';
            }
          }

          //dots to next page
          if( ! ($min_pages >= $total_pages-10) ){
            $new_data = array( "pagex" => $min_pages+1 );
            $full_data = array_merge($_GET, $new_data);
            $url = http_build_query($full_data);
            echo "<a href=?$url> ... </a> ";
          }
        } else {
          for ( $i=1; $i <= $total_pages; $i++) {
            $new_data = array( "pagex" => $i );
            $full_data = array_merge($_GET, $new_data);
            $url = http_build_query($full_data);
            if( $pagex == $i ){
              echo '<li class="page-item active"><a class="page-link" href="?'.$url.'">'.$i.'</a></li>';
            } else {
              echo '<li class="page-item"><a class="page-link" href="?'.$url.'">'.$i.'</a></li>';
            }
          }
        }

        //last page
        $new_data = array("pagex" => $total_pages);
        $full_data = array_merge($_GET, $new_data);
        $url = http_build_query($full_data);
        echo '<li class="page-item"><a class="page-link" href="?'.$url.'">Last</a></li>';
      ?>
    </ul>
  </nav>

</div>

<!-- include header -->
<?php include('inc/footer.php'); ?>