<?php include('inc/header.php'); ?>

<!-- page title -->
<div class="p-3 border-bottom">
  <h3> <strong>Add New Product</strong> </h3>
  <p>New Data registration form.</p>
</div>

<!-- operation & response -->
<div class="text-center h5 p-3">
  <?php
    if( isset($_POST['add_product']) ){
      // print_r($_FILES);

      //required
      $proName         = mysqli_real_escape_string($conn, $_POST['proName']);
      $proCode         = mysqli_real_escape_string($conn, $_POST['proCode']);
      $proCatalogue    = mysqli_real_escape_string($conn, $_POST['proCatalogue']);
      $proChemical     = mysqli_real_escape_string($conn, $_POST['proChemical']);

      //optional
      $proSynonyms     = mysqli_real_escape_string($conn, $_POST['proSynonyms']);
      $proImpurity     = mysqli_real_escape_string($conn, $_POST['proImpurity']);
      $proCasnum       = mysqli_real_escape_string($conn, $_POST['proCasnum']);
      $proCasnumAlt    = mysqli_real_escape_string($conn, $_POST['proCasnumAlt']);
      $proMolecular    = mysqli_real_escape_string($conn, $_POST['proMolecular']);
      $proAppearance   = mysqli_real_escape_string($conn, $_POST['proAppearance']);
      $proMelting      = mysqli_real_escape_string($conn, $_POST['proMelting']);
      $proMolweight    = mysqli_real_escape_string($conn, $_POST['proMolweight']);
      $proStorage      = mysqli_real_escape_string($conn, $_POST['proStorage']);
      $proSolubility   = mysqli_real_escape_string($conn, $_POST['proSolubility']);
      $proStability    = mysqli_real_escape_string($conn, $_POST['proStability']);
      $proCategory     = mysqli_real_escape_string($conn, $_POST['proCategory']);
      $proBoiling      = mysqli_real_escape_string($conn, $_POST['proBoiling']);
      $proApplications = mysqli_real_escape_string($conn, $_POST['proApplications']);
      $proDangerous    = mysqli_real_escape_string($conn, $_POST['proDangerous']);
      $proReferences   = mysqli_real_escape_string($conn, $_POST['proReferences']);
      $proKeywords     = mysqli_real_escape_string($conn, $_POST['proKeywords']);
      $proExtraNotes   = mysqli_real_escape_string($conn, $_POST['proExtraNotes']);

      //process permalink
      $plink          = mysqli_real_escape_string($conn, $_POST['plink']);
      $permalink_temp = str_replace(' ', '-', $plink);
      $permalink_temp = preg_replace('/[^A-Za-z0-9\-]/', '', $permalink_temp);
      $permalink_temp = preg_replace('/-+/', '-', $permalink_temp);
      $plink = strtolower($permalink_temp);

      //packs
      $proProductPacks = '';
      for ($i=1; $i<11; $i++) {
        if( isset($_POST['proPack'.$i]) && !empty($_POST['proPack'.$i]) ){
          $proProductPacks .= mysqli_real_escape_string($conn, $_POST['proPack'.$i]) .";";
        }
      }

      if( empty($proName) || empty($proCode) || empty($proCatalogue) || empty($proChemical) ){
        echo "<strong>ERROR: Required fields Empty or Invalid. Please try again.</strong>";
        // exit;
      } else {
        // check if data existing
        $checkexisting = "SELECT * FROM products WHERE proCode = '$proCode' ";
        $checkque = mysqli_query($conn, $checkexisting);
        if(mysqli_num_rows($checkque) > 0){
          echo "<strong>ERROR: Product with same code already exists.</strong>";
        } else {

          //files
          $proImage = $proDocument = '';
          $fileserr1 = $fileserr2 = 0;
          // $uniqd = round(microtime(true));
          $uniqd = $proCode;

          //file1
          if( ($_FILES['proImage']['size'] == 0) ){
            $proImage = '';
            $fileserr1 = 0;
          } else if( $_FILES['proImage']['size'] > (2*1024*1024) ) {
            $fileserr1 = 1;
          } else {
            $temp1        = explode(".", $_FILES["proImage"]["name"]);
            $newfilename1 = $uniqd . '_proImage' . '.' . end($temp1);
            $imagetmp1    = trim($_FILES['proImage']['tmp_name']);
            $path1        = "uploads/".$newfilename1;
            move_uploaded_file($imagetmp1, $path1);
            $proImage = $newfilename1;
            $fileserr1 = 0;
          }
          //file2
          if( ($_FILES['proDocument']['size'] == 0) ){
            $proDocument = '';
            $fileserr2 = 0;
          } else if( $_FILES['proDocument']['size'] > (2*1024*1024) ) {
            $fileserr2 = 1;
          } else {
            $temp2        = explode(".", $_FILES["proDocument"]["name"]);
            $newfilename2 = $uniqd . '_proDocument' . '.' . end($temp2);
            $imagetmp2    = trim($_FILES['proDocument']['tmp_name']);
            $path2        = "uploads/".$newfilename2;
            move_uploaded_file($imagetmp2, $path2);
            $proDocument = $newfilename2;
            $fileserr2 = 0;
          }

          //no files error
          if( $fileserr1 == 1 || $fileserr2 == 1 ){
            echo "<strong>FAILED: Error in uploading Files. Max Size Allowed: 2 MB each.</strong>";
          } else {
            // add data to db
            $insert = "INSERT INTO products( plink, proName, proCode, proCatalogue, proChemical, proSynonyms, proImpurity, proCasnum, proCasnumAlt, proMolecular, proAppearance, proMelting, proMolweight, proStorage, proSolubility, proStability, proCategory, proBoiling, proApplications, proDangerous, proReferences, proKeywords, proExtraNotes, proImage, proDocument, proProductPacks) VALUES ('$plink', '$proName', '$proCode', '$proCatalogue', '$proChemical', '$proSynonyms', '$proImpurity', '$proCasnum', '$proCasnumAlt', '$proMolecular', '$proAppearance', '$proMelting', '$proMolweight', '$proStorage', '$proSolubility', '$proStability', '$proCategory', '$proBoiling', '$proApplications', '$proDangerous', '$proReferences', '$proKeywords', '$proExtraNotes', '$proImage', '$proDocument', '$proProductPacks' )";
            $que = mysqli_query($conn, $insert);
            if($que){
              echo "<strong class='text-success'>SUCCESS: New Product Added Successfully.";
            } else {
              echo "<strong class='text-danger'>ERROR: Product not Added. Please try again later.</strong><br>";
              print_r( mysqli_error($conn) );
            }
          }

        }
      }
    }
  ?>
</div>

<!-- content & forms -->
<div class="row p-2">
  <div class="col-md-12 col-lg-12">
    <div class="form-box">

      <form class="file-form" enctype="multipart/form-data" method="post" action="">
        <table class="table table-borderless">
          <tbody>
            <tr>
              <td style="width: 20%;"> Product Name </td>
              <td style="width: 60%;">
                <input type="text" class="form-control" name="proName" required placeholder="name" id="productname">
              </td>
              <td style="width: 20%;">
                <small>Click to Generate Manually</small>
              </td>
            </tr>
            <tr>
              <td> Generate Code </td>
              <td>
                <?php
                  $lastid_sql   = "SELECT pid FROM products ORDER BY pid DESC LIMIT 1";
                  $lastid_query = mysqli_query($conn, $lastid_sql);
                  $lastid_data  = mysqli_fetch_array($lastid_query);
                  $lastid_plus = '0000' . ($lastid_data['pid'] + 1);
                ?>
                <input type="text" class="form-control" name="proCode" required readonly placeholder="Autogenerated by Name" id="productcode" data-last="<?php echo $lastid_plus; ?>">
              </td>
              <td>
                <button type="button" class="btn btn-dark" id="gencode">EDIT</button>
              </td>
            </tr>
            <tr>
              <td> Product Permalink </td>
              <td>
                <input type="text" class="form-control" name="plink" placeholder="autoformatted">
              </td>
            </tr>
            <tr>
              <td> Catalogue number </td>
              <td>
                <input type="text" class="form-control" name="proCatalogue" required placeholder="number">
              </td>
            </tr>
            <tr>
              <td> Chemical name </td>
              <td>
                <input type="text" class="form-control" name="proChemical" required placeholder="number">
              </td>
            </tr>
            <tr>
              <td> Synonyms </td>
              <td>
                <textarea class="form-control" name="proSynonyms" placeholder="comma seprated"></textarea>
              </td>
            </tr>
            <tr>
              <td>Impurity </td>
              <td>
                <input type="text" class="form-control" name="proImpurity" placeholder="impurities">
              </td>
            </tr>
            <tr>
              <td> CAS Number </td>
              <td>
                <input type="text" class="form-control" name="proCasnum" placeholder="000-000">
              </td>
            </tr>
            <tr>
              <td> Alternate CAS # </td>
              <td>
                <input type="text" class="form-control" name="proCasnumAlt" placeholder="000-000">
              </td>
            </tr>
            <tr>
              <td> Molecular form </td>
              <td>
                <input type="text" class="form-control" name="proMolecular" placeholder="H₂O">
              </td>
            </tr>
            <tr>
              <td> Appearance </td>
              <td>
                <input type="text" class="form-control" name="proAppearance" placeholder="colors">
              </td>
            </tr>
            <tr>
              <td> Melting Point </td>
              <td>
                <input type="text" class="form-control" name="proMelting" placeholder="XX°C">
              </td>
            </tr>
            <tr>
              <td> Mol. Weight </td>
              <td>
                <input type="text" class="form-control" name="proMolweight" placeholder="00.00">
              </td>
            </tr>
            <tr>
              <td> Storage </td>
              <td>
                <input type="text" class="form-control" name="proStorage" placeholder="freezer">
              </td>
            </tr>
            <tr>
              <td> Solubility </td>
              <td>
                <input type="text" class="form-control" name="proSolubility" placeholder="slighty">
              </td>
            </tr>
            <tr>
              <td> Stability </td>
              <td>
                <input type="text" class="form-control" name="proStability" placeholder="stablity">
              </td>
            </tr>
            <tr>
              <td> Category </td>
              <td>
                <input type="text" class="form-control" name="proCategory" placeholder="Category">
              </td>
            </tr>
            <tr>
              <td> Boiling Point </td>
              <td>
                <input type="text" class="form-control" name="proBoiling" placeholder="XX°C">
              </td>
            </tr>
            <tr>
              <td> Applications </td>
              <td>
                <textarea class="form-control" name="proApplications" placeholder="all applications"></textarea>
              </td>
            </tr>
            <tr>
              <td> Dangerous Goods Info </td>
              <td>
                <input type="text" class="form-control" name="proDangerous" placeholder="if any">
              </td>
            </tr>
            <tr>
              <td> References </td>
              <td>
                <textarea class="form-control" name="proReferences" placeholder="all references"></textarea>
              </td>
            </tr>
            <tr>
              <td> Keywords </td>
              <td>
                <textarea class="form-control" name="proKeywords" placeholder="comma seprated"></textarea>
              </td>
            </tr>
            <tr>
              <td> Extra Notes </td>
              <td>
                <textarea class="form-control" name="proExtraNotes" placeholder="if any"></textarea>
              </td>
            </tr>

            <tr>
              <td> Upload Image <br>(Picture) </td>
              <td>
                <input type="file" class="form-control-file" name="proImage" accept="image/*">
                <small>image only</small>
              </td>
            </tr>
            <tr>
              <td> Upload Document <br>(MSDS) </td>
              <td>
                <input type="file" class="form-control-file" name="proDocument" accept="application/pdf, application/doc, application/docx">
                <small>pdf, doc, docx</small>
              </td>
            </tr>
            <tr>
              <td> Product Packings </td>
              <td id="packbox">
                <input type="text" class="form-control" name="proPack1" placeholder="00mg (1)" data-pack="1">
              </td>
              <td>
                <button type="button" class="btn btn-dark" id="addpack">Add Packing</button>
              </td>
            </tr>
            <tr>
              <td colspan="2" class="text-center py-4">
                <input type="submit" class="btn btn-primary" name="add_product" value="Submit">
              </td>
            </tr>
          </tbody>
        </table>
      </form>

    </div>
  </div>
</div>

<!-- include header -->
<?php include('inc/footer.php'); ?>