<?php include('inc/header.php'); ?>

<!-- page title -->
<div class="p-3 border-bottom">
  <h3> <strong>User Entries</strong> </h3>
  <p>Click <strong>View</strong> to edit/view the user entered values. <strong>Sorted by Date Descending.</strong> </p>
</div>

<!-- content & forms -->
<div class="p-2">
  <!-- pagination -->
  <?php
    // initilize variables
    $items_per_page = 100;
    if (isset($_GET["pagex"])) {
      $pagex = $_GET["pagex"];
    } else {
      $pagex = 1;
    }
    $start_from = ($pagex - 1) * $items_per_page;
    $sql = "SELECT COUNT(pid) AS countx FROM products";
    $stmt = mysqli_query($conn, $sql);
    $stmt_data = mysqli_fetch_array($stmt);
    $total_records = $stmt_data['countx'] ;
    $total_pages = ceil($total_records / $items_per_page);

    // display pages
    function pages_display(){
      // grab outside vars
      global $pagex;
      global $total_pages;

      //for first page
      $new_data = array("pagex" => "1");
      $full_data = array_merge($_GET, $new_data);
      $url = http_build_query($full_data);
      echo '<li class="page-item"><a class="page-link" href="?'.$url.'">First</a></li>';

      //for each page
      if( $total_pages > 10 ){
        $i = $pagex;
        $min_pages = $i + 10 ;
        if( $min_pages >= $total_pages ){
          $i = $total_pages - 10;
          $min_pages = $i + 10 ;
        }
        for ( $i; $i <= $min_pages; $i++) {
          $new_data = array( "pagex" => $i );
          $full_data = array_merge($_GET, $new_data);
          $url = http_build_query($full_data);
          if( $pagex == $i ){
            echo '<li class="page-item active"><a class="page-link" href="?'.$url.'">'.$i.'</a></li>';
          } else {
            echo '<li class="page-item"><a class="page-link" href="?'.$url.'">'.$i.'</a></li>';
          }
        }

        //dots to next page
        if( ! ($min_pages >= $total_pages-10) ){
          $new_data = array( "pagex" => $min_pages+1 );
          $full_data = array_merge($_GET, $new_data);
          $url = http_build_query($full_data);
          echo "<a href=?$url> ... </a> ";
        }
      } else {
        for ( $i=1; $i <= $total_pages; $i++) {
          $new_data = array( "pagex" => $i );
          $full_data = array_merge($_GET, $new_data);
          $url = http_build_query($full_data);
          if( $pagex == $i ){
            echo '<li class="page-item active"><a class="page-link" href="?'.$url.'">'.$i.'</a></li>';
          } else {
            echo '<li class="page-item"><a class="page-link" href="?'.$url.'">'.$i.'</a></li>';
          }
        }
      }

      //last page
      $new_data = array("pagex" => $total_pages);
      $full_data = array_merge($_GET, $new_data);
      $url = http_build_query($full_data);
      echo '<li class="page-item"><a class="page-link" href="?'.$url.'">Last</a></li>';
    }
  ?>

  <!-- pages 1 -->
  <p><strong> Page: <?php echo $pagex; ?> of <?php echo $total_pages; ?></strong> </p>
  <nav class="mb-4" aria-label="Page Navigation">
    <ul class="pagination">
      <?php pages_display(); ?>
    </ul>
  </nav>

  <!-- data -->
  <table class="table table-striped table-bordered">
    <thead>
      <tr>
        <th>Code</th>
        <th>Name</th>
        <th>Catalogue</th>
        <th>Date</th>
        <th>Picture</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php
          $select = "SELECT * FROM products ORDER BY pdate DESC LIMIT $items_per_page OFFSET $start_from";
          $quer = mysqli_query($conn, $select);
          while($fetch = mysqli_fetch_array($quer)){
            $pic = $fetch['proImage'];
            $datef = date('d M, Y', strtotime($fetch['pdate']));
          ?>
          <tr>
            <td><?php echo $fetch['proCode']; ?></td>
            <td>
              <?php echo $fetch['proName']; ?> <br>
              <?php if( !empty($fetch['plink']) ) { ?>
                <small> <a href="../products/<?php echo $fetch['plink']; ?>" target="_blank">View on Permalink</a> </small>
              <?php } ?>
            </td>
            <td><?php echo $fetch['proCatalogue']; ?></td>
            <td><?php echo $datef; ?></td>
            <td><img src="<?php echo 'uploads/'.$pic; ?>" height="60" /></td>
            <td>
            <a class="btn btn-dark btn-sm w-100 mb-1" href="products-single.php?view=<?php echo $fetch['pid']; ?>">View/Edit</a><br>
            <a class="btn btn-danger btn-sm w-100" href="products-single.php?del=<?php echo $fetch['pid']; ?>">Delete</a>
            </td>
          </tr>
      <?php } ?>
    </tbody>
  </table>

  <!-- pages 2 -->
  <p><strong> Page: <?php echo $pagex; ?> of <?php echo $total_pages; ?></strong> </p>
  <nav class="mb-4" aria-label="Page Navigation">
    <ul class="pagination">
      <?php pages_display(); ?>
    </ul>
  </nav>

</div>

<!-- include header -->
<?php include('inc/footer.php'); ?>