<?php
// error_reporting(0);
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'srdpharm_user');
define('DB_PASSWORD', '6h#BRxaAguP5');
define('DB_DATABASE', 'srdpharm_customdb');
$conn = @mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_DATABASE)
or die("Connection error: cant connect to Database.");
// or die("Connection error: " . mysqli_connect_error());
