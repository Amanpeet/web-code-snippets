-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 17, 2022 at 09:41 PM
-- Server version: 5.7.36
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `srdpharm_customdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `bid` int(11) NOT NULL,
  `blog_title` text NOT NULL,
  `blog_permalink` text NOT NULL,
  `blog_image` varchar(400) NOT NULL,
  `blog_content` text NOT NULL,
  `blog_excerpt` text NOT NULL,
  `blog_keywords` text NOT NULL,
  `blog_date` varchar(100) NOT NULL,
  `dated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`bid`, `blog_title`, `blog_permalink`, `blog_image`, `blog_content`, `blog_excerpt`, `blog_keywords`, `blog_date`, `dated`) VALUES
(4, 'Know your Drinking Water Quality by Water Testing at Lab', 'know-your-drinking-water-quality-by-water-testing-at-lab', 'blog_1604511127.jpg', '<p> On a regular day, when you pour yourself a glass of water to drink, it may seem clean and taste fine but that doesnâ€™t mean you can expect it to be safe to drink. Most of the water sources that we reckon as safe may contain dissolved minerals, organic compounds or even live organisms in them and that too at harmful concentrations. Consumption of contaminated water for cooking or any other purpose can be harmful to your health. High concentrations of some specific minerals in water can result in unpleasant taste and odour.  It is recommended that you get your water quality checked if you havenâ€™t yet. </p>\r\n\r\n<p> There are multiple factors that can affect the quality of your drinking water. But the ones that need to be checked are- </p>\r\n<ul>\r\n  <li> <strong>Total coliform bacteria present in water:</strong> This is a test that indicates if the water has been contaminated with human or animal waste. If the water is found positive for this test then it is not healthy for consumption. Though, it can be made safe to consume if it is disinfected by any means.</li>\r\n  <li> <strong>Nitrate content in water:</strong> Drinking water supply that contains high concentration of nitrate can be fatal to humans. This contamination may occur near fertilized fields and farms or water sources close to factories.</li>\r\n  <li> <strong>The pH level of water:</strong> It is recommended that pH level of drinking water should be between 6.5 and 8.5. Water with pH below 6.5 can be harmful to your health.</li>\r\n  <li> <strong>Hardness of water:</strong> Drinking water with higher concentrations of magnesium and calcium is referred to as â€œHardâ€.  Although hard water is not affect health much but it is advised that drinking water should test below 150 mg/l hardness.</li>\r\n</ul>\r\n<p> Above mentioned are few factors that you must get checked. There are a lot more tests that can be done but analysing them can often be expensive and avoidable. </p>\r\n\r\n<h4>What should i do if my drinking water test indicates a problem?</h4>\r\n<p> There are possibilities that your drinking water test indicates a problem. In such a case, your health may be affected and you may be at risk of unpleasant health. Now, what is that you could do to if your water is harmful? A few things that can be done are- </p> \r\n<ul>\r\n  <li> Use bottled water. </li>\r\n  <li> Get an appropriate water treatment system installed. </li>\r\n  <li> Try to locate and eliminate the source that is responsible for the contamination of your water. </li>\r\n  <li> If possible, connect with a public water system (if available) </li>\r\n</ul>\r\n\r\n<p> Testing your drinking water is a critical step that everybody must follow. There are multiple testing labs where you can get your water checked. We at <strong>SRD Pharma</strong> also provide services like <a href=\"https://www.srdpharma.com/services.php\" target=\"_blank\"><strong>water testing</strong></a>. We can help you safeguard your water against environmental and health risks. People willing to ensure if their water is safe for drinking or not can contact us through our website. Our team will be more than happy to help you and give you the best advice. </p>\r\n', 'Water Testing will Help you to ensure that your Drinking water is safe and healthy;  Also, find multiple factors that can affect the quality of your drinking water.', 'Water Testing, Water Testing Lab, Drinking Water Test, Water ph Test, Types of water testing, Drinking water treatment, Water testing lab near me', '07/07/2021', '2020-11-04 23:02:07'),
(5, 'Why Food and Water Testing is Important?', 'why-food-and-water-testing-is-important', 'blog_1604686858.jpg', '<p>\r\n  Present day food industry requires testing and testing is very a crucial step that must be followed strictly to provide superior quality food and not to harm public health in any way. Food testing is an important part of reliable production of harmless and valuable food products. Food adulteration is a problem that our society is facing nowadays. To overcome this problem, testing food quality is of utmost importance. Testing water is equally important as water quality is crucial to many different industries and activities. <strong>SRD Pharma</strong> is trusted <strong><a href=\"https://www.srdpharma.com/about-us.php\" target=\"_blank\">chemicals manufacturer and supplier</a> </strong> that also analyses the health of food and water and carry out regular tests to check and maintain the quality of water and food. These tests are necessary in order to ensure that the water source is safe for consumption by humans as well as animals.\r\n</p>\r\n\r\n<p>\r\n  There are a lot of challenges faced by the food industry. These can vary from contaminants to genetically modified microorganisms. Food quality is the most important factor behind the grown and development of a food company. <a href=\"https://www.srdpharma.com/services.php\" target=\"_blank\"><strong>Food testing</strong></a> is a way to ensure that you are providing superior quality food. Testing can be done in many ways but testing at the source makes the process more affordable and is also time efficient.\r\n</p>\r\n\r\n<h4>Types of Food Tests</h4>\r\n<ol>\r\n  <li><strong>Organic Food Testing: </strong>The main feature of organically grown food is that it should be chemical free. Moreover, it should be grown without using any artificial fertilizers and pesticides. The organic food testing is done in order to find out if there is any presence of these pesticides and fertilizers.</li>\r\n  <li><strong>Pesticide Residue Analysis: </strong>Pesticide residue analysis tests help in identifying the residues of pesticides which are generally used to kill insects and increase crop production.</li>\r\n  <li><strong>Gluten-Free Food Test: </strong>There are people who are gluten intolerant and who only consume gluten free food. These food items must be tested to check if there is gluten present in food.</li>\r\n  <li><strong>Dairy Products Testing: </strong>These tests are done on dairy products to to determine ash, dispensability, fat, alkalinity, lactose, non â€“ fatty substances, minerals, etc.</li>\r\n</ol>\r\n\r\n<h4>Types of Water Tests</h4>\r\n<p>Some of the tests that are done on water to determine its quality are mentioned below:</p>\r\n<ul>\r\n  <li><strong>Tests to determine Nitrate level: </strong>High nitrate content in a drinking water supply can be fatal to humans and that is the reason why it is required to be tested.</li>\r\n  <li><strong>Tests to check the pH level of water: </strong>It is advised that pH level of drinking water must be between 6.5 and 8.5. Water with pH below 6.5 is can be dangerous and should not be consumed.</li>\r\n  <li><strong>Tests to check the magnesium and calcium content: </strong>The term â€œHard Waterâ€ is used for the water that has high content of magnesium and calcium. These tests are run to find out their content.</li>\r\n</ul>\r\n<p>\r\n  The quality of the food and water you consume has a direct impact on your health and thatâ€™s why it is recommended that Food and water must be tested.\r\n</p>', 'SRD Pharma provides various Types of Water Test and Food Test; Food and Water testing is Important because it Impacts Direct on our Health. ', 'Food testing, Water Testing, Types of Water Tests, How to check ph level of water, Water testing services, Types of food tests, Types of drinking water tests, Organic food testing laboratories', '08/08/2021', '2020-11-06 23:50:57'),
(6, 'Why Testing of Follow-up Formula & Complementary Foods is Needed?', 'why-testing-of-follow-up-formula-complementary-foods-is-needed', 'blog_1604859035.jpg', '<p>Follow-up Formula â€“ Complementary Foods are intended for infants and children preferably below the age of 2 years. Follow-up Formula Complementary Foods-IS 15757: 2007 has also been mentioned in the list of mandatory ISI Certification Scheme which implies that the product has to be tested in a laboratory.  At <strong>SRD Pharma</strong>, we provide services that include testing of Follow-up Formula Complementary Foods. The testing must be done based on the required parameters which will ensure that your product is in compliance with the Indian Standard. </p>\r\n\r\n<h4>Follow-up Formula â€“ Complementary foods must be approved in a recognized lab. Why?</h4>\r\n<p>As we know, Follow-up Formula â€“ Complementary Foods are meant to be consumed by infants. Follow-up Formula Complementary Foods cannot be sold in India without the ISI mark. This certification is required for approval of the formulation and overall quality of the product.</p>\r\n<p>The term <strong>â€œfollow-up formulaâ€</strong> is defined as a food that is meant to use as a liquid part of the weaning diet for infants and young children. These have to be tested and some important testing specifications have been mentioned below:</p>\r\n<ul>\r\n 	<li>The follow-up formula has to be tested for scorched particles.</li>\r\n 	<li>Tests to make sure that the product is free of additives like starch and artificial flavors, etc.</li>\r\n 	<li>Sensory testing for odor and taste.</li>\r\n 	<li>Some microbiological tests to check the bacterial count.</li>\r\n 	<li>Heavy Metal testing for lead, arsenic, tin and cadmium must be done every month.</li>\r\n 	<li>To check if the requirements of essential Vitamins, Phosphorous, Zinc, Iodine, Copper, etc. are being met. This has to be tested once every year.</li>\r\n</ul>\r\n<p>Follow-up Formula â€“ Complementary Foods requires a lot of tests to check the nutrients and their availability for healthy growth of children. Tests to check the content of vitamin A and C, iron, magnesium and calcium must be done once a month. In a scenario where tests indicate that nutrient content is not as per standards, then the product will be ISI marked. All the deficiencies must be reprocessed for the product to be ISI marked. Some of the tests are also conducted to check if permitted essential amino acids are present in the Follow-up formula or not.</p>\r\n\r\n<p>Testing of these products ensure that certain parameters are followed strictly. Some of these are mentioned below.</p>\r\n<ul>\r\n 	<li>Moisture content</li>\r\n 	<li>Total ash</li>\r\n 	<li>Protein content</li>\r\n 	<li>Total Fat</li>\r\n 	<li>Total milk protein</li>\r\n 	<li>Acid insoluble ash</li>\r\n 	<li>Linoleic acid</li>\r\n 	<li>Solubility</li>\r\n</ul>\r\n\r\n<h4>Reasons Why Testing Follow-up Formula â€“ Complementary foods is crucial</h4>\r\n<p>These tests for Follow-up formula â€“ Complementary Foods are essential to check if the content of micro-nutrients such as iron, zinc, vitamins, etc. is adequate for good growth and development of children at such an early stage of their life. One of the most important reasons to test these products is to prevent malnutrition in kids. <a href=\"https://www.srdpharma.com/services.php\" target=\"_blank\"><strong>Microbiological testing</strong></a> is also of utmost importance as during such as an early phase children often get affected with stomach infections like diarrhea and any type of contamination in follow-up formulas could aggravate the problem of these types of illnesses.</p>', 'Test of Follow-up Formula & Complementary Foods are essential to check the content of micro-nutrients; Also it is Important to prevent malnutrition in kids.', 'Complementary feeding, Baby food, Nutrients in food, Infants food, Complementary food for baby, Type of nutrients, Follow-up Formula Complementary Foods, Microbiological Testing', '09/09/2021', '2020-11-08 23:40:35'),
(7, 'How to choose the right Chemical and Pharmaceutical Supplier?', 'how-to-choose-the-right-chemical-and-pharmaceutical-supplier', 'blog_1634885598.jpg', '<p>Through improved understanding and the capacity to alter chemical molecules, study of chemical applications has made important contributions to the progress of human civilization. The chemical industry is built on modern science and capital incentives. To build a strong brand, every chemical firm must verify a few key points with the manufacturer and distributor of the same items. The company\'s performance is dependent on finding a realistic contract that meets the needs of both pharmaceutical and chemical product supply.</p>\r\n\r\n<p>The chemical industry is made up of a diverse range of businesses. This condition might be advantageous to customers since it indicates that there are several providers striving to deliver the finest product. However, this also makes selecting the appropriate provider the most important task. In most situations, several firms are likely to supply a corporation with chemicals adequately, but one or two will be superior than the rest. The difficult aspect is identifying those superior possibilities, but there are a few signs that might assist customers in identifying the finest selections.</p>\r\n\r\n<h4>IMPORTANT FACTORS TO CONSIDER WHILE CHOOSING THE FINEST CHEMICAL AND PHARMACEUTICAL PROVIDER:</h4>\r\n\r\n<p>â€¢ Verify the legitimacy of your source: There are several suppliers competing for the best purchasing offers. How can you choose the best supplier for yourself? Conduct research online. Examine the websites of the numerous providing firms, read the evaluations, and learn everything you can about the businesses. It will provide you a sense of the merchant\'s experience in this field, which is likely to lead in successful transactions and high-quality items.</p>\r\n\r\n<p>â€¢ Examine for consistency and reliability: The main question that arises is if the provider you\'re searching for has a solid track record of adhering to regulatory organisations or not. Did they recently carry out an assessment, and therefore will they share the results with you? Are they still searching for quality assurance from the appropriate bodies? If the answers to these questions match your criteria, then go for it.</p>\r\n\r\n<p>â€¢ Book a visit to the storage facility: Visiting the facility in person is one possible option for doing a detailed investigation of where the provider stores its inventory. This provides knowledge and awareness about the standards, condition, quality, and preservation of the chemical goods that will be delivered to you. You will get the opportunity to observe how they manage the most delicate and hazardous items under extreme conditions. Finally, it provides you with an understanding of the corporation\'s quality and service. The company\'s well-organized storage assures that you can depend on their products.</p>\r\n\r\n<p>â€¢ Examine certificates for genuineness: It is critical to verify that you are interacting with a reliable chemical manufacturer that is well-known and accredited. This guarantees you\'re working with legitimate suppliers rather than the imposters who plague the industry. Examine your requirements. Do you want to work with a large-scale provider or a small chemical production firm if you are a start-up? What should the prices of your items be, and who is your intended market? It will be simpler to find the proper supplier if you have answers to such questions.</p>\r\n\r\n<p>In conclusion, if we want to meet the best supplier of chemicals, we must properly follow these four fundamental procedures. It is vitally important that we select a firm that supplies 100% top quality standardized chemicals as well as other chemicals since the quality of product that a production company creates is dependent on the quality of components utilised.</p>\r\n', 'To build a strong brand, every chemical firm must verify a few key points with the manufacturer and distributor of the same items. The company\'s performance is dependent on finding a realistic contract that meets the needs of both pharmaceutical and chemical product supply.', 'SRD pharma manufacture and research, chemical and products for innovative research, custom chemical synthesis solutions', '22/10/2021', '2021-10-22 12:23:17'),
(8, 'Importance of Raw Material Testing & Analysis for Pharmaceutical Industry', 'importance-of-raw-material-testing-analysis-for-pharmaceutical-industry', 'blog_1639200526.jpg', '<p>The quality of the outputs is only as excellent as the quality of the inputs. If you don\'t first examine the quality of the raw materials, improving production procedures won\'t get you very far. Pollutants and impurities in the inputs can have an adverse influence on the end product\'s quality, effectiveness, and safety. Understanding the impurity level that begins to jeopardise final goods will assist you in maintaining quality production methods, avoiding costly recalls, and even optimising supply chain fluctuations and process costs.</p>\r\n\r\n<p>Since dozens of raw materials and components are utilised in the process of creating the final pharmaceutical product, it is difficult to ensure that each component is of high quality. Entering the production process will be impossible until the materials have been thoroughly tested for quality. Furthermore, using low-quality raw resources will result in a low-quality end product, which may need product recall. This can have a major impact on both material prices and reputation. As a result, raw material testing in medicines is required.</p>\r\n\r\n<p>Pharmaceutical raw material testing is performed to ensure that all inbound resources meet the necessary norms and regulations. Simply put, an unsatisfactory supply will undermine the safety and quality of the finished product. Furthermore, it will result in manufacturing delays and severe time and expense waste. As a result, testing laboratories assist pharmaceutical businesses in establishing raw material standards from the first phases of medication development.</p>\r\n\r\n<p>Before a pharmaceutical product or medical device is released for public use or sale, it must be authorised.  Material analysis, DSC analysis, chemical tests, physical characterization, NMR testing, FTIR testing, and other procedures can be carried out by testing laboratories in accordance with the requirements and safety regulations provided by the officials.  Chemical labs have normally conducted raw material testing and prepared reports to verify their quality and appropriateness for use in pharmaceutical medication compositions. They are well-equipped to carry out the complex processes required for raw material testing.</p>\r\n\r\n<p>With years of expertise in the examination of raw materials and completed products, we are Canada\'s leading pharmaceutical testing facility. We provide a full testing solution for pharmaceutical raw materials such as pharmaceutical drug compounds, intermediates, excipients, and so on. Our years of practice in chemical analysis, physical classification, and microbiological analysis in accordance with pharmacopeial regulations assist you in meeting these resource and capability difficulties.</p>\r\n\r\n<p>SRD Pharma analyses raw materials, both proactive and reactive. This service gives our clients peace of mind that their goods will continue to fulfil the most demanding quality requirements, or it helps them to swiftly discover if initial raw materials are a likely cause of end product foreign particle matter. Our specialists use an all-of-the-above strategy, which may involve microscopy, FTIR, Raman, and/or SEM-EDS based on the demands of the assignment.</p>\r\n\r\n<p>The pharmaceutical business employs a wide range of raw materials, and hundreds of substances might be used in the production of a single product. A pharmaceutical company\'s in-house testing facilities and abilities for all substances and products are sometimes challenging, if not impossible.</p>\r\n\r\n<p>Even though all of the facilities are available in-house, there will usually be a strain on the available resources, and it is critical to have a trustworthy partner who can evaluate pharmaceutical raw materials before they can be released and utilised to manufacture pharmaceutical goods. Aside from normal analysis for pharmaceutical raw material release testing, we also conduct method evaluation and development research for all of these tests.</p>\r\n\r\n<p>Our laboratories have also assisted various pharmaceutical raw material producers in conducting stability tests on their pharmaceutical drug ingredients and excipients. If you\'re wanting to quickly identify the cause of contamination in your production or are considering process adjustments, contact us to discover how we can shorten the time it takes you to find a solution.</p>', '', '', '11/12/2021', '2021-12-11 10:57:06');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `pid` int(40) NOT NULL,
  `pdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `plink` text NOT NULL,
  `proName` varchar(400) NOT NULL,
  `proCode` varchar(200) NOT NULL,
  `proCatalogue` varchar(200) NOT NULL,
  `proChemical` varchar(400) NOT NULL,
  `proSynonyms` text NOT NULL,
  `proImpurity` text NOT NULL,
  `proCasnum` varchar(200) NOT NULL,
  `proCasnumAlt` varchar(200) NOT NULL,
  `proMolecular` varchar(200) NOT NULL,
  `proAppearance` text NOT NULL,
  `proMelting` varchar(200) NOT NULL,
  `proMolweight` varchar(200) NOT NULL,
  `proStorage` text NOT NULL,
  `proSolubility` varchar(200) NOT NULL,
  `proStability` varchar(200) NOT NULL,
  `proCategory` text NOT NULL,
  `proBoiling` varchar(200) NOT NULL,
  `proApplications` text NOT NULL,
  `proDangerous` text NOT NULL,
  `proReferences` text NOT NULL,
  `proKeywords` text NOT NULL,
  `proExtraNotes` text NOT NULL,
  `proImage` text NOT NULL,
  `proDocument` text NOT NULL,
  `proProductPacks` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `uid` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `dated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `username`, `password`, `dated`) VALUES
(1, 'admin', '1e36159b6624810385a47004abba06ab', '2021-10-22 06:43:09'),
(2, 'master', '77565530b11dd30697290e5c256d2866', '2021-11-12 08:26:02');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`bid`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`pid`),
  ADD UNIQUE KEY `pro_search_name` (`proName`),
  ADD UNIQUE KEY `pro_search_advanced` (`proCode`,`proCasnum`,`proChemical`,`proMolecular`) USING BTREE;

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `bid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `pid` int(40) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
