<!-- include header -->
<?php include('inc/header.php'); ?>

<!-- page title -->
<div class="p-3 border-bottom">
  <h3> <strong>Blank Page</strong> </h3>
  <p>Click on <strong>Links</strong> in left sidebar to perform actions.</p>
</div>


<!-- include header -->
<?php include('inc/footer.php'); ?>