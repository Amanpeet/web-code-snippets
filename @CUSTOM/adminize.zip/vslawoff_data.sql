-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 07, 2018 at 02:18 PM
-- Server version: 5.7.24
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vslawoff_data`
--

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `bid` int(11) NOT NULL,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `image` text NOT NULL,
  `dated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`bid`, `title`, `content`, `image`, `dated`) VALUES
(1, 'Other Post C4', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '1544172219_image.jpg', '2018-12-07 14:13:39'),
(2, 'Dummy Post 01', 'OOT - Load Order Optimisation Tool Unofficial Skyrim Special Edition atchSKSE64 (beta)SkyUIJK\'s SkyrimA Quality World Map pocalypse Immersive Armors Immersive Weapons  mmersive Citizens - AI Overhaul        nWolf\'s Better-Shaped Weapons SE    limates Of Tamriel Special Edition -  eather - Lighting - Effects - Audio  True Storms Special Edition Vivid      hers Definitive Edition - a complete Weather and Visual overhaul for  kyrim Darker Nights Enhanced Lights and FX Enhanced Blood Textures SE  iverse Dragons Collection   mmersive Patrols SE  Realistic Water Two Quick Loot RE Realistic Ragdolls and Force   un For Your Lives  Ordinator Static Mesh Improvement Mod - SMIM Diverse Dragons Collection SE     im\'s Immersive Artifacts\r\n\r\n', '1544165056_image.jpg', '2018-12-07 14:12:58'),
(3, 'Modern Web Frameworks', 'Model-View-Controller (MVC) is one of the most widespread and influential patterns in software architecture. Rumors of MVCâ€™s death have been greatly exaggerated- it remains a useful pattern to understand. In this post, rather than reigning in the various definitions of MVC, I will highlight how it evolved into the modern web frameworks we know and love today.', '1544165343_image.png', '2018-12-07 12:19:02');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `uid` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `dated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `username`, `password`, `dated`) VALUES
(1, 'admin', '305e4f55ce823e111a46a9d500bcb86c', '2018-10-26 12:54:39'),
(2, 'master', '89f1d237760a0628873ef398fc09251c', '2018-12-07 11:34:09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`bid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `bid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
