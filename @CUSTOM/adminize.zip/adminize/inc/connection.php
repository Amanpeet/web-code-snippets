<?php
// error_reporting(0);
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'vslawoff_user');
define('DB_PASSWORD', 'mA9QpU0xcQ7p');
define('DB_DATABASE', 'vslawoff_data');
$conn = @mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_DATABASE) 
or die("Connection error: cant connect to Database.");
// or die("Connection error: " . mysqli_connect_error());
?>