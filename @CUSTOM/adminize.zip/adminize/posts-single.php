<!-- include header -->
<?php include('inc/header.php'); ?>

<?php
/* IF DELETE MEMBER */
if(isset($_REQUEST['del'])) {
  $id = $_REQUEST['del'];  
  ?>
    <div class="p-2 border-bottom">
      <h3> <strong>Delete Post</strong> </h3>
      <p>Confirm deletion of Specific Post.</p>
    </div>
    <div class="form-box p-2">
      <form id="id_card_form" name="id_card_form" action="" method="post">
        <?php
          $select = "SELECT * FROM blog WHERE bid = '$id'";
          $que = mysqli_query($conn, $select);
          $fet = mysqli_fetch_array($que);
        ?>
        <h5>Do you really want to delete id:<strong><?php echo $fet['bid']; ?> (Name: <?php echo $fet['proName']; ?>) </strong>from database? </h5>
        <p> Note: This action cannot be undone. </p>
        <div class="text-left">
          <input type="submit" class="btn btn-primary" name="deletemon" value="Delete">
          <a class="btn btn-dark" href="posts.php">Cancel</a>
          <br><br>
        </div>
      </form>
    </div>

    <div id="response" class="h4">
      <?php
      if(isset($_POST['deletemon'])){
        $delete = "DELETE FROM blog WHERE bid = '$id' ";
        $quer = mysqli_query($conn, $delete);
        if($quer){
          echo "<strong>SUCCESS: Post Deleted. Redirecting back...";
          echo '<script>window.location="posts.php";</script>'; 
        } else{
          echo "<strong>ERROR: Post not deleted. Please try again later.</strong>";
        }
      }
      ?>
    </div>
    <?php

/* IF Update MEMBER */
} else if(isset($_REQUEST['edit'])) {
  $id = $_REQUEST['edit'];
  ?>  
  <div class="p-2 border-bottom">
    <h3> <strong>Edit Post</strong> </h3>
    <p>Edit Details and Hit <strong>Update</strong> on bottom.</p>
  </div>

  <!-- Operation Updatemon -->
  <div id="response" class="h5">
    <?php
    if(isset($_POST['Updatemon'])) {

      //required
      $title   = mysqli_real_escape_string($conn, $_POST['title']);
      $content = mysqli_real_escape_string($conn, $_POST['content']);
      $image   = mysqli_real_escape_string($conn, $_POST['image']);

      if( empty($title) || empty($content) ){
        echo "<strong>ERROR: Required fields Empty or Invalid. Please try again.</strong>";
        // exit; 
      } else { 

        //files
        $ex_sql   = "SELECT * FROM blog WHERE bid = '$id' ";
        $ex_query = mysqli_query($conn, $ex_sql);
        $ex_row   = mysqli_fetch_array($ex_query);

        $image = $ex_row['image'];
        $fileserr1 = 0;
        $uniqd = round(microtime(true));

        //file1
        if( empty($_FILES['image']['name']) ){
          $image = $ex_row['image'];
          $fileserr1 = 0;
        } else if( ($_FILES['image']['size']==0) || ($_FILES['image']['size']>(2*1024*1024)) ) { 
          $fileserr1 = 1;
        } else {         
          $temp1        = explode(".", $_FILES["image"]["name"]);
          $newfilename1 = $uniqd . '_image' . '.' . end($temp1);
          $imagetmp1    = trim($_FILES['image']['tmp_name']);
          $path1        = "uploads/".$newfilename1;
          if( move_uploaded_file($imagetmp1, $path1) ){
            $image = $newfilename1;
          } else {
            $image = $ex_row['image'];
          }
          $fileserr1 = 0;
        }

        //no files error
        if( $fileserr1 == 1 ){
          echo "<strong>FAILED: Error in uploading Files. Max Size Allowed: 2 MB each.</strong>";
        } else {
          // Update products to db
          $Update = "UPDATE blog SET title='$title', content='$content', image='$image' WHERE bid = '$id'";
          $quer = mysqli_query($conn, $Update);
          if($quer){
            echo "<strong>SUCCESS: Post updated Successfully.</strong>";
            echo '<script>window.location="posts-single.php?view='.$id.'&updated=1";</script>';
            // echo '<script>window.location="#response";</script>';
          } else {
            echo "<strong>ERROR: Post not updated. Please try again later.</strong>";
          }
        }        
      }
    }
    ?>    
  </div>  

  <!-- Update form -->
  <div class="form-box p-2">
    <form id="id_card_form" name="id_card_form" action="" method="post" enctype="multipart/form-data">
      <?php
        $select = "SELECT * FROM blog WHERE bid = '$id'";
        $que = mysqli_query($conn, $select);
        $fet = mysqli_fetch_array($que);
        $datef = date('d M, Y', strtotime($fet['dated']));
      ?>
      <div class="py-3">            
        <small> Added on <?php echo $datef; ?> </small>
      </div> 
      <table class="table table-bordered">
        <tbody>
          <tr>
            <td style="width: 20%;"> Product Name </td>
            <td style="width: 60%;">
              <input type="text" class="form-control" name="title" required value="<?php echo $fet['title']; ?>">
            </td>
            <td style="width: 20%;"></td>
          </tr>          
          <tr>
            <td> Extra Notes </td>
            <td>
              <textarea class="form-control" name="content" required rows="8"><?php echo $fet['content']; ?></textarea>
            </td>
          </tr>

          <tr>
            <td> Upload new Image <br>(Picture) </td>
            <td>
              <input type="file" class="form-control-file" name="image" accept="image/*">
              <small>image only</small>
            </td>
          </tr>
        </tbody>
      </table>

      <div class="my-4">
        <input type="submit" class="btn btn-primary" name="Updatemon" value="Update">
        <a href="posts.php" class="btn btn-dark">Cancel</a> <br><br>
      </div>

    </form>
  </div>
  <?php

/* ELSE SHOW MEMBER */
} else if(isset($_REQUEST['view'])) {
  $id = $_REQUEST['view'];  
  ?>
      <!-- SHOW ALL ITEMS HERE -->
      <div class="p-2 border-bottom">
        <h3> <strong>View Post</strong> </h3>
        <p>Viewing individual Item details. Click <strong>Edit</strong> on right to modify details.</p>
      </div>

      <!-- response for Updatemon -->
      <div class="pt-2 pl-2 h4">
        <?php 
        if( isset($_REQUEST['updated']) ) {
          echo "<strong>SUCCESS: Post updated Successfully.</strong>";
        } 
        ?>
      </div>

      <div class="p-2">
        <?php 
        $select = "SELECT * FROM blog WHERE bid = '$id'";
        $quer = mysqli_query($conn, $select);
        while($fetch = mysqli_fetch_array($quer)){
          $datef = date('d M, Y', strtotime($fetch['dated']));
          ?>
          <div class="pt-2 pb-3">            
            <a class="btn btn-primary" href="posts-single.php?edit=<?php echo $fetch['bid']; ?>">Edit this</a> 
            <a class="btn btn-dark" href="posts-single.php?del=<?php echo $fetch['bid']; ?>">Delete</a> 
            <small> Added on <?php echo $datef; ?> </small>
          </div>

          <table class="table table-bordered">
            <tbody>
              <tr>
                <td style="width: 20%;"> Post Title </td>
                <td style="width: 60%;">
                  <?php echo $fetch['title']; ?>
                </td>
                <td style="width: 20%;">
                  <!-- <small>Click to Generate Manually</small> -->
                </td>
              </tr>              
              <tr>
                <td> Post Content </td>
                <td>
                  <?php echo $fetch['content']; ?>
                </td>
              </tr>

              <tr>
                <td> Post Image <br>(Picture) </td>
                <td>
                  <img src="uploads/<?php echo $fetch['image']; ?>" height="100" alt="image" /><br> 
                  <a class="btn btn-secondary btn-sm" href="uploads/<?php echo $fetch['image']; ?>" download>Download</a> 
                </td>
              </tr>
            </tbody>
          </table>
       
          <?php 
        } 
        ?>
      </div>
  <?php

/* ELSE SHOW ERROR */
} else {
  ?>
  <div class="p-3 border-bottom">
    <h3> <strong>Post not found</strong> </h3>
    <p>No Post found via given id. Please go back and try again.</p>
  </div>
  <?php

} //if else end
?>

<!-- include header -->
<?php include('inc/footer.php'); ?>