<!-- include header -->
<?php include('inc/header.php'); ?>

<!-- page title -->
<div class="p-3 border-bottom">
  <h3> <strong>Add New Post</strong> </h3>
  <p>New Post addition form.</p>    
</div>

<!-- operation & response -->
<div class="text-center h5 p-3">
  <?php
    if( isset($_POST['add_blogpost']) ){
      // print_r($_FILES);

      //required
      $title   = mysqli_real_escape_string($conn, $_POST['title']);
      $content = mysqli_real_escape_string($conn, $_POST['content']);
      $image   = mysqli_real_escape_string($conn, $_POST['image']);
      
      if( empty($title) || empty($content) ){
        echo "<strong>ERROR: Required fields Empty or Invalid. Please try again.</strong>";
        // exit; 
      } else { 
        // check if data existing    
        $checkexisting = "SELECT * FROM blog WHERE title = '$title' ";
        $checkque = mysqli_query($conn, $checkexisting);
        if(mysqli_num_rows($checkque) > 0){
          echo "<strong>ERROR: Blog with same title already exists.</strong>";
        } else {

          //files
          $image = '';
          $fileserr1 = $fileserr2 = 0;
          $uniqd = round(microtime(true));

          //file1
          if( ($_FILES['image']['size'] == 0) ){
            $image = '';
            $fileserr1 = 0;
          } else if( $_FILES['image']['size'] > (2*1024*1024) ) { 
            $fileserr1 = 1;
          } else {         
            $temp1        = explode(".", $_FILES["image"]["name"]);
            $newfilename1 = $uniqd . '_image' . '.' . end($temp1);
            $imagetmp1    = trim($_FILES['image']['tmp_name']);
            $path1        = "uploads/".$newfilename1;
            move_uploaded_file($imagetmp1, $path1);
            $image = $newfilename1;
            $fileserr1 = 0;
          }

          //no files error
          if( $fileserr1 == 1 ){
            echo "<strong>FAILED: Error in uploading Files. Max Size Allowed: 2 MB each.</strong>";
          } else {            
            // add data to db
            $insert = "INSERT INTO blog (title, content, image) VALUES ('$title', '$content', '$image' )";
            $que = mysqli_query($conn, $insert);
            if($que){
              echo "<strong>SUCCESS: New Blog Post Added Successfully.";
            } else {
              echo "<strong>ERROR: Blog Post not Added. Please try again later.</strong>";
            }
          }

        }
      }
    }
  ?>
</div>

<!-- content & forms -->
<div class="row p-2">
  <div class="col-md-12 col-lg-12">
    <div class="form-box">

      <form class="file-form" enctype="multipart/form-data" method="post" action="">
        <table class="table table-borderless">
          <tbody>
            <tr>
              <td style="width: 20%;"> Post Title </td>
              <td style="width: 60%;">
                <input type="text" class="form-control" name="title" required placeholder="Title">
              </td>
              <td style="width: 20%;"> </td>
            </tr>
            <tr>
              <td> Post Content </td>
              <td>
                <textarea class="form-control" name="content" placeholder="Write your Content" required rows="8"></textarea>
              </td>
            </tr>
            <tr>
              <td> Post Image <br>(optional) </td>
              <td>
                <input type="file" class="form-control-file" name="image" accept="image/*">
                <small>JPEG, JPG, PNG only. Max file size: 2MB</small>
              </td>
            </tr>
            <tr>
              <td colspan="2" class="text-center py-4">
                <input type="submit" class="btn btn-primary" name="add_blogpost" value="Submit">
              </td>
            </tr>
          </tbody>
        </table>
      </form>

    </div>
  </div>
</div>

<!-- include header -->
<?php include('inc/footer.php'); ?>