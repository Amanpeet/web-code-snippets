<!-- include header -->
<?php include('inc/header.php'); ?>

<!-- content goes here -->
<div class="p-3 border-bottom">
  <h3> <strong>Welcome Admin</strong> </h3>
  <p>Click on <strong>Posts</strong> in left sidebar to view all posts.</p>  
</div>

<!-- include header -->
<?php include('inc/footer.php'); ?>