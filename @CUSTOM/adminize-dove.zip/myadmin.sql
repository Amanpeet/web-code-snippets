-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 14, 2018 at 06:56 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.1.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myadmin`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `pid` int(40) NOT NULL,
  `pdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `proName` text NOT NULL,
  `proCode` varchar(200) NOT NULL,
  `proCatalogue` varchar(200) NOT NULL,
  `proChemical` varchar(200) NOT NULL,
  `proSynonyms` text NOT NULL,
  `proImpurity` text NOT NULL,
  `proCasnum` varchar(200) NOT NULL,
  `proCasnumAlt` varchar(200) NOT NULL,
  `proMolecular` varchar(200) NOT NULL,
  `proAppearance` text NOT NULL,
  `proMelting` varchar(200) NOT NULL,
  `proMolweight` varchar(200) NOT NULL,
  `proStorage` text NOT NULL,
  `proSolubility` varchar(200) NOT NULL,
  `proStability` varchar(200) NOT NULL,
  `proCategory` text NOT NULL,
  `proBoiling` varchar(200) NOT NULL,
  `proApplications` text NOT NULL,
  `proDangerous` text NOT NULL,
  `proReferences` text NOT NULL,
  `proKeywords` text NOT NULL,
  `proExtraNotes` text NOT NULL,
  `proImage` text NOT NULL,
  `proDocument` text NOT NULL,
  `proProductPacks` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`pid`, `pdate`, `proName`, `proCode`, `proCatalogue`, `proChemical`, `proSynonyms`, `proImpurity`, `proCasnum`, `proCasnumAlt`, `proMolecular`, `proAppearance`, `proMelting`, `proMolweight`, `proStorage`, `proSolubility`, `proStability`, `proCategory`, `proBoiling`, `proApplications`, `proDangerous`, `proReferences`, `proKeywords`, `proExtraNotes`, `proImage`, `proDocument`, `proProductPacks`) VALUES
(13, '2018-11-13 13:10:02', 'Hydro', 'H00002', 'C123', 'H2O', 'water, aqua, moar', 'pure', '123-945', '00', 'H2OX', 'colorless', '0C', '10mg', 'anywhere', 'lots', 'very', 'water type', '100C', 'u ll be amazed', 'naah', 'ref all u want', 'key1, key2, key 3', 'nan', 'H00002_proImage.png', 'H00002_proDocument.docx', '1g;2g;5g;tc;'),
(14, '2018-11-13 13:10:02', 'HydroX', 'H00003', 'C123x', 'H2O2', 'water, aqua, moar', 'pure', '123-945', '00', 'H2OX', 'colorless', '0C', '10mg', 'anywhere', 'lots', 'very', 'water type', '100C', 'u ll be amazed', 'naah', 'ref all u want', 'key1, key2, key 3', 'nan', 'H00003_proImage.jpg', 'H00002_proDocument.docx', '1g;2g;');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `uid` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `dated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `username`, `password`, `dated`) VALUES
(1, 'admin', '305e4f55ce823e111a46a9d500bcb86c', '2018-10-26 12:54:39'),
(2, 'master', '597a83ee0e377bb38d97fa3f5538067b', '2018-11-14 11:25:49');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`pid`);
ALTER TABLE `products` ADD FULLTEXT KEY `pro_search_index` (`proName`,`proSynonyms`,`proKeywords`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `pid` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
