<!-- check session -->
<?php include("logincheck.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="author" content="Amanz Galzor">
  <meta name="description" content="Custom Admin template by Amanz Galzor. Visit galzor.com for more information.">

  <title>Custom Admin Template</title>
  <link rel="shortcut icon" type="image/png" href="img/favicon.png?v=1">

  <!-- core CSS-->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/fontawesome.all.min.css" rel="stylesheet" type="text/css">
  <link href="css/sb-admin.css" rel="stylesheet">

  <!-- core JavaScript-->
  <script src="js/jquery.min.js"></script>

</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->

  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <a class="navbar-brand" href="index.html"><img src="img/logo-full.png" alt=""></a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">

      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link" data-toggle="modal" > 
            <i class="fa fa-fw fa-user"></i> <?php echo $_SESSION['username'];?>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" data-toggle="modal" data-target="#exampleModal"> <i class="fa fa-fw fa-sign-out-alt"></i>Logout</a>
        </li>
      </ul>

      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
        <li class="nav-item">
          <a class="nav-link" href="dashboard.php">
            <i class="fa fa-fw fa-home"></i>
            <span class="nav-link-text">Dashboard</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="add-product.php">
            <i class="fa fa-fw fa-box"></i>
            <span class="nav-link-text">Add Product</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="products.php">
            <i class="fa fa-fw fa-table"></i>
            <span class="nav-link-text">View Products</span>
          </a>
        </li>
        <!-- <li class="nav-item">
          <a class="nav-link" href="forms.php">
            <i class="fa fa-fw fa-file-alt"></i>
            <span class="nav-link-text">Form</span>
          </a>
        </li> -->
      </ul>

      <ul class="navbar-nav sidenav-toggler">
        <li class="nav-item">
          <a class="nav-link text-center" id="sidenavToggler">
            <i class="fa fa-fw fa-angle-left"></i>
          </a>
        </li>
      </ul>

    </div>
  </nav>
  <div class="content-wrapper">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <!-- content goes here -->