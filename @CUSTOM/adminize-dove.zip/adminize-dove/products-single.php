<!-- include header -->
<?php include('inc/header.php'); ?>

<?php
/* IF DELETE MEMBER */
if(isset($_REQUEST['del'])) {
  $id = $_REQUEST['del'];  
  ?>
    <div class="p-2 border-bottom">
      <h3> <strong>Delete Item</strong> </h3>
      <p>Confirm deletion of Specific Item.</p>
    </div>
    <div class="form-box p-2">
      <form id="id_card_form" name="id_card_form" action="" method="post">
        <?php
          $select = "select * from products where pid = '$id'";
          $que = mysqli_query($conn, $select);
          $fet = mysqli_fetch_array($que);
        ?>
        <h5>Do you really want to delete id:<strong><?php echo $fet['pid']; ?> (Name: <?php echo $fet['proName']; ?>) </strong>from database? </h5>
        <p> Note: This action cannot be undone. </p>
        <div class="text-left">
          <input type="submit" class="btn btn-primary" name="deletemon" value="Delete">
          <a class="btn btn-dark" href="products.php">Cancel</a>
          <br><br>
        </div>
      </form>
    </div>

    <div id="response" class="h4">
      <?php
      if(isset($_POST['deletemon'])){
        $delete = "DELETE FROM products WHERE pid = '$id' ";
        $quer = mysqli_query($conn, $delete);
        if($quer){
          echo "<strong>SUCCESS: Member Deleted. Redirecting back...";
          echo '<script>window.location="products.php";</script>'; 
        } else{
          echo "<strong>ERROR: Member not deleted. Please try again later.</strong>";
        }
      }
      ?>
    </div>
    <?php

/* IF UPDATE MEMBER */
} else if(isset($_REQUEST['edit'])) {
  $id = $_REQUEST['edit'];
  ?>  
  <div class="p-2 border-bottom">
    <h3> <strong>Edit Item</strong> </h3>
    <p>Edit Details and Hit <strong>UPDATE</strong> on bottom. Some fields can't be changed.</p>
  </div>

  <!-- Operation updatemon -->
  <div id="response" class="h5">
    <?php
    if(isset($_POST['updatemon'])) {

      //required
      $proName         = mysqli_real_escape_string($conn, $_POST['proName']);
      $proCode         = mysqli_real_escape_string($conn, $_POST['proCode']);
      $proCatalogue    = mysqli_real_escape_string($conn, $_POST['proCatalogue']);
      $proChemical     = mysqli_real_escape_string($conn, $_POST['proChemical']);

      //optional
      $proSynonyms     = mysqli_real_escape_string($conn, $_POST['proSynonyms']);
      $proImpurity     = mysqli_real_escape_string($conn, $_POST['proImpurity']);
      $proCasnum       = mysqli_real_escape_string($conn, $_POST['proCasnum']);
      $proCasnumAlt    = mysqli_real_escape_string($conn, $_POST['proCasnumAlt']);
      $proMolecular    = mysqli_real_escape_string($conn, $_POST['proMolecular']);
      $proAppearance   = mysqli_real_escape_string($conn, $_POST['proAppearance']);
      $proMelting      = mysqli_real_escape_string($conn, $_POST['proMelting']);
      $proMolweight    = mysqli_real_escape_string($conn, $_POST['proMolweight']);
      $proStorage      = mysqli_real_escape_string($conn, $_POST['proStorage']);
      $proSolubility   = mysqli_real_escape_string($conn, $_POST['proSolubility']);
      $proStability    = mysqli_real_escape_string($conn, $_POST['proStability']);
      $proCategory     = mysqli_real_escape_string($conn, $_POST['proCategory']);
      $proBoiling      = mysqli_real_escape_string($conn, $_POST['proBoiling']);
      $proApplications = mysqli_real_escape_string($conn, $_POST['proApplications']);
      $proDangerous    = mysqli_real_escape_string($conn, $_POST['proDangerous']);
      $proReferences   = mysqli_real_escape_string($conn, $_POST['proReferences']);
      $proKeywords     = mysqli_real_escape_string($conn, $_POST['proKeywords']);
      $proExtraNotes   = mysqli_real_escape_string($conn, $_POST['proExtraNotes']);

      //packs
      $proProductPacks = '';
      for ($i=1; $i<11; $i++) { 
        if( isset($_POST['proPack'.$i]) && !empty($_POST['proPack'.$i]) ){
          $proProductPacks .= mysqli_real_escape_string($conn, $_POST['proPack'.$i]) .";";
        }
      }
      
      if( empty($proName) || empty($proCode) || empty($proCatalogue) || empty($proChemical) ){
        echo "<strong>ERROR: Required fields Empty or Invalid. Please try again.</strong>";
        // exit; 
      } else { 

        //files
        $ex_sql   = "SELECT * FROM products WHERE pid = '$id' ";
        $ex_query = mysqli_query($conn, $ex_sql);
        $ex_row   = mysqli_fetch_array($ex_query);

        $proImage = $ex_row['proImage'];
        $proDocument = $ex_row['proDocument'];
        $fileserr1 = $fileserr2 = 0;
        // $uniqd = round(microtime(true));
        $uniqd = $proCode;

        //file1
        if( empty($_FILES['proImage']['name']) ){
          $proImage = $ex_row['proImage'];
          $fileserr1 = 0;
        } else if( ($_FILES['proImage']['size']==0) || ($_FILES['proImage']['size']>(2*1024*1024)) ) { 
          $fileserr1 = 1;
        } else {         
          $temp1        = explode(".", $_FILES["proImage"]["name"]);
          $newfilename1 = $uniqd . '_proImage' . '.' . end($temp1);
          $imagetmp1    = trim($_FILES['proImage']['tmp_name']);
          $path1        = "uploads/".$newfilename1;
          if( move_uploaded_file($imagetmp1, $path1) ){
            $proImage = $newfilename1;
          } else {
            $proImage = $ex_row['proImage'];
          }
          $fileserr1 = 0;
        }
        //file2
        if( empty($_FILES['proDocument']['name']) ){
          $proDocument = $ex_row['proDocument'];
          $fileserr2 = 0;
        } else if( ($_FILES['proDocument']['size']==0) || ($_FILES['proDocument']['size']>(2*1024*1024)) ) { 
          $fileserr2 = 1;
        } else {
          $temp2        = explode(".", $_FILES["proDocument"]["name"]);
          $newfilename2 = $uniqd . '_proDocument' . '.' . end($temp2);
          $imagetmp2    = trim($_FILES['proDocument']['tmp_name']);
          $path2        = "uploads/".$newfilename2;
          if( move_uploaded_file($imagetmp2, $path2) ){
            $proDocument = $newfilename2;
          } else {
            $proDocument = $ex_row['proDocument'];
          }
          $fileserr2 = 0;
        }

        //no files error
        if( $fileserr1 == 1 || $fileserr2 == 1 ){
          echo "<strong>FAILED: Error in uploading Files. Max Size Allowed: 2 MB each.</strong>";
        } else {
          // update products to db
          $update = "UPDATE products SET proName='$proName', proCode='$proCode', proCatalogue='$proCatalogue', proChemical='$proChemical', proSynonyms='$proSynonyms', proImpurity='$proImpurity', proCasnum='$proCasnum', proCasnumAlt='$proCasnumAlt', proMolecular='$proMolecular', proAppearance='$proAppearance', proMelting='$proMelting', proMolweight='$proMolweight', proStorage='$proStorage', proSolubility='$proSolubility', proStability='$proStability', proCategory='$proCategory', proBoiling='$proBoiling', proApplications='$proApplications', proDangerous='$proDangerous', proReferences='$proReferences', proKeywords='$proKeywords', proExtraNotes='$proExtraNotes', proImage='$proImage', proDocument='$proDocument', proProductPacks='$proProductPacks' WHERE pid = '$id' ";
          $quer = mysqli_query($conn, $update);
          if($quer){
            echo "<strong>SUCCESS: Member Details Updated Successfully.</strong>";
            echo '<script>window.location="products-single.php?view='.$id.'&updated=1";</script>';
            // echo '<script>window.location="#response";</script>';
          } else {
            echo "<strong>ERROR: Member Details not Updated. Please try again later.</strong>";
          }
        }        
      }
    }
    ?>    
  </div>  

  <!-- update form -->
  <div class="form-box p-2">
    <form id="id_card_form" name="id_card_form" action="" method="post" enctype="multipart/form-data">
      <?php
        $select = "SELECT * FROM products WHERE pid = '$id'";
        $que = mysqli_query($conn, $select);
        $fet = mysqli_fetch_array($que);
        $datef = date('d M, Y', strtotime($fet['pdate']));
      ?>
      <div class="py-3">            
        <small> Added on <?php echo $datef; ?> </small>
      </div> 
      <table class="table table-bordered">
        <tbody>
          <tr>
            <td style="width: 20%;"> Product Name </td>
            <td style="width: 60%;">
              <input type="text" class="form-control" name="proName" required value="<?php echo $fet['proName']; ?>" id="productname">
            </td>
            <td style="width: 20%;">
            </td>
          </tr>
          <tr>
            <td> Generate Code </td>
            <td>
              <input type="text" class="form-control" name="proCode" required value="<?php echo $fet['proCode']; ?>" id="productcodexxx">
            </td>
          </tr>
          <tr>
            <td> Catalogue number </td>
            <td>
              <input type="text" class="form-control" name="proCatalogue" required value="<?php echo $fet['proCatalogue']; ?>">
            </td>
          </tr>
          <tr>
            <td> Chemical name </td>
            <td>
              <input type="text" class="form-control" name="proChemical" required value="<?php echo $fet['proChemical']; ?>">
            </td>
          </tr>
          <tr>
            <td> Synonyms </td>
            <td>
              <textarea class="form-control" name="proSynonyms"><?php echo $fet['proSynonyms']; ?></textarea>
            </td>
          </tr>
          <tr>
            <td>Impurity </td>
            <td>
              <input type="text" class="form-control" name="proImpurity" value="<?php echo $fet['proImpurity']; ?>">
            </td>
          </tr>
          <tr>
            <td> CAS Number </td>
            <td>
              <input type="text" class="form-control" name="proCasnum" value="<?php echo $fet['proCasnum']; ?>">
            </td>
          </tr>
          <tr>
            <td> Alternate CAS # </td>
            <td>
              <input type="text" class="form-control" name="proCasnumAlt" value="<?php echo $fet['proCasnumAlt']; ?>">
            </td>
          </tr>
          <tr>
            <td> Molecular form </td>
            <td>
              <input type="text" class="form-control" name="proMolecular" value="<?php echo $fet['proMolecular']; ?>">
            </td>
          </tr>
          <tr>
            <td> Appearance </td>
            <td>
              <input type="text" class="form-control" name="proAppearance" value="<?php echo $fet['proAppearance']; ?>">
            </td>
          </tr>
          <tr>
            <td> Melting Point </td>
            <td>
              <input type="text" class="form-control" name="proMelting" value="<?php echo $fet['proMelting']; ?>">
            </td>
          </tr>
          <tr>
            <td> Mol. Weight </td>
            <td>
              <input type="text" class="form-control" name="proMolweight" value="<?php echo $fet['proMolweight']; ?>">
            </td>
          </tr>
          <tr>
            <td> Storage </td>
            <td>
              <input type="text" class="form-control" name="proStorage" value="<?php echo $fet['proStorage']; ?>">
            </td>
          </tr>
          <tr>
            <td> Solubility </td>
            <td>
              <input type="text" class="form-control" name="proSolubility" value="<?php echo $fet['proSolubility']; ?>">
            </td>
          </tr>
          <tr>
            <td> Stability </td>
            <td>
              <input type="text" class="form-control" name="proStability" value="<?php echo $fet['proStability']; ?>">
            </td>
          </tr>
          <tr>
            <td> Category </td>
            <td>
              <input type="text" class="form-control" name="proCategory" value="<?php echo $fet['proCategory']; ?>">
            </td>
          </tr>
          <tr>
            <td> Boiling Point </td>
            <td>
              <input type="text" class="form-control" name="proBoiling" value="<?php echo $fet['proBoiling']; ?>">
            </td>
          </tr>
          <tr>
            <td> Applications </td>
            <td>
              <textarea class="form-control" name="proApplications"><?php echo $fet['proApplications']; ?></textarea>
            </td>
          </tr>
          <tr>
            <td> Dangerous Goods Info </td>
            <td>
              <input type="text" class="form-control" name="proDangerous" value="<?php echo $fet['proDangerous']; ?>">
            </td>
          </tr>
          <tr>
            <td> References </td>
            <td>
              <textarea class="form-control" name="proReferences"><?php echo $fet['proReferences']; ?></textarea>
            </td>
          </tr>
          <tr>
            <td> Keywords </td>
            <td>
              <textarea class="form-control" name="proKeywords"><?php echo $fet['proKeywords']; ?></textarea>
            </td>
          </tr>
          <tr>
            <td> Extra Notes </td>
            <td>
              <textarea class="form-control" name="proExtraNotes"><?php echo $fet['proExtraNotes']; ?></textarea>
            </td>
          </tr>

          <tr>
            <td> Upload new Image <br>(Picture) </td>
            <td>
              <input type="file" class="form-control-file" name="proImage" accept="image/*">
              <small>image only</small>
            </td>
          </tr>
          <tr>
            <td> Upload new Document <br>(MSDS) </td>
            <td>
              <input type="file" class="form-control-file" name="proDocument" accept="application/pdf, application/doc, application/docx">
              <small>pdf, doc, docx</small>
            </td>
          </tr>
          <tr>
            <td> Product Packs </td>
            <td id="packbox">
              <?php 
              $packs = explode(";", $fet['proProductPacks']);
              $count=1;
              foreach ($packs as $pack) { 
                ?>
                <input type="text" class="form-control mt-2" name="proPack<?php echo $count; ?>" value="<?php echo $pack; ?>" placeholder="00mg (<?php echo $count; ?>)" data-pack="<?php echo $count; ?>">
                <?php 
                $count++;
              }
              ?>
            </td>
            <td> 
              <button type="button" class="btn btn-dark" id="addpack">Add Pack</button> 
            </td>
          </tr>
        </tbody>
      </table>

      <div class="my-4">
        <input type="submit" class="btn btn-primary" name="updatemon" value="UPDATE">
        <a href="products.php" class="btn btn-dark">Cancel</a> <br><br>
      </div>

    </form>
  </div>
  <?php

/* ELSE SHOW MEMBER */
} else if(isset($_REQUEST['view'])) {
  $id = $_REQUEST['view'];  
  ?>
      <!-- SHOW ALL ITEMS HERE -->
      <div class="p-2 border-bottom">
        <h3> <strong>View Item</strong> </h3>
        <p>Viewing individual Item details. Click <strong>Edit</strong> on right to modify details.</p>
      </div>

      <!-- response for updatemon -->
      <div class="pt-2 pl-2 h4">
        <?php 
        if( isset($_REQUEST['updated']) ) {
          echo "<strong>SUCCESS: Member Details Updated Successfully.</strong>";
        } 
        ?>
      </div>

      <div class="p-2">
        <?php 
        $select = "SELECT * FROM products WHERE pid = '$id'";
        $quer = mysqli_query($conn, $select);
        while($fetch = mysqli_fetch_array($quer)){
          $datef = date('d M, Y', strtotime($fetch['pdate']));
          ?>
          <div class="pt-2 pb-3">            
            <a class="btn btn-primary" href="products-single.php?edit=<?php echo $fetch['pid']; ?>">Edit this</a> 
            <a class="btn btn-dark" href="products-single.php?del=<?php echo $fetch['pid']; ?>">Delete</a> 
            <small> Added on <?php echo $datef; ?> </small>
          </div>

          <table class="table table-bordered">
            <tbody>
              <tr>
                <td style="width: 20%;"> Product Name </td>
                <td style="width: 60%;">
                  <?php echo $fetch['proName']; ?>
                </td>
                <td style="width: 20%;">
                  <!-- <small>Click to Generate Manually</small> -->
                </td>
              </tr>
              <tr>
                <td> Product Code </td>
                <td>
                  <?php echo $fetch['proCode']; ?>
                </td>
              </tr>
              <tr>
                <td> Catalogue number </td>
                <td>
                  <?php echo $fetch['proCatalogue']; ?>
                </td>
              </tr>
              <tr>
                <td> Chemical name </td>
                <td>
                  <?php echo $fetch['proChemical']; ?>
                </td>
              </tr>
              <tr>
                <td> Synonyms </td>
                <td>
                  <?php echo $fetch['proSynonyms']; ?>
                </td>
              </tr>
              <tr>
                <td>Impurity </td>
                <td>
                  <?php echo $fetch['proImpurity']; ?>
                </td>
              </tr>
              <tr>
                <td> CAS Number </td>
                <td>
                  <?php echo $fetch['proCasnum']; ?>
                </td>
              </tr>
              <tr>
                <td> Alternate CAS # </td>
                <td>
                  <?php echo $fetch['proCasnumAlt']; ?>
                </td>
              </tr>
              <tr>
                <td> Molecular form </td>
                <td>
                  <?php echo $fetch['proMolecular']; ?>
                </td>
              </tr>
              <tr>
                <td> Appearance </td>
                <td>
                  <?php echo $fetch['proAppearance']; ?>
                </td>
              </tr>
              <tr>
                <td> Melting Point </td>
                <td>
                  <?php echo $fetch['proMelting']; ?>
                </td>
              </tr>
              <tr>
                <td> Mol. Weight </td>
                <td>
                  <?php echo $fetch['proMolweight']; ?>
                </td>
              </tr>
              <tr>
                <td> Storage </td>
                <td>
                  <?php echo $fetch['proStorage']; ?>
                </td>
              </tr>
              <tr>
                <td> Solubility </td>
                <td>
                  <?php echo $fetch['proSolubility']; ?>
                </td>
              </tr>
              <tr>
                <td> Stability </td>
                <td>
                  <?php echo $fetch['proStability']; ?>
                </td>
              </tr>
              <tr>
                <td> Category </td>
                <td>
                  <?php echo $fetch['proCategory']; ?>
                </td>
              </tr>
              <tr>
                <td> Boiling Point </td>
                <td>
                  <?php echo $fetch['proBoiling']; ?>
                </td>
              </tr>
              <tr>
                <td> Applications </td>
                <td>
                  <?php echo $fetch['proApplications']; ?>
                </td>
              </tr>
              <tr>
                <td> Dangerous Goods Info </td>
                <td>
                  <?php echo $fetch['proDangerous']; ?>
                </td>
              </tr>
              <tr>
                <td> References </td>
                <td>
                  <?php echo $fetch['proReferences']; ?>
                </td>
              </tr>
              <tr>
                <td> Keywords </td>
                <td>
                  <?php echo $fetch['proKeywords']; ?>
                </td>
              </tr>
              <tr>
                <td> Extra Notes </td>
                <td>
                  <?php echo $fetch['proExtraNotes']; ?>
                </td>
              </tr>

              <tr>
                <td> Upload Image <br>(Picture) </td>
                <td>
                  <a class="btn btn-secondary btn-sm" href="uploads/<?php echo $fetch['proImage']; ?>" download>Download</a> <img src="uploads/<?php echo $fetch['proImage']; ?>" height="100" alt="image" /> 
                </td>
              </tr>
              <tr>
                <td> Upload Document <br>(MSDS) </td>
                <td>
                  <a class="btn btn-secondary btn-sm" href="uploads/<?php echo $fetch['proDocument']; ?>" download>Download</a> Document
                </td>
              </tr>
              <tr>
                <td> Product Packs </td>
                <td id="packbox">
                  <?php 
                  $packs = explode(";", $fetch['proProductPacks']);
                  foreach ($packs as $pack) {
                   echo $pack."<br>";
                  }
                  ?>
                </td>
              </tr>
            </tbody>
          </table>
       
          <?php 
        } 
        ?>
      </div>
  <?php

/* ELSE SHOW ERROR */
} else {
  ?>
  <div class="p-3 border-bottom">
    <h3> <strong>Product not found</strong> </h3>
    <p>No Product found via given id. Please go back and try again.</p>
  </div>
  <?php

} //if else end
?>

<!-- include header -->
<?php include('inc/footer.php'); ?>