<!-- include header -->
<?php include('inc/header.php'); ?>

<!-- content goes here -->
<h1>Welcome Admin</h1>
<p>Click on <strong>Members</strong> in left sidebar to view entries.</p>


<!-- include header -->
<?php include('inc/footer.php'); ?>