/* Copyright © 2011-2015 by Neil Jenkins. MIT Licensed. */
/*jshint ignore:start */

( function ( doc, undefined ) {

"use strict";
