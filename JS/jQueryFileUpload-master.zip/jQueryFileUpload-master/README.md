jQueryFileUpload
================

A simple method for handling file uploads with jQuery
