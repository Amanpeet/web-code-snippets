# animate-typing
This is plugin to animate typing that require jQuery to work
