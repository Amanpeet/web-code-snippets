export default function arrayMin(array) {
  return Math.min.apply(Math, array); // eslint-disable-line prefer-spread
}
