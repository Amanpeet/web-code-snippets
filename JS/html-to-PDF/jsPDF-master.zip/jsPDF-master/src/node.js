global.atob = require('atob');
global.btoa = require('btoa');
global.canvg = require('canvg');
global.GifReader = require('omggif').GifReader;
